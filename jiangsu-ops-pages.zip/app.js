/* 江苏经营工作台 · 网页版（公开托管版，空白数据）（自动生成，别手改） */
(function () {
	if (!window.React || !window.ReactDOM) {
		document.getElementById("root").innerHTML = '<div style="padding:40px;font-family:system-ui">React 没加载成功：检查 vendor/react.js、vendor/react-dom.js 是否存在</div>';
		return;
	}

		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		const React = window.React;
		const h = React.createElement;
		const useState = React.useState;
		const useMemo = React.useMemo;
		const useEffect = React.useEffect;

		// 独立网页版（没有 DSH 宿主）
		window.__JIANGSU_STANDALONE__ = true;
		// 公开托管版：第一次打开是空数据，靠「恢复」导入自己的备份
		window.__JIANGSU_BLANK_SEED__ = true;
		const PANEL_ID = "jiangsu-ops-v2";
		const STORE_KEY = "jiangsu-ops-v2:v1";
		const OTHER_STORE_KEY = "jiangsu-ops:v2"; // 旧版「江苏经营」的存储键（同源 localStorage，可直接读）
		const FONT = '"Microsoft YaHei", system-ui, -apple-system, "Segoe UI", sans-serif';

		const C = {
			ink: "#1f2328", sub: "#6b7280", line: "#e6e8eb", soft: "#f6f7f9",
			accent: "#2f6fed", accentSoft: "#eef3fe", warn: "#c4320a",
			warnSoft: "#fff4ee", ok: "#1a7f37", okSoft: "#eefbf3",
		};

		/* ------------------------------ 初始数据 ------------------------------ */

		let seq = 0;
		const nid = () => "r" + (++seq);
		const mk = (arr, keys) => arr.map((row) => {
			const o = { id: nid() };
			keys.forEach((k, i) => { o[k] = row[i] === undefined ? "" : String(row[i]); });
			return o;
		});

		/** 终端状态：未首单 / 休眠（超两倍周期没进货）/ 逾期 / 临近 / 在销 */
		function termState(t) {
			const raw = String(t.lastBuy || "").trim();
			if (!raw) return "未首单";
			const r = repurchase(t);
			if (r.state === "日期有误") return "日期有误";
			const d = new Date(raw.replace(/[./]/g, "-"));
			const cycle = num(t.cycle) || 30;
			const idle = Math.round((Date.now() - d.getTime()) / 86400000);
			if (idle > Math.max(90, cycle * 2)) return "休眠";
			return r.state === "正常" ? "在销" : r.state;
		}

		/** 公开部署用：清空真实数据，只留空框架（数据仍存在各自浏览器里） */
		function blankSeed() {
			const d = seed();
			return Object.assign({}, d, {
				customers: [],
				visits: [],
				agents: [],
				products: [],
				catalog: [],
				board: [],
				actions: [],
			});
		}

		/** 大客户标记：拜访只围绕大客户转，普通终端在终端台账里维护 */
		const isBig = (t) => !!(t && (String(t.big) === "1" || t.big === true));
		const bigGuess = (t) => (["县域连锁", "乡镇卫生院", "民营医院", "社区卫生服务站"].indexOf(String((t && t.type) || "").trim()) >= 0
			|| num(t && t.amt) >= 15000) ? "1" : "";

		/** 台账终端数：给了市/县区就按条件数 */
		function countTerminals(db, cityName, countyName) {
			return (db.customers || []).filter((t) => {
				const c = String(t.city || "").trim();
				const k = String(t.county || "").trim();
				if (cityName && c !== String(cityName).trim()) return false;
				if (countyName && k !== String(countyName).trim()) return false;
				return true;
			}).length;
		}

		/** 某市下辖县区名（下拉用） */
		function countyNamesIn(db, cityName) {
			const city = (db.cities || []).filter((c) => String(c.city || "").trim() === String(cityName || "").trim())[0];
			return city ? (db.counties || []).filter((k) => k.city === city.id).map((k) => String(k.name || "").trim()).filter(Boolean) : [];
		}

		/** 某市的负责人名字（下拉用） */
		function agentNamesIn(db, cityName) {
			return uniqArr((db.agents || [])
				.filter((a) => String(a.city || "").trim() === String(cityName || "").trim())
				.map((a) => String(a.name || "").trim()));
		}

		/** 江苏 13 市下辖县区（共 95 个），用于指标分解的市级向下细分 */
		const COUNTY_NAMES = {
			南京: ["玄武区", "秦淮区", "建邺区", "鼓楼区", "浦口区", "栖霞区", "雨花台区", "江宁区", "六合区", "溧水区", "高淳区"],
			苏州: ["姑苏区", "虎丘区", "吴中区", "相城区", "吴江区", "常熟市", "张家港市", "昆山市", "太仓市"],
			无锡: ["锡山区", "惠山区", "滨湖区", "梁溪区", "新吴区", "江阴市", "宜兴市"],
			常州: ["天宁区", "钟楼区", "新北区", "武进区", "金坛区", "溧阳市"],
			镇江: ["京口区", "润州区", "丹徒区", "丹阳市", "扬中市", "句容市"],
			南通: ["崇川区", "通州区", "海门区", "如东县", "启东市", "如皋市", "海安市"],
			扬州: ["广陵区", "邗江区", "江都区", "宝应县", "仪征市", "高邮市"],
			泰州: ["海陵区", "高港区", "姜堰区", "兴化市", "靖江市", "泰兴市"],
			徐州: ["鼓楼区", "云龙区", "贾汪区", "泉山区", "铜山区", "丰县", "沛县", "睢宁县", "新沂市", "邳州市"],
			连云港: ["连云区", "海州区", "赣榆区", "东海县", "灌云县", "灌南县"],
			淮安: ["清江浦区", "淮安区", "淮阴区", "洪泽区", "涟水县", "盱眙县", "金湖县"],
			盐城: ["亭湖区", "盐都区", "大丰区", "响水县", "滨海县", "阜宁县", "射阳县", "建湖县", "东台市"],
			宿迁: ["宿城区", "宿豫区", "沭阳县", "泗阳县", "泗洪县"],
		};

		const splitInt = (total, k) => {
			const t = Math.max(0, Math.round(num(total)));
			const base = Math.floor(t / k);
			const rem = t - base * k;
			return Array.from({ length: k }, (_, i) => base + (i < rem ? 1 : 0));
		};

		const splitNum = (total, k) => {
			const t = Math.max(0, num(total));
			const base = Math.floor((t * 10) / k) / 10;
			const rest = Math.round((t - base * k) * 10) / 10;
			return Array.from({ length: k }, (_, i) => (i === 0 ? base + rest : base));
		};

		/** 按市把终端数/目标均摊到县区；目标默认留空＝跟年度指标自动分摊 */
		function makeCounties(cities) {
			const out = [];
			cities.forEach((c) => {
				const names = COUNTY_NAMES[c.city] || [];
				if (!names.length) return;
				const ns = splitInt(c.n, names.length);
				names.forEach((nm, i) => out.push({
					id: nid(), city: c.id, name: nm, n: String(ns[i]), u: String(c.u || "0"), t: "",
				}));
			});
			return out;
		}

		/**
		 * 目标分摊：年度指标是唯一主数。
		 * 没手填值的市/县区，按「现有年化占比」自动分摊；手填过就用填的值。
		 */
		function targetsOf(db) {
			const annual = num(db.settings && db.settings.annualTarget);
			const cities = db.cities || [];
			const counties = db.counties || [];
			const cityE = new Map();
			cities.forEach((c) => cityE.set(c.id, 0));
			counties.forEach((k) => {
				if (cityE.has(k.city)) cityE.set(k.city, cityE.get(k.city) + num(k.n) * num(k.u) * 12 / 10000);
			});

			const manualCity = new Set(cities.filter((c) => String(c.t == null ? "" : c.t).trim() !== "").map((c) => c.id));
			let manualSum = 0;
			cities.forEach((c) => { if (manualCity.has(c.id)) manualSum += num(c.t); });
			const autoCities = cities.filter((c) => !manualCity.has(c.id));
			const rest = Math.max(0, annual - manualSum);
			const autoE = autoCities.reduce((a, c) => a + (cityE.get(c.id) || 0), 0);

			const effCity = new Map();
			cities.forEach((c) => {
				if (manualCity.has(c.id)) { effCity.set(c.id, num(c.t)); return; }
				const e = cityE.get(c.id) || 0;
				const auto = autoE > 0 ? rest * (e / autoE) : rest / Math.max(1, autoCities.length);
				effCity.set(c.id, auto);
			});

			const effCounty = new Map();
			const byCity = new Map();
			counties.forEach((k) => {
				if (!byCity.has(k.city)) byCity.set(k.city, []);
				byCity.get(k.city).push(k);
			});
			byCity.forEach((list, cityId) => {
				const ct = effCity.get(cityId) || 0;
				const manual = list.filter((k) => String(k.t == null ? "" : k.t).trim() !== "");
				const autoList = list.filter((k) => String(k.t == null ? "" : k.t).trim() === "");
				let mSum = 0;
				manual.forEach((k) => { mSum += num(k.t); effCounty.set(k.id, num(k.t)); });
				const left = Math.max(0, ct - mSum);
				const autoE2 = autoList.reduce((a, k) => a + num(k.n) * num(k.u) * 12 / 10000, 0);
				autoList.forEach((k) => {
					const e = num(k.n) * num(k.u) * 12 / 10000;
					const auto = autoE2 > 0 ? left * (e / autoE2) : left / Math.max(1, autoList.length);
					effCounty.set(k.id, auto);
				});
			});

			return { effCity, effCounty };
		}

		/** 找出覆盖某个县区的代理商：同城 + 区域写了该县区 / 全市 */
		function agentsOfCounty(db, countyName, cityName) {
			return (db.agents || []).filter((a) => {
				const ac = String(a.city || "").trim();
				if (!ac || (cityName && ac !== cityName)) return false;
				const parts = String(a.area || "").split(/[,，、/\\\s]+/).map((x) => x.trim()).filter(Boolean);
				if (!parts.length) return false;
				return parts.some((p) => p === "全市" || p === countyName);
			});
		}

		/** 已被代理商覆盖的县区 id 集合 */
		function coveredCountyIds(db) {
			const set = new Set();
			(db.counties || []).forEach((k) => {
				const city = (db.cities || []).filter((c) => c.id === k.city)[0];
				if (agentsOfCounty(db, k.name, city ? city.city : "").length) set.add(k.id);
			});
			return set;
		}

		/* ---------- 产品大类 × 代理商 × 县区 覆盖 ---------- */

		/** 一个代理商负责的大类：写「全部」＝全品类；可写多个，逗号分隔 */
		function catsOf(a) {
			const raw = String((a && a.cat) || "").trim();
			if (!raw) return ["全部"];
			const parts = raw.split(/[,，、/\s]+/).map((x) => x.trim()).filter(Boolean);
			if (!parts.length || parts.some((p) => p === "全部" || p === "全品类")) return ["全部"];
			return parts;
		}

		const agentCovers = (a, cat) => { const cs = catsOf(a); return cs.indexOf("全部") >= 0 || cs.indexOf(cat) >= 0; };

		/** 出现过的全部大类（品种目录 + 代理商），按预设顺序排 */
		function catListOf(db) {
			const out = [];
			catalogOf(db).forEach((r) => { const c = String(r.cat || "").trim() || "未分类"; if (out.indexOf(c) < 0) out.push(c); });
			(db.agents || []).forEach((a) => catsOf(a).forEach((c) => { if (c !== "全部" && out.indexOf(c) < 0) out.push(c); }));
			return out.sort((a, b) => catRank(a) - catRank(b));
		}

		/** 大类占比：读设置里的 catMix，自动归一到 100% */
		function mixOf(db) {
			const cats = catListOf(db);
			const raw = (db.settings && db.settings.catMix) || {};
			const vals = cats.map((c) => Math.max(0, num(raw[c])));
			const sum = vals.reduce((a, b) => a + b, 0);
			const share = {};
			cats.forEach((c, i) => { share[c] = sum > 0 ? vals[i] / sum : 1 / Math.max(1, cats.length); });
			return { cats, share, sum, hasMix: cats.some((c) => num(raw[c]) > 0) };
		}

		/** 某市某大类：谁负责、覆盖了哪些县区、哪些县区还空着 */
		function catCoverage(db, cityName, cat) {
			const name = String(cityName || "").trim();
			const city = (db.cities || []).filter((c) => String(c.city).trim() === name)[0];
			const counties = city ? (db.counties || []).filter((k) => k.city === city.id) : [];
			const agents = (db.agents || []).filter((a) => String(a.city || "").trim() === name && agentCovers(a, cat));
			const hit = {};
			agents.forEach((a) => {
				const parts = String(a.area || "").split(/[,，、/\\\s]+/).map((x) => x.trim()).filter(Boolean);
				if (!parts.length || parts.some((p) => p === "全市" || p === "全部")) counties.forEach((k) => { hit[k.name] = 1; });
				else parts.forEach((p) => { if (counties.some((k) => k.name === p)) hit[p] = 1; });
			});
			return { city, counties, agents, covered: Object.keys(hit), missing: counties.filter((k) => !hit[k.name]) };
		}

		/** 老数据没有「负责大类」时，从「承接产品」推出来 */
		function inferCat(db, scope) {
			const raw = String(scope || "").trim();
			if (!raw || /全部|全品类/.test(raw)) return "全部";
			const cats = [];
			raw.split(/[,，、/\s]+/).map((x) => x.trim()).filter(Boolean).forEach((p) => {
				const c = catOf(db, p);
				if (!c) return;
				const cn = String(c.cat || "").trim() || "未分类";
				if (cats.indexOf(cn) < 0) cats.push(cn);
			});
			return cats.length ? cats.join(",") : "全部";
		}

		/** 新建一个市：useTemplate=true 时把内置县区一起建好 */
		function buildCity(name, useTemplate) {
			const cityId = nid();
			const tpl = useTemplate ? (COUNTY_NAMES[String(name || "").trim()] || null) : null;
			const city = { id: cityId, city: String(name || "").trim(), zone: "", n: "0", u: "0", t: "" };
			const counties = tpl ? tpl.map((nm) => ({ id: nid(), city: cityId, name: nm, n: "0", u: "0", t: "" })) : [];
			return { city, counties };
		}

		/** 按市聚合一：市的数字来自下辖县区，目标取分摊结果 */
		function aggByCity(db) {
			const { effCounty } = targetsOf(db);
			const map = new Map();
			(db.cities || []).forEach((c) => map.set(c.id, { city: c, items: [], n: 0, e: 0, t: 0 }));
			(db.counties || []).forEach((k) => {
				const slot = map.get(k.city);
				if (!slot) return;
				const e = num(k.n) * num(k.u) * 12 / 10000;
				slot.items.push(k);
				slot.n += num(k.n);
				slot.e += e;
				slot.t += effCounty.get(k.id) || 0;
			});
			return Array.from(map.values());
		}

		const unitOf = (n, e) => (n ? e * 10000 / (n * 12) : 0);

		/** 分/万元：优先用设置里的覆盖值，否则按价格表平均值算；回款口径可选 */
		const convBasePrice = (p, base) => (base === "supply" ? num(p.supply) : base === "region" ? num(p.region) : num(p.county));

		function convOf(db) {
			const s = db.settings || {};
			const v = Number(s.conv) || 0;
			if (v > 0) return v;
			const base = s.convBase || "county";
			const ps = (db.products || []).filter((p) => convBasePrice(p, base) > 0 && num(p.pts) > 0);
			if (!ps.length) return 0;
			return ps.reduce((a, p) => a + (num(p.pts) / convBasePrice(p, base)) * 10000, 0) / ps.length;
		}

		/** 改动确认：开关打开时，每改一格都会记一条，底部可撤销 / 确认 */
		const UI = { strict: true };
		const CHANGELOG = { list: [], subs: [] };
		function pushChange(e) {
			const list = CHANGELOG.list;
			const last = list[list.length - 1];
			if (last && last.key === e.key) last.to = e.to;   // 同一格连续改，合成一条
			else {
				list.push(e);
				if (list.length > 30) list.shift();
			}
			CHANGELOG.subs.forEach((f) => f());
		}

		/** 把另一个插件的产品数据合并进当前 db（只动产品相关三块） */
		function mergeProductData(db, other, scopes) {
			const out = Object.assign({}, db);
			const o = other || {};
			if (scopes.catalog && Array.isArray(o.catalog) && o.catalog.length) out.catalog = o.catalog.map((r) => Object.assign({}, r));
			if (scopes.products && Array.isArray(o.products) && o.products.length) out.products = o.products.map((r) => Object.assign({}, r));
			if (scopes.settings && o.settings) {
				out.settings = Object.assign({}, db.settings, {
					conv: o.settings.conv,
					convBase: o.settings.convBase,
					catMix: o.settings.catMix,
				});
			}
			return out;
		}

		/** 读旧版插件的数据（同源 localStorage） */
		function readOtherStore() {
			try {
				const raw = window.localStorage.getItem(OTHER_STORE_KEY);
				if (!raw) return null;
				const v = JSON.parse(raw);
				return v && typeof v === "object" ? v : null;
			} catch (e) {
				return null;
			}
		}

		/** 去重（保持顺序，丢空值） */
		const uniqArr = (arr) => arr.filter((x, i) => x && arr.indexOf(x) === i);

		/** 产品目录里的标准名（老数据里写错的在这里统一） */
		const NAME_ALIAS = { "柱附地黄颗粒": "桂附地黄颗粒", "丹参瘢痕涂膜": "丹芎瘢痕涂膜", "前列舒丸": "前列腺舒丸" };
		const normName = (s) => {
			const t = String(s == null ? "" : s).trim();
			return NAME_ALIAS[t] || t;
		};
		const catalogOf = (db) => (db && Array.isArray(db.catalog) ? db.catalog : []);
		/** 按品种名找目录条目 */
		const catOf = (db, name) => catalogOf(db).filter((r) => normName(r.name) === normName(name))[0] || null;

		/* --------------- 产品目录（来源：《威海人生药业·精品推广目录》） --------------- */
		/** 大类顺序 */
		const CAT_ORDER = ["骨科", "皮肤", "儿科与呼吸", "补益与男科妇科", "口腔", "胃肠与补液"];
		const catRank = (c) => { const i = CAT_ORDER.indexOf(c); return i < 0 ? 99 : i; };
		/** 一条规格里可能有多规格："20g/支×240盒；40g/支×240盒" */
		const specList = (s) => String(s || "").split(/[；;]/).map((x) => x.trim()).filter(Boolean);
		/** 列：大类 / 小类 / 品种 / 卖点 / 资质 / 规格 / 成份 / 主治 / 用法 */
		const CAT_ROWS = [];

		function seed() {
			seq = 0;
			const cities = mk([
				["南京", "苏南", 60, 1400, ""], ["苏州", "苏南", 80, 1300, ""],
				["无锡", "苏南", 45, 1350, ""], ["常州", "苏南", 40, 1200, ""],
				["镇江", "苏南", 25, 1150, ""], ["南通", "苏中", 55, 1100, ""],
				["扬州", "苏中", 35, 1050, ""], ["泰州", "苏中", 30, 1050, ""],
				["徐州", "苏北", 70, 1000, ""], ["连云港", "苏北", 30, 950, ""],
				["淮安", "苏北", 35, 950, ""], ["盐城", "苏北", 40, 1000, ""],
				["宿迁", "苏北", 30, 900, ""],
			], ["city", "zone", "n", "u", "t"]);

			const AGENT_ROWS = [];
			const agentOfCity = {};
			AGENT_ROWS.forEach((r) => { if (r[1] === "地区") agentOfCity[r[2]] = r[0]; });

			/* 终端台账：9 家老客户 + 每个市生成 2 家（共 35 家） */
			const T_TYPES = ["个体诊所", "单体药店", "乡镇卫生院", "村卫生室", "社区卫生服务站", "县域连锁", "民营医院"];
			const T_ROWS = [];
			cities.forEach((c, ci) => {
				(COUNTY_NAMES[c.city] || []).slice(0, 2).forEach((kn, ki) => {
					const n = ci * 2 + ki;
					const type = T_TYPES[n % T_TYPES.length];
					const amt = 1500 + (n % 9) * 1100;
					const cycle = [30, 45, 60][n % 3];
					const mode = n % 7;   // 0 临近 / 1 在销 / 2 刚逾期 / 3 休眠 / 4 在销 / 5 逾期 / 6 刚进货
					const idle = mode === 0 ? cycle - 3
						: mode === 1 ? 5
							: mode === 2 ? cycle + 2
								: mode === 3 ? 200
									: mode === 4 ? Math.round(cycle * 0.6)
										: mode === 5 ? cycle + 40
											: 12;
					const short = kn.replace(/[区市县]$/, "");
					T_ROWS.push([
						(c.city + short + (type.indexOf("药店") >= 0 ? "大药房" : type.indexOf("卫生院") >= 0 ? "卫生院" : type.indexOf("卫生室") >= 0 ? "卫生室" : "诊所")),
						type, c.city, kn, agentOfCity[c.city] || "", "139" + String(10000000 + n * 137).slice(0, 8),
						amt, 3 + (n % 3), 3 + ((n + 1) % 3), "", daysAgo(idle + 180), daysAgo(idle), cycle,
					]);
				});
			});

			const db = {
				schema: 4,
				cities,
				counties: makeCounties(cities),

				segments: mk([
					["苏南", "南京、苏州、无锡、常州、镇江", "做样板、提单产；靠病例和讲者打开", "40%"],
					["苏中", "南通、扬州、泰州", "做通道、稳覆盖；苏南打法平移、控投入", "25%"],
					["苏北", "徐州、连云港、淮安、盐城、宿迁", "做密度、做客情；先铺后提", "35%"],
				], ["region", "cities", "play", "resource"]),

				decisions: mk([
					["①", "先打哪三个市", "苏州（样板）+ 徐州（规模）+ 南通（通道）"],
					["②", "首批招几个人", "年目标 ÷ 12 ÷ 单产 ÷ 活跃率 ÷ 人均维护终端数"],
					["③", "费用怎么分", "40% 样板市、35% 规模市、25% 通道市与机动"],
				], ["mark", "title", "content"]),

				customers: mk(T_ROWS, ["name", "type", "city", "county", "agent", "phone", "amt", "pot", "coop", "products", "firstBuy", "lastBuy", "cycle"])
					.map((t) => Object.assign(t, { big: bigGuess(t) })),

				agents: mk(AGENT_ROWS, ["name", "role", "city", "area", "scope", "cat", "task", "real"]),

				plan: mk([
					["第 1 周", "摸底", "拿到三年数据、终端台账、代理名单、商业协议、费用预算、系统权限", "交接清单"],
					["第 2 周", "摸底", "13 市一市一表：容量、竞品、终端、配送、政策", "江苏市场地图"],
					["第 3 周", "摸底", "见 3 家商业公司，列配送盲区；跑 10 家终端看竞品", "配送盲区清单"],
					["第 4 周", "摸底", "跟访现有代理各 1 天，评能力；定首批三个市", "能力评估 + 三市决定"],
					["第 5 周", "选商", "四渠道找人，见面六问，打分", "候选名单 + 评分表"],
					["第 6 周", "选商", "尽调六查，签 3—5 家，下达首年任务书", "协议 + 任务书"],
					["第 7 周", "启动", "启动会（讲三件事）+ 48 小时帮扶", "首周目标 + 首单"],
					["第 8 周", "启动", "三件套下发：一页纸话术、病例卡、FAQ", "话术卡人手一份"],
					["第 9 周", "开发", "终端五步法，每家代理开发 5—10 家", "终端台账更新"],
					["第 10 周", "动销", "首场圆桌会 / 科室会，48 小时回访", "活动复盘"],
					["第 11 周", "固化", "周会六问跑通两轮；库存与流向首次月报", "周报 + 库存表"],
					["第 12 周", "复盘", "90 天复盘：留什么、停什么、下季度目标", "季度计划"],
				], ["week", "stage", "action", "output"]).map((r) => Object.assign({}, r, { done: false })),

				weekq: mk([
					["上周数字差在哪？", "定位问题：哪个市、哪个品规、哪个终端"],
					["这个客户为什么不动？", "客情、价格、库存、竞品，还是政策"],
					["本周做哪三件事？", "具体到哪几家、哪一天"],
					["需要我什么支持？", "费用、物料，还是要我陪你去"],
					["下周怎么验证？", "看哪个指标、多少算合格"],
					["你自己卡在哪？", "是不会，还是不想"],
				], ["q", "purpose"]),

				board: mk([
					["1月", 83.3, 72.5, 68.0, 52, 380], ["2月", 83.3, 78.0, 74.5, 55, 395],
					["3月", 83.3, 96.0, 101.0, 49, 412], ["4月", 83.3, "", "", "", ""],
					["5月", 83.3, "", "", "", ""], ["6月", 83.3, "", "", "", ""],
					["7月", 83.3, "", "", "", ""], ["8月", 83.3, "", "", "", ""],
					["9月", 83.3, "", "", "", ""], ["10月", 83.3, "", "", "", ""],
					["11月", 83.3, "", "", "", ""], ["12月", 83.3, "", "", "", ""],
				], ["month", "target", "actual", "pure", "inv", "active"]),

				metrics: mk([
					["结果", "回款达成率", "回款 ÷ 目标", "月", "＜95%"],
					["结果", "纯销达成率", "纯销 ÷ 目标", "月", "＜90%"],
					["结果", "同比增长率", "(本期 − 同期) ÷ 同期", "月", "＜0"],
					["过程", "有效拜访覆盖率", "有效拜访 ÷ 计划拜访", "周", "＜80%"],
					["过程", "新增有效终端", "当月首次有购进的终端数", "月", "＜计划50%"],
					["过程", "活跃终端率", "月内有购进 ÷ 总终端", "月", "＜60%"],
					["过程", "单终端产出", "纯销 ÷ 活跃终端", "月", "环比下降"],
					["过程", "活动转化率", "会后30天进货 ÷ 参会客户", "场", "＜30%"],
					["健康", "库存周转天数", "期末库存 ÷ 月均纯销 × 30", "月", "＞60天"],
					["健康", "断货风险天数", "库存 ÷ 日均纯销", "周", "＜15天"],
					["健康", "应收周转天数", "应收 ÷ 月均回款 × 30", "月", "＞60天"],
					["健康", "费用率", "费用 ÷ 回款", "月", "超预算"],
					["健康", "退货率", "退货 ÷ 发货", "月", "＞3%"],
					["健康", "代表流失率", "季度离职 ÷ 期初人数", "季", "＞15%"],
				], ["level", "name", "formula", "freq", "warn"]),

				meetings: mk([
					["晨会", "每日", "15 分钟", "今日路线、目标客户、携带物料", "省区 + 地区"],
					["周会", "每周五", "30—40 分钟", "六问：差在哪、为什么、做哪三件、要什么、怎么验证、卡在哪", "省区 + 全体代理"],
					["协同拜访", "每周 2 次", "半天", "看、听、问、示范、当天复盘", "省区 + 1 名代理"],
					["月度经营分析", "每月 3—5 日", "2 小时", "八张表：达成、结构、终端、代理、活动、费用、库存、竞品", "省区 + 地区 + 财务"],
					["季度复盘", "每季末", "半天", "目标校准、代理升降级、费用重分配、打法取舍", "省区 + 大区"],
					["年度规划", "12 月", "1 天", "目标、区域、编制、预算、样板市场", "省区 + 大区 + 市场部"],
				], ["name", "freq", "dur", "agenda", "who"]),

				month8: mk([
					["1", "达成表", "目标完成多少，差在哪个市、哪个品规"],
					["2", "结构表", "增长来自覆盖、单产、复购还是品类"],
					["3", "终端表", "覆盖、活跃、单产三个数的变化"],
					["4", "代理商表", "A/B/C 怎么变，谁在掉队"],
					["5", "活动表", "几场、花多少、30 天转化多少"],
					["6", "费用表", "钱花在哪、ROI 多少"],
					["7", "库存与流向表", "周转、断货、滞销、窜货"],
					["8", "竞品与政策表", "对手在做什么、政策有什么变化"],
				], ["no", "name", "question"]),

				strategy: mk([
					["市场判断", "盘子多大、增速多少、竞争格局、政策往哪走"],
					["目标", "回款、纯销、增长、覆盖、利润各多少"],
					["增长路径", "覆盖、单产、复购还是品类，各贡献多少"],
					["重点区域", "哪 3—5 个县是主战场，哪些放弃"],
					["重点客户", "A 类名单、待开发的重点终端"],
					["产品组合", "主推、搭配、防御品规"],
					["渠道", "用哪几家商业公司，怎么分工"],
					["队伍", "编制、区域划分、招人、淘汰"],
					["学术", "全年活动排期、重点专家、预算"],
					["费用", "总额、结构、ROI 目标"],
					["节奏", "季度里程碑、关键战役时间点"],
					["风险", "政策、竞品、人员、资金及预案"],
				], ["module", "question"]).map((r) => Object.assign({}, r, { answer: "" })),

				oneplan: {
					strategy: "",
					battles: "",
					redlines: "",
				},

				settings: {
					annualTarget: "1000",
					conv: "",
					convBase: "region",
					monthPoints: "",
					catMix: { "骨科": 40, "皮肤": 20, "儿科与呼吸": 20, "补益与男科妇科": 10, "口腔": 5, "胃肠与补液": 5, "未分类": 0 },
				},

				cards: mk([
					["年度回款目标", "auto:target", ""],
					["月均目标", "auto:month", ""],
					["现有年化产出", "auto:existing", ""],
					["缺口", "auto:gap", ""],
					["折合目标分", "auto:points", ""],
				], ["label", "type", "value"]),

				products: mk([], ["name", "spec", "pts", "retail", "supply", "county", "region", "days"]),

				catalog: mk(CAT_ROWS, ["cat", "sub", "name", "sell", "qual", "spec", "ing", "act", "use"]),

				visits: [],

				actions: mk([
					["本人", "约谈 C 药业，定降目标或缩区域", "本周五", "未开始", ""],
					["F 商贸", "补 30 家新终端名单，逐家排拜访", "本月底", "进行中", ""],
					["本人", "把 3 个市的一页纸话术发到代理群", "本周三", "已完成", "已发，群内 12 人确认"],
				], ["owner", "action", "due", "status", "result"]),

				loop: mk([
					["① 摸底", "第 1—4 周", "数据、市场、终端、商业、政策、队伍", "能说出每个市的容量和份额"],
					["② 选商", "第 3—6 周", "四渠道、六问、尽调、签约", "签 3—5 家，任务书下达"],
					["③ 启动", "签约后 30 天", "启动会、48 小时帮扶、首批开发", "每家代理 ≥5 家终端首单"],
					["④ 开发", "第 2—3 月", "终端分级、五步开发、首推落地", "活跃终端达计划 60%"],
					["⑤ 动销", "第 3—6 月", "话术、病例、活动、复购", "单产达目标"],
					["⑥ 复盘", "每月/每季", "八张表、分级考核、汰换", "差的停、好的复制"],
				], ["step", "time", "action", "done"]),
			};

			return db;
		}

		/* ------------------------------ 样式 ------------------------------ */

		const inputBase = {
			width: "100%", boxSizing: "border-box", border: "1px solid transparent",
			background: "transparent", padding: "3px 5px", borderRadius: 4,
			fontSize: "inherit", fontFamily: FONT, color: "inherit", outline: "none",
		};

		const S = {
			page: { height: "100%", overflow: "auto", padding: "22px 30px 56px", background: "#fff", color: C.ink, fontFamily: FONT, fontSize: 13, lineHeight: 1.6, boxSizing: "border-box" },
			head: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, flexWrap: "wrap", marginBottom: 4 },
			h1: { fontSize: 19, fontWeight: 650, margin: 0, letterSpacing: 0.2 },
			sub: { fontSize: 12.5, color: C.sub, marginTop: 2 },
			tabs: { display: "flex", gap: 2, borderBottom: `1px solid ${C.line}`, margin: "16px 0 18px" },
			tab: { appearance: "none", border: "none", background: "transparent", padding: "8px 13px", fontSize: 13, color: C.sub, cursor: "pointer", borderBottom: "2px solid transparent", marginBottom: -1, fontFamily: FONT },
			tabOn: { color: C.accent, borderBottomColor: C.accent, fontWeight: 600 },
			cards: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 12, marginBottom: 18 },
			card: { border: `1px solid ${C.line}`, borderRadius: 10, padding: "13px 15px", background: "#fff" },
			cardLabel: { fontSize: 12, color: C.sub, marginBottom: 4 },
			cardValue: { fontSize: 22, fontWeight: 650, letterSpacing: -0.2 },
			cardHint: { fontSize: 11.5, color: C.sub, marginTop: 2 },
			sec: { fontSize: 13.5, fontWeight: 650, margin: "22px 0 4px", display: "flex", alignItems: "center", gap: 8 },
			bar: { display: "inline-block", width: 3, height: 13, background: C.accent, borderRadius: 2 },
			note: { fontSize: 12, color: C.sub, marginBottom: 10 },
			table: { width: "100%", borderCollapse: "collapse", fontSize: 12.5, tableLayout: "fixed", marginBottom: 6 },
			th: { textAlign: "left", fontWeight: 600, fontSize: 11.5, color: "#4b5563", background: C.soft, border: `1px solid ${C.line}`, padding: "7px 8px" },
			td: { border: `1px solid ${C.line}`, padding: "2px 3px", verticalAlign: "middle" },
			add: { appearance: "none", border: `1px dashed ${C.line}`, background: "#fff", color: C.sub, padding: "5px 12px", borderRadius: 7, fontSize: 12, cursor: "pointer", fontFamily: FONT },
			del: { appearance: "none", border: "none", background: "transparent", color: "#c9ccd1", cursor: "pointer", fontSize: 13, padding: "0 4px", fontFamily: FONT },
		};

		const fmt = (n, d) => (Number(n) || 0).toLocaleString("zh-CN", { minimumFractionDigits: d == null ? 1 : d, maximumFractionDigits: d == null ? 1 : d });
		const num = (v) => Number(v) || 0;
		const pct = (n) => (num(n) * 100).toFixed(1) + "%";

		const fmtDate = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
		const daysAgo = (n) => {
			const d = new Date();
			d.setDate(d.getDate() - n);
			return fmtDate(d);
		};

		/** 复购推算：最近进货 + 周期 = 应复购日；今天超过就是逾期 */
		function repurchase(c) {
			const raw = String(c.lastBuy || "").trim();
			if (!raw) return { state: "未进货", due: "", days: null };
			const d = new Date(raw.replace(/[./]/g, "-"));
			if (isNaN(d.getTime())) return { state: "日期有误", due: "", days: null };
			const cycle = num(c.cycle) || 30;
			const due = new Date(d.getTime() + cycle * 86400000);
			const today = new Date();
			today.setHours(0, 0, 0, 0);
			const days = Math.round((due - today) / 86400000);
			return { state: days < 0 ? "逾期" : days <= 7 ? "临近" : "正常", due: fmtDate(due), days };
		}

		/* ---------------------------- Excel 导出 ---------------------------- */

		const crcTable = (() => {
			const t = new Uint32Array(256);
			for (let n = 0; n < 256; n++) {
				let c = n;
				for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
				t[n] = c >>> 0;
			}
			return t;
		})();

		function crc32(u8) {
			let c = 0xffffffff;
			for (let i = 0; i < u8.length; i++) c = crcTable[(c ^ u8[i]) & 0xff] ^ (c >>> 8);
			return (c ^ 0xffffffff) >>> 0;
		}

		/** 无压缩 ZIP（Excel 接受 store 方式） */
		function zip(files) {
			const enc = new TextEncoder();
			const parts = [];
			const central = [];
			let offset = 0;
			files.forEach((f) => {
				const name = enc.encode(f.name);
				const data = f.data;
				const crc = crc32(data);
				const lh = new Uint8Array(30 + name.length);
				const dv = new DataView(lh.buffer);
				dv.setUint32(0, 0x04034b50, true);
				dv.setUint16(4, 20, true);
				dv.setUint16(6, 0x0800, true);
				dv.setUint16(8, 0, true);
				dv.setUint16(10, 0, true);
				dv.setUint16(12, 0, true);
				dv.setUint32(14, crc, true);
				dv.setUint32(18, data.length, true);
				dv.setUint32(22, data.length, true);
				dv.setUint16(26, name.length, true);
				dv.setUint16(28, 0, true);
				lh.set(name, 30);
				parts.push(lh, data);

				const ch = new Uint8Array(46 + name.length);
				const cv = new DataView(ch.buffer);
				cv.setUint32(0, 0x02014b50, true);
				cv.setUint16(4, 20, true);
				cv.setUint16(6, 20, true);
				cv.setUint16(8, 0x0800, true);
				cv.setUint16(10, 0, true);
				cv.setUint16(12, 0, true);
				cv.setUint16(14, 0, true);
				cv.setUint32(16, crc, true);
				cv.setUint32(20, data.length, true);
				cv.setUint32(24, data.length, true);
				cv.setUint16(28, name.length, true);
				cv.setUint16(30, 0, true);
				cv.setUint16(32, 0, true);
				cv.setUint16(34, 0, true);
				cv.setUint16(36, 0, true);
				cv.setUint32(38, 0, true);
				cv.setUint32(42, offset, true);
				ch.set(name, 46);
				central.push(ch);
				offset += lh.length + data.length;
			});

			const cdSize = central.reduce((a, c) => a + c.length, 0);
			const eocd = new Uint8Array(22);
			const ev = new DataView(eocd.buffer);
			ev.setUint32(0, 0x06054b50, true);
			ev.setUint16(8, files.length, true);
			ev.setUint16(10, files.length, true);
			ev.setUint32(12, cdSize, true);
			ev.setUint32(16, offset, true);

			const total = offset + cdSize + 22;
			const out = new Uint8Array(total);
			let p = 0;
			parts.forEach((b) => { out.set(b, p); p += b.length; });
			central.forEach((b) => { out.set(b, p); p += b.length; });
			out.set(eocd, p);
			return out;
		}

		const colName = (i) => {
			let s = "";
			let n = i + 1;
			while (n > 0) {
				const m = (n - 1) % 26;
				s = String.fromCharCode(65 + m) + s;
				n = Math.floor((n - 1) / 26);
			}
			return s;
		};

		const xmlEsc = (s) => String(s == null ? "" : s)
			.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
			.replace(/"/g, "&quot;").replace(/'/g, "&apos;");

		function sheetXml(head, rows) {
			const cell = (ref, v) => {
				if (typeof v === "number" && isFinite(v)) return `<c r="${ref}"><v>${v}</v></c>`;
				const t = v == null ? "" : String(v);
				if (!t) return "";
				return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlEsc(t)}</t></is></c>`;
			};
			const lines = [];
			const hr = head.map((t, i) => cell(colName(i) + "1", t)).join("");
			lines.push(`<row r="1">${hr}</row>`);
			rows.forEach((row, ri) => {
				const cells = row.map((v, ci) => cell(colName(ci) + (ri + 2), v)).join("");
				lines.push(`<row r="${ri + 2}">${cells}</row>`);
			});
			return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${lines.join("")}</sheetData></worksheet>`;
		}

		function buildXlsx(sheets) {
			const enc = new TextEncoder();
			const files = [];
			const n = sheets.length;
			const overrides = sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("");
			const types = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${overrides}</Types>`;
			files.push({ name: "[Content_Types].xml", data: enc.encode(types) });

			const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
			files.push({ name: "_rels/.rels", data: enc.encode(rels) });

			const sheetTags = sheets.map((s, i) => `<sheet name="${xmlEsc(s.name).slice(0, 31)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("");
			const wb = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheetTags}</sheets></workbook>`;
			files.push({ name: "xl/workbook.xml", data: enc.encode(wb) });

			const wbRels = sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("");
			files.push({ name: "xl/_rels/workbook.xml.rels", data: enc.encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${wbRels}</Relationships>`) });

			sheets.forEach((s, i) => {
				files.push({ name: `xl/worksheets/sheet${i + 1}.xml`, data: enc.encode(sheetXml(s.head, s.rows)) });
			});

			return zip(files);
		}

		function download(name, bytes) {
			const blob = new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = name;
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			setTimeout(() => URL.revokeObjectURL(url), 2000);
		}

		/* ---------------------------- 导出内容 / 全局检索 ---------------------------- */

		const r1 = (x) => Math.round(x * 10) / 10;
		const gradeOf = (amt, pot, coop) => {
			const a = num(amt), p = num(pot), c = num(coop);
			if (p >= 4 && c >= 4) return a >= 5000 ? "A" : "B";
			return a >= 15000 ? "A" : a >= 5000 ? "B" : "C";
		};
		const freqOf = (g) => (g === "A" ? "≥2 次/月" : g === "B" ? "1 次/月" : "1 次/季");
		const statusOf = (task, real) => {
			const t = num(task), x = t ? num(real) / t : 0;
			return x < 0.6 ? "预警" : x < 0.7 ? "关注" : "正常";
		};

		function sheetsFor(tab, db) {
			const add = (name, head, rows) => ({ name, head, rows });
			if (tab === "overview") {
				return [
					add("江苏三段", ["区域", "包含城市", "打法", "资源"], db.segments.map((r) => [r.region, r.cities, r.play, r.resource])),
					add("首月三个决定", ["序号", "决定", "内容"], db.decisions.map((r) => [r.mark, r.title, r.content])),
					add("六步闭环", ["步骤", "时间", "核心动作", "完成的标志"], db.loop.map((r) => [r.step, r.time, r.action, r.done])),
				];
			}
			if (tab === "goal") {
				const rows = [];
				const conv = convOf(db);
				const groups = aggByCity(db);
				const { effCounty } = targetsOf(db);
				groups.forEach((g) => {
					rows.push(["市", g.city.city, g.city.zone, g.items.length, g.n, r1(unitOf(g.n, g.e)), r1(g.e), r1(g.t), r1(g.t - g.e)]);
					g.items.forEach((k) => {
						const e = num(k.n) * num(k.u) * 12 / 10000;
						const kt = effCounty.get(k.id) || 0;
						rows.push(["县区", k.name, g.city.city, "", num(k.n), num(k.u), r1(e), r1(kt), r1(kt - e)]);
					});
				});
				const mix = mixOf(db);
				const catRows = [];
				groups.forEach((g) => {
					mix.cats.forEach((cat) => {
						catRows.push([g.city.city, cat, pct(mix.share[cat] || 0), r1(g.t * (mix.share[cat] || 0)), Math.round(g.t * (mix.share[cat] || 0) * conv)]);
					});
				});
				return [
					add("指标分解", ["层级", "名称", "所属市", "县区数", "终端数", "单产(元/月)", "现有年化(万)", "年目标(万)", "缺口(万)"], rows),
					add("指标分解·大类", ["城市", "大类", "占比", "目标(万)", "目标分"], catRows),
				];
			}
			if (tab === "client") {
				return [
					add("终端台账", ["终端名称", "类别", "类型", "市", "县区", "归属代理/负责人", "电话", "月均购进(元)", "首单日", "最近进货", "复购周期(天)", "应复购", "状态", "等级", "主推产品"],
						db.customers.map((r) => {
							const s = repurchase(r);
							return [r.name, isBig(r) ? "大客户" : "普通", r.type, r.city, r.county, r.agent, r.phone, num(r.amt), r.firstBuy, r.lastBuy, num(r.cycle), s.due, termState(r), gradeOf(r.amt, r.pot, r.coop), r.products];
						})),
					add("本周该跑", ["终端", "市", "县区", "归属代理", "电话", "应复购", "状态", "逾期/剩余天数"],
						db.customers.filter((r) => { const t = termState(r); return t === "逾期" || t === "临近"; })
							.map((r) => ({ r, s: repurchase(r), t: termState(r) }))
							.sort((a, b) => num(a.s.days) - num(b.s.days))
							.map((x) => [x.r.name, x.r.city, x.r.county, x.r.agent, x.r.phone, x.s.due, x.t, Math.abs(num(x.s.days))])),
					add("代理商台账", ["代理商/负责人", "级别", "城市", "负责大类", "覆盖区域", "承接产品", "年度任务(万)", "累计回款(万)", "达成率", "等级", "状态"],
						db.agents.map((r) => {
							const t = num(r.task), x = t ? num(r.real) / t : 0;
							return [r.name, r.role, r.city, String(r.cat || "全部"), r.area, r.scope, t, num(r.real), pct(x), x >= 1 ? "A" : x >= 0.7 ? "B" : "C", statusOf(r.task, r.real)];
						})),
					add("代理与覆盖", ["城市", "大类", "占比", "目标(万)", "负责人", "负责人覆盖区域", "已覆盖县区", "未覆盖县区"],
						(() => {
							const mix = mixOf(db);
							const rows = [];
							aggByCity(db).forEach((g) => {
								mix.cats.forEach((cat) => {
									const cov = catCoverage(db, g.city.city, cat);
									rows.push([
										g.city.city, cat, pct(mix.share[cat] || 0), r1(g.t * (mix.share[cat] || 0)),
										cov.agents.map((a) => a.name + (a.role ? `(${a.role})` : "")).join("、") || "未配置",
										cov.agents.map((a) => a.area || "未填").join("、"),
										cov.covered.length, cov.missing.map((k) => k.name).join("、"),
									]);
								});
							});
							return rows;
						})()),
				];
			}
			if (tab === "weekly") {
				return [
					add("90天排期", ["完成", "周次", "阶段", "关键动作", "交付物"], db.plan.map((r) => [r.done ? "√" : "", r.week, r.stage, r.action, r.output])),
					add("周会六问", ["问题", "目的"], db.weekq.map((r) => [r.q, r.purpose])),
				];
			}
			if (tab === "metric") {
				return [
					add("月度看板", ["月份", "目标(万)", "回款实际(万)", "达成率", "纯销(万)", "库存天数", "活跃终端", "单产(元)"],
						db.board.map((r) => {
							const x = num(r.target) ? num(r.actual) / num(r.target) : 0;
							const u = num(r.active) ? Math.round(num(r.pure) * 10000 / num(r.active)) : "";
							return [r.month, num(r.target), r.actual === "" ? "" : num(r.actual), r.actual === "" ? "" : pct(x), r.pure === "" ? "" : num(r.pure), r.inv === "" ? "" : num(r.inv), r.active === "" ? "" : num(r.active), u];
						})),
					add("指标词典", ["层级", "指标", "算法", "频率", "预警线"], db.metrics.map((r) => [r.level, r.name, r.formula, r.freq, r.warn])),
				];
			}
			if (tab === "product") {
				const conv = convOf(db);
				const base = (db.settings && db.settings.convBase) || "county";
				const catRows = catalogOf(db).map((r) => {
					const ps = (db.products || []).filter((p) => normName(p.name) === normName(r.name));
					const p0 = ps[0] || null;
					return [
						r.cat, r.sub, r.name, r.sell, r.qual, r.spec, r.ing, r.act, r.use,
						p0 ? num(p0.pts) : "", p0 ? num(p0.retail) : "", p0 ? num(p0.supply) : "",
						p0 ? num(p0.county) : "", p0 ? num(p0.region) : "",
						p0 ? r1(num(p0.supply) - num(p0.county)) : "",
						p0 ? "已录价" : "待录价",
					];
				});
				return [add("产品目录", ["大类", "小类", "品种", "一句话卖点", "资质", "全部规格", "主要成份", "功能主治", "用法用量", "分值", "零售价", "给终端价", "县区价", "地区价", "县区毛利", "价格状态"], catRows),
					add("产品价格与分值", ["产品", "规格", "分值", "零售价", "给终端价", "县区价", "地区价", "使用天数", "县区自营毛利", "县区毛利率", "地区自营毛利", "地区分销毛利", "县区扣", "地区扣", "分/万元"],
					db.products.map((p) => {
						const s = num(p.supply), c = num(p.county), rg = num(p.region);
						return [
							p.name, p.spec, num(p.pts), num(p.retail), s, c, rg, p.days,
							r1(s - c), s ? pct((s - c) / s) : "",
							r1(s - rg), r1(c - rg),
							s ? Math.round((c / s) * 100) : "", s ? Math.round((rg / s) * 100) : "",
							convBasePrice(p, base) ? Math.round((num(p.pts) / convBasePrice(p, base)) * 10000) : "",
						];
					}).concat([["", "", "", "", "", "", "", "换算", "", "", "", "", "", "", `${Math.round(conv)} 分/万元`]]))];
			}
			if (tab === "visit") {
				const only = bigVisitsOf(db);
				return [add("拜访记录", ["日期", "终端", "市", "县区", "归属代理", "方式", "结果", "备注", "下次跟进"],
					only.slice().sort((a, b) => String(b.date || "").localeCompare(String(a.date || ""))).map((v) => [v.date, v.terminal, v.city, v.county, v.agent, v.method, v.result, v.note, v.next]))];
			}
			if (tab === "risk") {
				const risks = risksOf(db);
				return [
					add("风险清单", ["级别", "对象", "问题", "建议动作"], risks.map((r) => [r.level, r.who, r.what, r.how])),
					add("行动项", ["负责人", "动作", "截止", "状态", "结果"], (db.actions || []).map((a) => [a.owner, a.action, a.due, a.status, a.result])),
				];
			}
			return [
				add("会议节奏", ["会议", "频率", "时长", "议程", "参会人"], db.meetings.map((r) => [r.name, r.freq, r.dur, r.agenda, r.who])),
				add("月度八张表", ["序", "表", "要看的问题"], db.month8.map((r) => [r.no, r.name, r.question])),
				add("一省一策", ["模块", "要回答的问题", "我的答案"], db.strategy.map((r) => [r.module, r.question, r.answer])),
				add("一省一策-总纲", ["项目", "内容"], [
					["一句话战略", db.oneplan.strategy],
					["三个必须赢的战役", db.oneplan.battles],
					["三条不能碰的红线", db.oneplan.redlines],
				]),
			];
		}

		function searchSources(db) {
			return [
				{ tab: "overview", label: "江苏三段", rows: db.segments, title: (r) => r.region, cols: ["region", "cities", "play", "resource"] },
				{ tab: "overview", label: "首月决定", rows: db.decisions, title: (r) => r.title, cols: ["mark", "title", "content"] },
				{ tab: "overview", label: "六步闭环", rows: db.loop, title: (r) => r.step, cols: ["step", "time", "action", "done"] },
				{ tab: "goal", label: "指标分解", rows: db.cities, title: (r) => r.city, cols: ["city", "zone", "n", "u", "t"] },
				{ tab: "client", label: "终端台账", rows: db.customers, title: (r) => r.name, cols: ["name", "type", "city", "county", "agent", "phone", "products", "lastBuy", "cycle"] },
				{ tab: "visit", label: "拜访记录", rows: db.visits || [], title: (r) => (r.terminal || "") + " " + (r.date || ""), cols: ["date", "terminal", "city", "county", "method", "result", "note", "next"] },
				{ tab: "client", label: "代理商台账", rows: db.agents, title: (r) => r.name, cols: ["name", "role", "city", "cat", "area", "scope", "task", "real"] },
				{ tab: "product", label: "品种目录", rows: db.catalog || [], title: (r) => r.name, cols: ["cat", "sub", "sell", "qual", "ing", "act"] },
				{ tab: "product", label: "产品价格", rows: db.products, title: (r) => r.name, cols: ["name", "spec", "pts", "supply", "county", "region"] },
				{ tab: "weekly", label: "90 天排期", rows: db.plan, title: (r) => r.week + " " + r.stage, cols: ["week", "stage", "action", "output"] },
				{ tab: "weekly", label: "周会六问", rows: db.weekq, title: (r) => r.q, cols: ["q", "purpose"] },
				{ tab: "metric", label: "月度看板", rows: db.board, title: (r) => r.month, cols: ["month", "target", "actual", "pure", "inv", "active"] },
				{ tab: "metric", label: "指标词典", rows: db.metrics, title: (r) => r.name, cols: ["level", "name", "formula", "freq", "warn"] },
				{ tab: "review", label: "会议节奏", rows: db.meetings, title: (r) => r.name, cols: ["name", "freq", "dur", "agenda", "who"] },
				{ tab: "review", label: "月度八张表", rows: db.month8, title: (r) => r.name, cols: ["no", "name", "question"] },
				{ tab: "review", label: "一省一策", rows: db.strategy, title: (r) => r.module, cols: ["module", "question", "answer"] },
			];
		}

		function GlobalSearch({ db, onGo }) {
			const [q, setQ] = useState("");
			const [focus, setFocus] = useState(false);

			const hits = useMemo(() => {
				const s = q.trim().toLowerCase();
				if (!s) return [];
				const out = [];
				searchSources(db).forEach((src) => {
					src.rows.forEach((r) => {
						const hay = src.cols.map((k) => String(r[k] == null ? "" : r[k])).join(" ").toLowerCase();
						if (hay.indexOf(s) >= 0) {
							out.push({
								key: src.tab + ":" + src.label + ":" + r.id,
								tab: src.tab,
								label: src.label,
								title: String(src.title(r) || "（未命名）"),
								text: src.cols.map((k) => String(r[k] == null ? "" : r[k])).filter(Boolean).slice(0, 3).join(" · "),
							});
						}
					});
				});
				return out.slice(0, 40);
			}, [q, db]);

			const open = focus && q.trim().length > 0;

			return h("div", { style: { position: "relative" } },
				h("input", {
					value: q,
					placeholder: "全局搜索：城市 / 客户 / 会议 / 指标…",
					onChange: (e) => setQ(e.target.value),
					onFocus: () => setFocus(true),
					onBlur: () => setTimeout(() => setFocus(false), 150),
					style: {
						width: 280, padding: "6px 11px", border: `1px solid ${C.line}`, borderRadius: 8,
						fontSize: 12.5, fontFamily: FONT, outline: "none", background: "#fff", color: C.ink,
					},
				}),
				open ? h("div", {
					style: {
						position: "absolute", top: "calc(100% + 6px)", right: 0, width: 420, maxHeight: 380, overflow: "auto",
						background: "#fff", border: `1px solid ${C.line}`, borderRadius: 10,
						boxShadow: "0 12px 32px rgba(16,24,40,.14)", zIndex: 50, padding: 6,
					},
				},
					hits.length === 0
						? h("div", { style: { padding: "12px", color: C.sub, fontSize: 12.5 } }, "没有匹配的内容")
						: hits.map((x) => h("div", {
							key: x.key,
							onMouseDown: (e) => e.preventDefault(),
							onClick: () => { onGo(x.tab); setQ(""); },
							style: { padding: "7px 10px", borderRadius: 7, cursor: "pointer" },
							onMouseEnter: (e) => { e.currentTarget.style.background = C.soft; },
							onMouseLeave: (e) => { e.currentTarget.style.background = "transparent"; },
						},
							h("div", { style: { fontSize: 12.5, fontWeight: 600 } }, x.title),
							h("div", { style: { fontSize: 11.5, color: C.sub, marginTop: 1 } }, `${x.label} · ${x.text}`))))
					: null);
		}

		/* ---------------------------- 数据导入 ---------------------------- */

		/** 解 xlsx 的 zip 目录（用 DecompressionStream 处理 deflate） */
		async function unzip(u8) {
			const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
			let eo = -1;
			for (let i = u8.length - 22; i >= Math.max(0, u8.length - 70000); i--) {
				if (u8[i] === 0x50 && u8[i + 1] === 0x4b && u8[i + 2] === 0x05 && u8[i + 3] === 0x06) { eo = i; break; }
			}
			if (eo < 0) throw new Error("不是有效的 xlsx 文件");
			const count = dv.getUint16(eo + 10, true);
			let off = dv.getUint32(eo + 16, true);
			const map = {};
			for (let i = 0; i < count; i++) {
				const nameLen = dv.getUint16(off + 28, true);
				const extraLen = dv.getUint16(off + 30, true);
				const cmtLen = dv.getUint16(off + 32, true);
				const method = dv.getUint16(off + 10, true);
				const csize = dv.getUint32(off + 20, true);
				const localOff = dv.getUint32(off + 42, true);
				const name = new TextDecoder().decode(u8.subarray(off + 46, off + 46 + nameLen));
				const lnameLen = dv.getUint16(localOff + 26, true);
				const lextraLen = dv.getUint16(localOff + 28, true);
				const start = localOff + 30 + lnameLen + lextraLen;
				map[name] = { method, data: u8.subarray(start, start + csize) };
				off += 46 + nameLen + extraLen + cmtLen;
			}
			return map;
		}

		async function entryText(entry) {
			if (!entry) return "";
			if (entry.method === 0) return new TextDecoder().decode(entry.data);
			const ds = new DecompressionStream("deflate-raw");
			const stream = new Blob([entry.data]).stream().pipeThrough(ds);
			const buf = await new Response(stream).arrayBuffer();
			return new TextDecoder().decode(new Uint8Array(buf));
		}

		const unxml = (s) => String(s)
			.replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
			.replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
			.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");

		/** 读第一个工作表，返回二维数组 */
		async function readXlsx(arrayBuffer) {
			const files = await unzip(new Uint8Array(arrayBuffer));
			const sheetName = Object.keys(files).filter((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n)).sort()[0];
			if (!sheetName) throw new Error("没找到工作表");
			const shared = [];
			if (files["xl/sharedStrings.xml"]) {
				const xml = await entryText(files["xl/sharedStrings.xml"]);
				const re = /<si>([\s\S]*?)<\/si>/g;
				let m;
				while ((m = re.exec(xml))) {
					const ts = [];
					const re2 = /<t[^>]*>([\s\S]*?)<\/t>/g;
					let m2;
					while ((m2 = re2.exec(m[1]))) ts.push(unxml(m2[1]));
					shared.push(ts.join(""));
				}
			}
			const sheet = await entryText(files[sheetName]);
			const rows = [];
			const rowRe = /<row[^>]*>([\s\S]*?)<\/row>/g;
			let rm;
			while ((rm = rowRe.exec(sheet))) {
				const cells = [];
				const cellRe = /<c r="([A-Z]+)(\d+)"([^>]*)\/>|<c r="([A-Z]+)(\d+)"([^>]*)>([\s\S]*?)<\/c>/g;
				let cm;
				while ((cm = cellRe.exec(rm[1]))) {
					const col = cm[1] || cm[4];
					const idx = col.split("").reduce((a, ch) => a * 26 + (ch.charCodeAt(0) - 64), 0) - 1;
					const attrs = cm[3] || cm[6] || "";
					const inner = cm[7] || "";
					let val = "";
					if (/t="s"/.test(attrs)) {
						const vm = /<v>([\s\S]*?)<\/v>/.exec(inner);
						val = vm ? shared[Number(vm[1])] || "" : "";
					} else if (/t="inlineStr"/.test(attrs)) {
						const tm = /<t[^>]*>([\s\S]*?)<\/t>/.exec(inner);
						val = tm ? unxml(tm[1]) : "";
					} else {
						const vm = /<v>([\s\S]*?)<\/v>/.exec(inner);
						val = vm ? unxml(vm[1]) : "";
					}
					while (cells.length < idx) cells.push("");
					cells[idx] = val;
				}
				if (cells.some((c) => String(c).trim() !== "")) rows.push(cells);
			}
			return rows;
		}

		/** 解析粘贴的表格（制表符或逗号），返回二维数组 */
		function parsePaste(text) {
			return String(text || "")
				.replace(/\r/g, "")
				.split("\n")
				.filter((line) => line.trim() !== "")
				.map((line) => (line.indexOf("\t") >= 0 ? line.split("\t") : line.split(",")).map((c) => c.trim()));
		}

		/** 只覆盖非空字段，空值保留原值；id 不变 */
		function mergeRow(cur, next, fields) {
			const out = Object.assign({}, cur);
			fields.forEach((f) => {
				const v = next[f];
				if (v !== undefined && v !== null && String(v).trim() !== "") out[f] = v;
			});
			return out;
		}

		/** 追加并更新：按 key 匹配，命中就覆盖非空字段，没命中就新增 */
		function upsertRows(existing, incoming, keyOf, fields) {
			const map = new Map();
			existing.forEach((r) => map.set(keyOf(r), r));
			let added = 0, updated = 0;
			incoming.forEach((n) => {
				if (!keyOf(n)) return;
				const cur = map.get(keyOf(n));
				if (cur) {
					map.set(keyOf(n), mergeRow(cur, n, fields));
					updated++;
				} else {
					map.set(keyOf(n), n);
					added++;
				}
			});
			return { list: Array.from(map.values()), added, updated };
		}

		const IMPORT_TARGETS = [
			{
				key: "counties", label: "指标分解 · 县区", cols: "市名 / 县区名 / 终端数 / 单产 / 年目标",
				note: "按「市 + 县区」匹配，同名的只改非空列",
				apply: (db, rows, mode) => {
					const byName = new Map(db.cities.map((c) => [String(c.city).trim(), c.id]));
					const list = [];
					let skipped = 0;
					rows.forEach((r) => {
						const cityId = byName.get(String(r[0] || "").trim());
						const name = String(r[1] || "").trim();
						if (!cityId || !name) { skipped++; return; }
						list.push({ id: nid(), city: cityId, name, n: String(r[2] == null ? "" : r[2]), u: String(r[3] == null ? "" : r[3]), t: String(r[4] == null ? "" : r[4]) });
					});
					if (mode === "replace") return { db: Object.assign({}, db, { counties: list }), added: list.length, updated: 0, skipped };
					const res = upsertRows(db.counties, list, (o) => o.city + "|" + String(o.name).trim(), ["n", "u", "t"]);
					return { db: Object.assign({}, db, { counties: res.list }), added: res.added, updated: res.updated, skipped };
				},
			},
			{
				key: "customers", label: "终端台账", cols: "终端 / 类型 / 市 / 县区 / 归属代理 / 电话 / 月均购进 / 潜力 / 配合度 / 主推产品 / 首单日 / 最近进货 / 复购周期",
				note: "按终端名匹配；市/县区要跟你基础数据里的名字一致",
				apply: (db, rows, mode) => {
					const list = rows.map((r) => ({
						id: nid(), name: String(r[0] || "").trim(), type: r[1] || "",
						city: String(r[2] || ""), county: String(r[3] || ""), agent: String(r[4] || ""),
						phone: String(r[5] || ""), amt: String(r[6] == null ? "" : r[6]),
						pot: String(r[7] == null ? "" : r[7]), coop: String(r[8] == null ? "" : r[8]),
						products: String(r[9] || ""), firstBuy: String(r[10] || ""), lastBuy: String(r[11] || ""), cycle: String(r[12] || ""),
					})).filter((o) => o.name);
					if (mode === "replace") return { db: Object.assign({}, db, { customers: list }), added: list.length, updated: 0, skipped: rows.length - list.length };
					const res = upsertRows(db.customers, list, (o) => String(o.name).trim(), ["type", "city", "county", "agent", "phone", "amt", "pot", "coop", "products", "firstBuy", "lastBuy", "cycle"]);
					return { db: Object.assign({}, db, { customers: res.list }), added: res.added, updated: res.updated, skipped: rows.length - list.length };
				},
			},
			{
				key: "agents", label: "代理商台账", cols: "代理商 / 级别 / 城市 / 负责大类 / 覆盖区域 / 承接产品 / 年度任务 / 累计回款",
				note: "按代理商名匹配；负责大类写「全部」或「骨科,皮肤」；区域写「全市」或具体县区，多个用逗号隔开",
				apply: (db, rows, mode) => {
					const list = rows.map((r) => ({
						id: nid(), name: String(r[0] || "").trim(), role: r[1] || "县区", city: String(r[2] || ""),
						cat: String(r[3] || "全部"), area: String(r[4] || "全市"), scope: String(r[5] || "全部"),
						task: String(r[6] == null ? "" : r[6]), real: String(r[7] == null ? "" : r[7]),
					})).filter((o) => o.name);
					if (mode === "replace") return { db: Object.assign({}, db, { agents: list }), added: list.length, updated: 0, skipped: rows.length - list.length };
					const res = upsertRows(db.agents, list, (o) => String(o.name).trim(), ["role", "city", "cat", "area", "scope", "task", "real"]);
					return { db: Object.assign({}, db, { agents: res.list }), added: res.added, updated: res.updated, skipped: rows.length - list.length };
				},
			},
			{
				key: "board", label: "月度看板", cols: "月份 / 目标 / 回款 / 纯销 / 库存天数 / 活跃终端",
				note: "按月份匹配——比如二月这行只改回款，其他列不动",
				apply: (db, rows, mode) => {
					const list = rows.map((r) => ({ id: nid(), month: String(r[0] || "").trim(), target: String(r[1] == null ? "" : r[1]), actual: String(r[2] == null ? "" : r[2]), pure: String(r[3] == null ? "" : r[3]), inv: String(r[4] == null ? "" : r[4]), active: String(r[5] == null ? "" : r[5]) })).filter((o) => o.month);
					if (mode === "replace") return { db: Object.assign({}, db, { board: list }), added: list.length, updated: 0, skipped: rows.length - list.length };
					const res = upsertRows(db.board, list, (o) => String(o.month).trim(), ["target", "actual", "pure", "inv", "active"]);
					return { db: Object.assign({}, db, { board: res.list }), added: res.added, updated: res.updated, skipped: rows.length - list.length };
				},
			},
			{
				key: "metrics", label: "指标词典", cols: "层级 / 指标 / 算法 / 频率 / 预警线",
				note: "按「层级 + 指标」匹配",
				apply: (db, rows, mode) => {
					const list = rows.map((r) => ({ id: nid(), level: r[0] || "", name: String(r[1] || "").trim(), formula: r[2] || "", freq: r[3] || "", warn: r[4] || "" })).filter((o) => o.name);
					if (mode === "replace") return { db: Object.assign({}, db, { metrics: list }), added: list.length, updated: 0, skipped: rows.length - list.length };
					const res = upsertRows(db.metrics, list, (o) => String(o.level || "").trim() + "|" + String(o.name).trim(), ["formula", "freq", "warn"]);
					return { db: Object.assign({}, db, { metrics: res.list }), added: res.added, updated: res.updated, skipped: rows.length - list.length };
				},
			},
			{
				key: "catalog", label: "品种目录", cols: "大类 / 小类 / 品种 / 一句话卖点 / 资质 / 全部规格 / 主要成份 / 功能主治 / 用法用量",
				note: "按「品种名」匹配——同名视为同一品种，填了的列才覆盖",
				apply: (db, rows, mode) => {
					const list = rows.map((r) => ({
						id: nid(), cat: String(r[0] || "").trim(), sub: String(r[1] || "").trim(),
						name: String(r[2] || "").trim(), sell: r[3] || "", qual: r[4] || "",
						spec: r[5] || "", ing: r[6] || "", act: r[7] || "", use: r[8] || "",
					})).filter((o) => o.name);
					if (mode === "replace") return { db: Object.assign({}, db, { catalog: list }), added: list.length, updated: 0, skipped: rows.length - list.length };
					const res = upsertRows(db.catalog || [], list, (o) => normName(o.name), ["cat", "sub", "sell", "qual", "spec", "ing", "act", "use"]);
					return { db: Object.assign({}, db, { catalog: res.list }), added: res.added, updated: res.updated, skipped: rows.length - list.length };
				},
			},
			{
				key: "products", label: "产品价格", cols: "产品 / 规格 / 分值 / 零售价 / 供货价 / 县区价 / 地区价 / 使用天数",
				note: "按「产品 + 规格」匹配——同名不同规格算两个产品",
				apply: (db, rows, mode) => {
					const list = rows.map((r) => ({
						id: nid(), name: String(r[0] || "").trim(), spec: String(r[1] || "").trim(),
						pts: String(r[2] == null ? "" : r[2]), retail: String(r[3] == null ? "" : r[3]),
						supply: String(r[4] == null ? "" : r[4]), county: String(r[5] == null ? "" : r[5]),
						region: String(r[6] == null ? "" : r[6]), days: String(r[7] || ""),
					})).filter((o) => o.name);
					if (mode === "replace") return { db: Object.assign({}, db, { products: list }), added: list.length, updated: 0, skipped: rows.length - list.length };
					const res = upsertRows(db.products, list, (o) => String(o.name).trim() + "|" + String(o.spec).trim(), ["pts", "retail", "supply", "county", "region", "days"]);
					return { db: Object.assign({}, db, { products: res.list }), added: res.added, updated: res.updated, skipped: rows.length - list.length };
				},
			},
			{
				key: "strategy", label: "一省一策", cols: "模块 / 问题 / 答案",
				note: "按模块名匹配",
				apply: (db, rows, mode) => {
					const list = rows.map((r) => ({ id: nid(), module: String(r[0] || "").trim(), question: r[1] || "", answer: r[2] || "" })).filter((o) => o.module);
					if (mode === "replace") return { db: Object.assign({}, db, { strategy: list }), added: list.length, updated: 0, skipped: rows.length - list.length };
					const res = upsertRows(db.strategy, list, (o) => String(o.module).trim(), ["question", "answer"]);
					return { db: Object.assign({}, db, { strategy: res.list }), added: res.added, updated: res.updated, skipped: rows.length - list.length };
				},
			},
		];

		function Modal({ title, onClose, width, children, footer }) {
			return h("div", {
				style: { position: "fixed", inset: 0, background: "rgba(16,24,40,.38)", zIndex: 200, display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "48px 16px", overflow: "auto" },
				onMouseDown: (e) => { if (e.target === e.currentTarget) onClose(); },
			},
				h("div", { style: { width: width || 720, maxWidth: "100%", background: "#fff", borderRadius: 12, boxShadow: "0 18px 48px rgba(16,24,40,.24)", overflow: "hidden" } },
					h("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 18px", borderBottom: `1px solid ${C.line}` } },
						h("div", { style: { fontSize: 14, fontWeight: 650 } }, title),
						h("button", { onClick: onClose, style: { appearance: "none", border: "none", background: "transparent", fontSize: 16, color: C.sub, cursor: "pointer" } }, "✕")),
					h("div", { style: { padding: "14px 18px", maxHeight: "62vh", overflow: "auto" } }, children),
					footer ? h("div", { style: { padding: "11px 18px", borderTop: `1px solid ${C.line}`, display: "flex", justifyContent: "flex-end", gap: 8, background: "#fcfcfd" } }, footer) : null));
		}

		/** 多选取值：value 是逗号串，opt 是刚点的那个，allLabel 是「全市 / 全部」这种全选值 */
		function pickToggle(value, opt, allLabel) {
			const parts = String(value || "").split(/[,，、/\s]+/).map((x) => x.trim()).filter(Boolean);
			const isAll = parts.indexOf(allLabel) >= 0;
			if (opt === allLabel) return isAll ? "" : allLabel;
			if (isAll) return opt;
			return (parts.indexOf(opt) >= 0 ? parts.filter((x) => x !== opt) : parts.concat([opt])).join(",");
		}

		/** 多选面板：勾选县区 / 大类，也能直接手输一串 */
		function MultiPicker({ title, note, options, value, allLabel, onChange, onClose }) {
			const parts = String(value || "").split(/[,，、/\s]+/).map((x) => x.trim()).filter(Boolean);
			const isAll = parts.indexOf(allLabel) >= 0;
			const chip = (label, on, onClick, key) => h("button", {
				key: key || label,
				onClick,
				style: {
					appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 12,
					padding: "4px 11px", borderRadius: 999,
					border: `1px solid ${on ? C.accent : C.line}`,
					background: on ? C.accentSoft : "#fff", color: on ? C.accent : C.sub,
				},
			}, label);
			return h(Modal, {
				title,
				onClose,
				width: 640,
				footer: h("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
					h("span", { style: { marginRight: "auto", fontSize: 12, color: C.sub } }, "勾一下即时保存，关闭即生效"),
					h("button", { onClick: onClose, style: Object.assign({}, S.add, { margin: 0, borderColor: C.accent, color: C.accent }) }, "完成")),
			},
				note ? h("div", { style: { fontSize: 12, color: C.sub, marginBottom: 10, lineHeight: 1.7 } }, note) : null,
				h("div", { style: { display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap", marginBottom: 10 } },
					chip(allLabel, isAll, () => onChange(pickToggle(value, allLabel, allLabel))),
					chip("全选所有项", false, () => onChange(options.filter((o) => o !== allLabel).join(","))),
					chip("清空", false, () => onChange("")),
					h("span", { style: { marginLeft: "auto", fontSize: 11.5, color: C.sub } }, isAll ? `全选（${allLabel}）` : `已选 ${parts.length} 个`)),
				h("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(118px, 1fr))", gap: 6, marginBottom: 12 } },
					options.filter((o) => o !== allLabel).map((o) => h("label", {
						key: o,
						style: {
							display: "flex", alignItems: "center", gap: 5, fontSize: 12, padding: "5px 8px",
							border: `1px solid ${isAll || parts.indexOf(o) >= 0 ? C.accent : C.line}`, borderRadius: 8,
							background: isAll || parts.indexOf(o) >= 0 ? C.accentSoft : "#fff", cursor: "pointer",
						},
					},
						h("input", { type: "checkbox", checked: isAll || parts.indexOf(o) >= 0, onChange: () => onChange(pickToggle(value, o, allLabel)) }),
						o))),
				h("div", { style: { fontSize: 11.5, color: C.sub, marginBottom: 4 } }, "也可以直接手输（逗号分隔）："),
				h("input", {
					value: String(value || ""),
					placeholder: allLabel + " 或 玄武区,秦淮区",
					onChange: (e) => onChange(e.target.value),
					style: { width: "100%", padding: "7px 10px", border: `1px solid ${C.line}`, borderRadius: 8, fontSize: 12.5, fontFamily: FONT, boxSizing: "border-box", outline: "none" },
				}),
				h("div", { style: { fontSize: 11.5, color: C.sub, marginTop: 8 } },
					`当前：${String(value || "").trim() || "（空）"}`));
		}


		/** 数据同步：产品目录 / 产品价格 / 分值换算，两个插件之间来回搬 */
		function SyncDialog({ db, setDb, onClose }) {
			const other = readOtherStore();
			const [scopes, setScopes] = useState({ catalog: true, products: true, settings: false });
			const [msg, setMsg] = useState("");
			const [pending, setPending] = useState(null); // "pull" | "push"

			const otherCatalog = other && Array.isArray(other.catalog) ? other.catalog.length : 0;
			const otherProducts = other && Array.isArray(other.products) ? other.products.length : 0;
			const mineCatalog = (db.catalog || []).length;
			const mineProducts = (db.products || []).length;
			const otherConv = (() => { try { return other ? convOf(other) : 0; } catch (e) { return 0; } })();
			const myConv = convOf(db);

			const toggle = (k) => setScopes(Object.assign({}, scopes, { [k]: !scopes[k] }));
			const row = (k, label, detail) => h("label", {
				style: {
					display: "flex", alignItems: "flex-start", gap: 8, padding: "8px 10px", cursor: "pointer",
					border: `1px solid ${scopes[k] ? C.accent : C.line}`, borderRadius: 8,
					background: scopes[k] ? C.accentSoft : "#fff", marginBottom: 6,
				},
			},
				h("input", { type: "checkbox", checked: !!scopes[k], onChange: () => toggle(k), style: { marginTop: 2 } }),
				h("div", null,
					h("div", { style: { fontSize: 12.5, fontWeight: 600 } }, label),
					h("div", { style: { fontSize: 11.5, color: C.sub, marginTop: 1 } }, detail)));

			const pull = () => {
				if (!other) { setMsg("读不到旧版数据：先在左侧栏打开一次「江苏经营」旧版，再回来同步"); return; }
				if (pending !== "pull") { setPending("pull"); setMsg("会把当前插件这三块数据覆盖成旧版的，再点一次「确认拉取」"); return; }
				setPending(null);
				setDb((d) => mergeProductData(d, other, scopes));
				setMsg("已从旧版拉过来，当前插件立即生效");
			};

			const push = () => {
				if (pending !== "push") { setPending("push"); setMsg("会把旧版这三块数据覆盖成当前的，再点一次「确认推送」"); return; }
				setPending(null);
				try {
					const raw = window.localStorage.getItem(OTHER_STORE_KEY);
					if (!raw) { setMsg("旧版还没有数据：先打开一次「江苏经营」旧版"); return; }
					const base = JSON.parse(raw);
					const next = Object.assign({}, base);
					if (scopes.catalog) next.catalog = (db.catalog || []).map((r) => Object.assign({}, r));
					if (scopes.products) next.products = (db.products || []).map((r) => Object.assign({}, r));
					if (scopes.settings) {
						next.settings = Object.assign({}, base.settings, {
							conv: db.settings.conv, convBase: db.settings.convBase, catMix: db.settings.catMix,
						});
					}
					window.localStorage.setItem(OTHER_STORE_KEY, JSON.stringify(next));
					setMsg("已写入旧版。旧版要刷新页面才看得到；在它刷新之前，旧版的下一次修改会把这次推送盖回去");
				} catch (e) {
					setMsg("写入失败：" + (e && e.message ? e.message : e));
				}
			};

			return h(Modal, {
				title: "数据同步 · 产品",
				onClose,
				width: 660,
				footer: h("div", { style: { display: "flex", gap: 8 } },
					h("button", { onClick: onClose, style: Object.assign({}, S.add) }, "关闭"),
					h("button", { onClick: pull, style: Object.assign({}, S.add, { borderColor: C.accent, color: C.accent }) }, pending === "pull" ? "确认拉取" : "从旧版拉到当前"),
					h("button", { onClick: push, style: Object.assign({}, S.add, { borderColor: C.warn, color: C.warn }) }, pending === "push" ? "确认推送" : "把当前的推给旧版")),
			},
				h("div", { style: { fontSize: 12.5, lineHeight: 1.8, color: "#374151", marginBottom: 10 } },
					"两个插件（旧版「江苏经营」/ 当前「江苏经营 V2」）各存各的数据。这里只搬产品相关的三块，市 / 县区 / 客户 / 代理 / 终端这些都不动。"),
				other
					? h("table", { style: S.table },
						h("thead", null, h("tr", null,
							["内容", "旧版", "当前 V2", "是否一致"].map((t, i) => h("th", { key: i, style: S.th }, t)))),
						h("tbody", null,
							h("tr", null,
								h("td", { style: S.td }, "品种目录"),
								h("td", { style: S.td }, otherCatalog + " 个品种"),
								h("td", { style: S.td }, mineCatalog + " 个品种"),
								h("td", { style: Object.assign({}, S.td, { color: otherCatalog === mineCatalog ? C.ok : "#8a6d00" }) }, otherCatalog === mineCatalog ? "一致" : "不一致")),
							h("tr", null,
								h("td", { style: S.td }, "产品价格"),
								h("td", { style: S.td }, otherProducts + " 个品规"),
								h("td", { style: S.td }, mineProducts + " 个品规"),
								h("td", { style: Object.assign({}, S.td, { color: otherProducts === mineProducts ? C.ok : "#8a6d00" }) }, otherProducts === mineProducts ? "一致" : "不一致")),
							h("tr", null,
								h("td", { style: S.td }, "分值换算"),
								h("td", { style: S.td }, fmt(otherConv, 0) + " 分/万元"),
								h("td", { style: S.td }, fmt(myConv, 0) + " 分/万元"),
								h("td", { style: Object.assign({}, S.td, { color: Math.round(otherConv) === Math.round(myConv) ? C.ok : "#8a6d00" }) },
									Math.round(otherConv) === Math.round(myConv) ? "一致" : "不一致"))))
					: h("div", { style: { padding: "10px 12px", border: `1px solid ${C.line}`, borderRadius: 8, background: "#fffdf5", fontSize: 12.5, color: "#8a6d00", marginBottom: 10 } },
						"读不到旧版数据（可能还没打开过旧版插件）。先在左侧栏打开一次「江苏经营」，再回来点同步。"),
				h("div", { style: { fontSize: 12, color: C.sub, margin: "10px 0 6px" } }, "要同步哪几块："),
				row("catalog", "品种目录", "大类 / 小类 / 品种 / 资质 / 规格 / 成份 / 主治 / 用法（" + otherCatalog + " 条）"),
				row("products", "产品价格", "分值 / 零售价 / 给终端价 / 县区价 / 地区价 / 天数（" + otherProducts + " 条）"),
				row("settings", "分值换算设置", "分/万元 的覆盖值、按哪个价折算、大类占比"),
				msg ? h("div", { style: { fontSize: 12, color: C.warn, marginTop: 8, lineHeight: 1.7 } }, msg) : null);
		}

		function ImportDialog({ db, setDb, onClose }) {
			const [target, setTarget] = useState(IMPORT_TARGETS[0].key);
			const [mode, setMode] = useState("upsert");
			const [text, setText] = useState("");
			const [rows, setRows] = useState(null);
			const [msg, setMsg] = useState("");
			const [confirmReplace, setConfirmReplace] = useState(false);
			const spec = IMPORT_TARGETS.filter((t) => t.key === target)[0];

			const doParse = (rs) => {
				const body = rs.filter((r) => r.some((c) => String(c).trim() !== ""));
				if (!body.length) { setMsg("没有读到数据"); setRows(null); return; }
				// 首行如果像表头（含「终端」「客户」「名称」等字样）就跳过
				const first = body[0].join("");
				const looksHeader = /终端数|量|目标|名称|客户|代理商|月份|层级|模块|指标/.test(first) && body.length > 1;
				const data = looksHeader ? body.slice(1) : body;
				setRows(data);
				setMsg(`读到 ${data.length} 行 × ${Math.max.apply(null, data.map((r) => r.length))} 列`);
			};

			const pickFile = () => {
				const input = document.createElement("input");
				input.type = "file";
				input.accept = ".xlsx";
				input.onchange = async () => {
					const f = input.files && input.files[0];
					if (!f) return;
					try {
						const buf = await f.arrayBuffer();
						const rs = await readXlsx(buf);
						doParse(rs);
					} catch (e) {
						setMsg("读取失败：" + (e && e.message ? e.message : e));
					}
				};
				input.click();
			};

			const commit = () => {
				if (!rows || !rows.length) { setMsg("先读取或粘贴数据"); return; }
				// 整表替换会清掉原数据，必须再点一次确认
				if (mode === "replace" && !confirmReplace) {
					setConfirmReplace(true);
					setMsg("「整表替换」会先清空这张表的现有数据，再点一次底部的「确认整表替换」才会执行");
					return;
				}
				setConfirmReplace(false);
				const res = spec.apply(db, rows, mode);
				setDb(res.db);
				const parts = [];
				if (res.added) parts.push(`新增 ${res.added} 行`);
				if (res.updated) parts.push(`更新 ${res.updated} 行`);
				if (res.skipped) parts.push(`跳过 ${res.skipped} 行`);
				setMsg((parts.length ? parts.join("，") : "没有变化") + (mode === "replace" ? "（整表已替换）" : "（同名已合并，未填的列保留原值）"));
				setRows(null);
			};

			return h(Modal, {
				title: "导入数据",
				onClose,
				width: 760,
				footer: h("div", { style: { display: "flex", gap: 8 } },
					h("button", { onClick: onClose, style: Object.assign({}, S.add) }, "关闭"),
					h("button", {
						onClick: commit,
						style: Object.assign({}, S.add, {
							borderColor: mode === "replace" && confirmReplace ? C.warn : C.accent,
							color: mode === "replace" && confirmReplace ? C.warn : C.accent,
						}),
					}, mode === "replace"
						? (confirmReplace ? "确认整表替换（不可撤销）" : "确认导入（整表替换）")
						: "确认导入（追加并更新）")),
			},
				h("div", { style: { fontSize: 12.5, color: C.sub, marginBottom: 10 } },
					"两种方式：① 在 Excel 里选中区域复制，粘到下面；② 直接选 .xlsx 文件（读第一个工作表）。第一行如果是表头会自动跳过。"),
				h("div", { style: { display: "flex", gap: 8, alignItems: "center", marginBottom: 8, flexWrap: "wrap" } },
					h("select", {
						value: target,
						onChange: (e) => { setTarget(e.target.value); setRows(null); setMsg(""); setConfirmReplace(false); },
						style: { padding: "6px 9px", border: `1px solid ${C.line}`, borderRadius: 8, fontSize: 12.5, fontFamily: FONT, background: "#fff" },
					}, IMPORT_TARGETS.map((t) => h("option", { key: t.key, value: t.key }, t.label))),
					h("button", { onClick: pickFile, style: Object.assign({}, S.add) }, "选择 .xlsx 文件"),
					h("span", { style: { fontSize: 12, color: C.sub } }, "列顺序：" + spec.cols)),
				h("div", { style: { display: "flex", gap: 6, alignItems: "center", marginBottom: 4, flexWrap: "wrap" } },
					[["upsert", "追加并更新"], ["replace", "整表替换"]].map(([k, label]) => h("button", {
						key: k,
						onClick: () => { setMode(k); setConfirmReplace(false); setMsg(""); },
						style: {
							appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 12,
							padding: "4px 11px", borderRadius: 999, border: `1px solid ${mode === k ? C.accent : C.line}`,
							background: mode === k ? C.accentSoft : "#fff", color: mode === k ? C.accent : C.sub,
						},
					}, label)),
					h("span", { style: { fontSize: 11.5, color: C.sub } },
						mode === "upsert" ? `匹配规则：${spec.note}；空单元格不覆盖原值` : "危险：会用导入内容替换整张表")),
				h("textarea", {
					value: text,
					placeholder: "从 Excel 复制后 Ctrl+V 到这里（制表符分隔），或用逗号分隔",
					onChange: (e) => setText(e.target.value),
					onPaste: (e) => {
						const t = e.clipboardData && e.clipboardData.getData("text");
						if (t) { e.preventDefault(); setText(t); doParse(parsePaste(t)); }
					},
					style: { width: "100%", minHeight: 130, padding: "8px 10px", border: `1px solid ${C.line}`, borderRadius: 8, fontSize: 12, fontFamily: "Consolas, monospace", lineHeight: 1.5, resize: "vertical", outline: "none", boxSizing: "border-box" },
				}),
				h("div", { style: { display: "flex", gap: 8, alignItems: "center", margin: "10px 0" } },
					h("button", { onClick: () => doParse(parsePaste(text)), style: S.add }, "解析粘贴内容"),
					msg ? h("span", { style: { fontSize: 12, color: msg.indexOf("失败") >= 0 || msg.indexOf("没有") >= 0 ? C.warn : C.sub } }, msg) : null),
				rows && rows.length
					? h("div", { style: { border: `1px solid ${C.line}`, borderRadius: 8, overflow: "hidden" } },
						h("table", { style: Object.assign({}, S.table, { marginBottom: 0 }) },
							h("thead", null, h("tr", null, ["预览（前 5 行）"].map((t, i) => h("th", { key: i, style: S.th }, t)))),
							h("tbody", null, rows.slice(0, 5).map((r, ri) => h("tr", { key: ri },
								h("td", { style: S.td }, r.slice(0, 6).join("  |  ")))))))
					: null);
		}

		/* ---------------------------- 数据体检 ---------------------------- */

		function healthIssues(db) {
			const out = [];
			const groups = aggByCity(db);
			const totalT = groups.reduce((a, g) => a + g.t, 0);
			const want = num(db.settings && db.settings.annualTarget);

			if (want && Math.abs(totalT - want) > 0.5) out.push({ level: "高", msg: `各市目标合计 ${r1(totalT)} 万，与公司年度目标 ${want} 万 差 ${r1(totalT - want)} 万`, tab: "goal" });

			groups.forEach((g) => {
				if (!String(g.city.city).trim()) out.push({ level: "中", msg: "有一个市没填名称", tab: "goal" });
				if (!g.items.length) out.push({ level: "中", msg: `${g.city.city || "未命名市"}：还没有拆到县区`, tab: "goal" });
				if (g.n === 0) out.push({ level: "中", msg: `${g.city.city || "未命名市"}：终端数为 0`, tab: "goal" });
			});

			db.counties.forEach((k) => {
				if (!String(k.name).trim()) out.push({ level: "中", msg: "有县区没填名称", tab: "goal" });
				if (num(k.n) < 0 || num(k.t) < 0) out.push({ level: "高", msg: `${k.name || "未命名县区"}：出现负数`, tab: "goal" });
				if (num(k.n) > 0 && num(k.u) === 0) out.push({ level: "低", msg: `${k.name}：有终端但单产为 0`, tab: "goal" });
			});

			db.customers.forEach((c) => {
				if (!String(c.name).trim()) out.push({ level: "中", msg: "有客户没填名称", tab: "client" });
				if (num(c.amt) <= 0) out.push({ level: "低", msg: `${c.name || "未命名客户"}：月均购进为 0`, tab: "client" });
				if (num(c.pot) < 1 || num(c.pot) > 5 || num(c.coop) < 1 || num(c.coop) > 5) out.push({ level: "低", msg: `${c.name}：潜力/配合度应为 1—5`, tab: "client" });
				if (!String(c.products || "").trim()) out.push({ level: "低", msg: `${c.name || "未命名客户"}：没写使用哪些产品`, tab: "client" });
				const rp = repurchase(c);
				if (rp.state === "日期有误") out.push({ level: "中", msg: `${c.name}：最近进货日期填错了`, tab: "client" });
				if (rp.state === "逾期") out.push({ level: "高", msg: `${c.name}：该复购了（${rp.due} 到期，已过 ${Math.abs(rp.days)} 天）`, tab: "client" });
			});

			db.agents.forEach((a) => {
				if (num(a.task) <= 0) out.push({ level: "中", msg: `${a.name || "未命名代理"}：年度任务为 0`, tab: "client" });
				if (!String(a.city || "").trim()) out.push({ level: "中", msg: `${a.name || "未命名代理"}：没填城市，目标分不下去`, tab: "client" });
				if (!String(a.area || "").trim()) out.push({ level: "中", msg: `${a.name || "未命名代理"}：没填覆盖区域`, tab: "client" });
				if (!String(a.scope || "").trim()) out.push({ level: "低", msg: `${a.name || "未命名代理"}：没填承接产品`, tab: "client" });
				if (num(a.real) > 0 && num(a.task) > 0 && num(a.real) / num(a.task) > 2) out.push({ level: "低", msg: `${a.name}：回款是任务的两倍，核对一下`, tab: "client" });
			});

			const covered = coveredCountyIds(db);
			(db.counties || []).forEach((k) => {
				if (covered.has(k.id)) return;
				const city = (db.cities || []).filter((c) => c.id === k.city)[0];
				out.push({ level: "中", msg: `${city ? city.city : "?"} · ${k.name}：还没有负责人`, tab: "goal" });
			});

			db.board.forEach((b) => {
				if (b.actual !== "" && (b.pure === "" || b.inv === "" || b.active === ""))
					out.push({ level: "中", msg: `${b.month}：填了回款但缺纯销/库存/活跃终端`, tab: "metric" });
				if (b.inv !== "" && num(b.inv) > 60) out.push({ level: "中", msg: `${b.month}：库存 ${b.inv} 天，超过 60 天红线`, tab: "metric" });
			});

			db.metrics.forEach((m) => {
				if (!String(m.formula).trim()) out.push({ level: "低", msg: `指标「${m.name || "未命名"}」没有算法`, tab: "metric" });
			});
			(db.products || []).forEach((p) => {
				if (!String(p.name).trim()) out.push({ level: "低", msg: "有产品没填名称", tab: "product" });
				if (num(p.pts) <= 0) out.push({ level: "中", msg: `产品「${p.name || "未命名"}」分值为 0，卖多少都不计分`, tab: "product" });
				if (num(p.supply) <= 0) out.push({ level: "中", msg: `产品「${p.name || "未命名"}」供货价为 0`, tab: "product" });
				if (num(p.supply) > 0 && num(p.county) >= num(p.supply)) out.push({ level: "中", msg: `「${p.name || "未命名"}」县区拿货价不低于给终端价，代理没毛利`, tab: "product" });
				if (num(p.county) > 0 && num(p.region) > num(p.county)) out.push({ level: "低", msg: `「${p.name || "未命名"}」地区价高于县区价，层级价格可能填反了`, tab: "product" });
			});
			// 品种目录 ↔ 价格表 对不上的地方
			{
				const cat = catalogOf(db);
				const inCat = {};
				cat.forEach((r) => { inCat[normName(r.name)] = 1; });
				const priced = {};
				(db.products || []).forEach((p) => { priced[normName(p.name)] = 1; });
				(db.products || []).forEach((p) => {
					if (String(p.name).trim() && !inCat[normName(p.name)]) out.push({ level: "低", msg: `「${p.name}」不在品种目录里，没有大类归属`, tab: "product" });
				});
				const miss = cat.filter((r) => !priced[normName(r.name)]);
				if (miss.length) out.push({ level: "中", msg: `目录里还有 ${miss.length} 个品种没录价格：${miss.slice(0, 6).map((r) => r.name).join("、")}${miss.length > 6 ? " 等" : ""}`, tab: "product" });
				const noCat = cat.filter((r) => !String(r.cat || "").trim()).length;
				if (noCat) out.push({ level: "低", msg: `有 ${noCat} 个品种没填大类，在「产品 → 品种目录」里补`, tab: "product" });
			}
			// 终端台账
			{
				const terms = db.customers || [];
				const noCity = terms.filter((t) => !String(t.city || "").trim()).length;
				if (noCity) out.push({ level: "中", msg: `有 ${noCity} 家终端没填市，台账数对不到县区`, tab: "client" });
				const noCounty = terms.filter((t) => String(t.city || "").trim() && !String(t.county || "").trim()).length;
				if (noCounty) out.push({ level: "低", msg: `有 ${noCounty} 家终端只填了市、没填县区`, tab: "client" });
				const noAgent = terms.filter((t) => !String(t.agent || "").trim()).length;
				if (noAgent) out.push({ level: "低", msg: `有 ${noAgent} 家终端没写归属代理/负责人`, tab: "client" });
				const sleep = terms.filter((t) => termState(t) === "休眠").length;
				if (sleep) out.push({ level: "高", msg: `${sleep} 家终端休眠（超两倍周期没进货），要么激活要么砍掉`, tab: "client" });
				const ids = {};
				terms.forEach((t) => { const k = String(t.name || "").trim(); if (k) ids[k] = (ids[k] || 0) + 1; });
				const dup = Object.keys(ids).filter((k) => ids[k] > 1);
				if (dup.length) out.push({ level: "中", msg: `终端名重复：${dup.slice(0, 3).join("、")}${dup.length > 3 ? " 等" : ""}（导入会互相覆盖）`, tab: "client" });
			}
			// 拜访闭环
			{
				const terms = db.customers || [];
				const visits = db.visits || [];
				const weekAgo = (() => { const d = new Date(); d.setDate(d.getDate() - 7); return fmtDate(d); })();
				const recently = {};
				visits.forEach((v) => { if (String(v.date || "") >= weekAgo) recently[v.terminalId || v.terminal] = 1; });
				if (!terms.some(isBig)) out.push({ level: "中", msg: "还没有标记任何大客户：拜访页会是空的，去「终端与代理」把重点终端点成「★ 大客户」", tab: "client" });
				const missed = terms.filter((t) => {
					const st = termState(t);
					return isBig(t) && (st === "逾期" || st === "临近") && !recently[t.id];
				}).length;
				if (missed) out.push({ level: "中", msg: `${missed} 家复购到期的终端本周还没拜访过`, tab: "visit" });
				const noResult = visits.filter((v) => !String(v.result || "").trim()).length;
				if (noResult) out.push({ level: "低", msg: `有 ${noResult} 条拜访记录没填结果`, tab: "visit" });
				const noId = visits.filter((v) => v.terminal && !v.terminalId).length;
				if (noId) out.push({ level: "低", msg: `有 ${noId} 条老拜访记录没绑定终端档案（照名字对得上，不影响统计）`, tab: "visit" });
			}
			// 大类覆盖：每个市每个大类有没有人
			{
				const mix = mixOf(db);
				const blank = [];
				aggByCity(db).forEach((g) => mix.cats.forEach((cat) => {
					if (!catCoverage(db, g.city.city, cat).agents.length) blank.push(g.city.city + "·" + cat);
				}));
				if (blank.length) out.push({
					level: "中",
					msg: `还有 ${blank.length} 个「市 · 大类」没配负责人：${blank.slice(0, 5).join("、")}${blank.length > 5 ? " 等" : ""}`,
					tab: "client",
				});
				const noCatAgent = (db.agents || []).filter((a) => !String(a.cat || "").trim()).length;
				if (noCatAgent) out.push({ level: "低", msg: `有 ${noCatAgent} 个代理没填「负责大类」，会按全品类算`, tab: "client" });
			}
			db.meetings.forEach((m) => {
				if (!String(m.agenda).trim()) out.push({ level: "低", msg: `会议「${m.name || "未命名"}」没有议程`, tab: "review" });
			});

			const blank = db.strategy.filter((s) => !String(s.answer || "").trim()).length;
			if (blank) out.push({ level: "中", msg: `一省一策还有 ${blank} 个模块没写答案`, tab: "review" });

			return out;
		}

		function HealthDialog({ db, setDb, onGo, onClose }) {
			const list = healthIssues(db);
			const order = { 高: 0, 中: 1, 低: 2 };
			list.sort((a, b) => order[a.level] - order[b.level]);
			const color = { 高: C.warn, 中: "#8a6d00", 低: C.sub };
			const bg = { 高: C.warnSoft, 中: "#fffbe6", 低: C.soft };
			const onDbTarget = (v) => setDb((d) => Object.assign({}, d, { settings: Object.assign({}, d.settings, { annualTarget: v }) }));

			return h(Modal, {
				title: `数据体检（${list.length} 项）`,
				onClose,
				width: 720,
				footer: h("button", { onClick: onClose, style: S.add }, "关闭"),
			},
				h("div", { style: { display: "flex", alignItems: "center", gap: 8, marginBottom: 12 } },
					h("span", { style: { fontSize: 12.5, color: C.sub } }, "公司年度目标（万元）"),
					h("input", {
						value: (db.settings && db.settings.annualTarget) || "",
						onChange: (e) => onDbTarget(e.target.value),
						style: { width: 110, padding: "5px 8px", border: `1px solid ${C.line}`, borderRadius: 7, fontSize: 12.5, fontFamily: FONT, textAlign: "right" },
					}),
					h("span", { style: { fontSize: 11.5, color: C.sub } }, "改这里会同步校验「目标合计是否对得上」")),
				list.length === 0
					? h("div", { style: { padding: 24, textAlign: "center", color: C.ok, fontSize: 13 } }, "没有发现问题")
					: h("div", { style: { display: "grid", gap: 6 } }, list.map((x, i) => h("div", {
						key: i,
						style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "7px 10px", borderRadius: 8, background: "#fcfcfd", border: `1px solid ${C.line}` },
					},
						h("span", { style: { fontSize: 11, color: color[x.level], background: bg[x.level], borderRadius: 999, padding: "1px 8px", flex: "0 0 auto" } }, x.level),
						h("span", { style: { flex: 1, fontSize: 12.5 } }, x.msg),
						h("button", {
							onClick: () => { onGo(x.tab); onClose(); },
							style: { appearance: "none", border: "none", background: "transparent", color: C.accent, fontSize: 12, cursor: "pointer", flex: "0 0 auto" },
						}, "去处理")))));
		}

		function Section({ title, note, extra }) {
			return h("div", null,
				h("div", { style: Object.assign({}, S.sec, { justifyContent: "space-between" }) },
					h("div", { style: { display: "flex", alignItems: "center", gap: 8 } }, h("span", { style: S.bar }), title),
					extra || null),
				note ? h("div", { style: S.note }, note) : null);
		}

		function Card({ label, value, hint, tone }) {
			return h("div", { style: S.card },
				h("div", { style: S.cardLabel }, label),
				h("div", { style: Object.assign({}, S.cardValue, tone === "warn" ? { color: C.warn } : tone === "ok" ? { color: C.ok } : null) }, value),
				hint ? h("div", { style: S.cardHint }, hint) : null);
		}

		/* ---------------------------- 图表 ---------------------------- */

		function niceTop(v) {
			const m = Math.max(1, Math.abs(v));
			const p = Math.pow(10, Math.floor(Math.log10(m)));
			const s = m / p;
			return (s <= 1 ? 1 : s <= 2 ? 2 : s <= 5 ? 5 : 10) * p;
		}

		function LineChart({ labels, series, unit, height }) {
			const W = 760;
			const H = height || 236;
			const L = 46;
			const R = 14;
			const T = 14;
			const B = 30;
			const n = labels.length;
			const flat = [0];
			series.forEach((s) => s.values.forEach((v) => { if (v !== "" && v != null) flat.push(Number(v) || 0); }));
			const top = niceTop(Math.max.apply(null, flat));
			const px = (i) => (n <= 1 ? (L + W - R) / 2 : L + (i * (W - L - R)) / (n - 1));
			const py = (v) => T + (1 - (Number(v) || 0) / top) * (H - T - B);
			const grid = [0, 0.25, 0.5, 0.75, 1];

			return h("div", null,
				h("svg", { viewBox: `0 0 ${W} ${H}`, style: { width: "100%", height: "auto", display: "block" } },
					grid.map((g, i) => h("g", { key: i },
						h("line", {
							x1: L, x2: W - R, y1: py(top * g), y2: py(top * g),
							stroke: g === 0 ? "#d5dae1" : "#eef0f3", strokeWidth: 1,
						}),
						h("text", { x: L - 8, y: py(top * g) + 3.5, textAnchor: "end", fontSize: 10, fill: C.sub }, Math.round(top * g)))),
					labels.map((lb, i) => h("text", { key: i, x: px(i), y: H - 10, textAnchor: "middle", fontSize: 10, fill: C.sub }, lb)),
					series.map((s, si) => h("g", { key: si },
						h("polyline", {
							points: s.values.map((v, i) => `${px(i)},${py(v)}`).join(" "),
							fill: "none", stroke: s.color, strokeWidth: s.dashed ? 1.6 : 2.2,
							strokeDasharray: s.dashed ? "5 4" : undefined, strokeLinejoin: "round", strokeLinecap: "round",
						}),
						s.values.map((v, i) => (v === "" || v == null ? null : h("circle", {
							key: i, cx: px(i), cy: py(v), r: 3, fill: "#fff", stroke: s.color, strokeWidth: 1.6,
						}, h("title", null, `${labels[i]} · ${s.name} ${v}${unit || ""}`))))))),
				h("div", { style: { display: "flex", gap: 16, marginTop: 6, fontSize: 11.5, color: C.sub, flexWrap: "wrap" } },
					series.map((s, i) => h("span", { key: i, style: { display: "inline-flex", alignItems: "center", gap: 5 } },
						h("span", { style: { width: 16, height: 3, background: s.color, borderRadius: 2, display: "inline-block" } }),
						s.name))));
		}

		/** 横向条形：value 为实心条，base 为目标/基准（浅色底） */
		function BarList({ items, max, labelWidth, unit }) {
			const top = max || Math.max(1, ...items.map((i) => Math.max(Number(i.value) || 0, Number(i.base) || 0)));
			return h("div", { style: { display: "grid", gap: 7 } }, items.map((it, i) => {
				const v = Number(it.value) || 0;
				const b = it.base == null ? null : Number(it.base) || 0;
				return h("div", { key: i, style: { display: "grid", gridTemplateColumns: `${labelWidth || 88}px 1fr auto`, gap: 10, alignItems: "center" } },
					h("div", { style: { fontSize: 12, color: C.ink, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }, title: it.label }, it.label),
					h("div", { style: { position: "relative", height: 11, background: C.soft, borderRadius: 4, overflow: "hidden" } },
						b != null ? h("div", { style: { position: "absolute", left: 0, top: 0, bottom: 0, width: `${Math.min(100, (b / top) * 100)}%`, background: "#dbe6fb" } }) : null,
						h("div", { style: { position: "absolute", left: 0, top: 0, bottom: 0, width: `${Math.min(100, (v / top) * 100)}%`, background: it.color || C.accent, borderRadius: 4 } })),
					h("div", { style: { fontSize: 11.5, color: it.noteColor || C.sub, fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" } }, it.note || String(v) + (unit || "")));
			}));
		}

		/**
		 * 可编辑单元格
		 * 给了 options 就用 <datalist>：既能下拉选现有值，也能直接手输新的
		 */
		let listSeq = 0;
		function Cell({ value, onChange, align, placeholder, options, listId, label }) {
			const [focus, setFocus] = useState(false);
			const hasList = !!(options && options.length);
			const lid = listId || ("dlx-" + (++listSeq));
			const inp = h("input", {
				value: value == null ? "" : value,
				placeholder: placeholder || "",
				list: hasList ? lid : undefined,
				title: hasList ? "可点下拉选，也可以直接输入" : undefined,
				onChange: (e) => {
					const nv = e.target.value;
					const cur = value == null ? "" : String(value);
					if (UI.strict && String(nv) !== cur) {
						pushChange({ key: label || listId || "cell", label: label || "这一格", from: cur, to: String(nv), set: onChange });
					}
					onChange(nv);
				},
				onFocus: () => setFocus(true),
				onBlur: () => setFocus(false),
				style: Object.assign({}, inputBase, { textAlign: align || "left" },
					hasList ? { paddingRight: 15 } : null,
					focus ? { background: "#fff", borderColor: C.accent, boxShadow: "0 0 0 2px rgba(47,111,237,.10)" } : null),
			});
			if (!hasList) return inp;
			return h("span", { style: { display: "block", position: "relative" } }, inp,
				h("span", {
					style: { position: "absolute", right: 4, top: "50%", transform: "translateY(-50%)", fontSize: 9, color: C.sub, pointerEvents: "none", lineHeight: 1 },
				}, "▾"),
				h("datalist", { id: lid }, options.map((o, i) => h("option", { key: i, value: String(o) }))));
		}

		function Area({ value, onChange, placeholder, minH, label }) {
			const [focus, setFocus] = useState(false);
			return h("textarea", {
				value: value == null ? "" : value,
				placeholder: placeholder || "",
				onChange: (e) => {
					const nv = e.target.value;
					const cur = value == null ? "" : String(value);
					if (UI.strict && String(nv) !== cur) {
						pushChange({ key: label || "area", label: label || "这一段", from: cur, to: String(nv), set: onChange });
					}
					onChange(nv);
				},
				onFocus: () => setFocus(true),
				onBlur: () => setFocus(false),
				style: Object.assign({
					width: "100%", minHeight: minH || 62, padding: "7px 9px", borderRadius: 8,
					border: `1px solid ${C.line}`, fontSize: 12.5, fontFamily: FONT, lineHeight: 1.6,
					resize: "vertical", outline: "none", boxSizing: "border-box", color: C.ink, background: "#fff",
				}, focus ? { borderColor: C.accent, boxShadow: "0 0 0 2px rgba(47,111,237,.10)" } : null),
			});
		}

		/** 行内任意字段包含关键字即命中；extra 供派生列（等级/状态等）参与匹配 */
		function match(row, q, extra) {
			if (!q) return true;
			const s = String(q).trim().toLowerCase();
			if (!s) return true;
			const own = Object.keys(row).some((k) => k !== "id" && String(row[k] == null ? "" : row[k]).toLowerCase().includes(s));
			if (own) return true;
			return extra ? String(extra(row)).toLowerCase().includes(s) : false;
		}

		function Filter({ q, setQ, placeholder, chips, value, setValue, shown, total, hideSearch }) {
			return h("div", { style: { display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap", marginBottom: 8 } },
				hideSearch ? null : h("input", {
					value: q,
					placeholder: placeholder || "筛选：输入关键字",
					onChange: (e) => setQ(e.target.value),
					style: {
						width: 240, padding: "5px 10px", border: `1px solid ${C.line}`, borderRadius: 8,
						fontSize: 12.5, fontFamily: FONT, outline: "none", background: "#fff", color: C.ink,
					},
				}),
				q ? h("button", {
					onClick: () => setQ(""),
					style: { appearance: "none", border: "none", background: "transparent", color: C.sub, fontSize: 12, cursor: "pointer", fontFamily: FONT },
				}, "清除") : null,
				chips ? chips.map((c) => h("button", {
					key: c,
					onClick: () => setValue(c),
					style: {
						appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 12,
						padding: "3px 10px", borderRadius: 999, border: `1px solid ${c === value ? C.accent : C.line}`,
						background: c === value ? C.accentSoft : "#fff", color: c === value ? C.accent : C.sub,
					},
				}, c)) : null,
				shown != null && total != null
					? h("span", { style: { fontSize: 11.5, color: C.sub, marginLeft: "auto" } }, shown === total ? `共 ${total} 行` : `筛出 ${shown} / ${total} 行`)
					: null);
		}

		/** 删除按钮：点一次变红「确认」，4 秒内再点一次才真的删掉；不动就自动取消 */
		function DelBtn({ onConfirm, title, confirmText, label }) {
			const [armed, setArmed] = useState(false);
			useEffect(() => {
				if (!armed) return undefined;
				const t = setTimeout(() => setArmed(false), 4000);
				return () => clearTimeout(t);
			}, [armed]);
			return h("button", {
				title: armed ? "再点一次就删掉（4 秒内有效）" : (title || "删除（会再确认一次）"),
				onClick: () => {
					if (armed) { setArmed(false); onConfirm(); } else setArmed(true);
				},
				style: armed
					? {
						appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 11, padding: "1px 6px",
						borderRadius: 5, border: `1px solid ${C.warn}`, background: C.warnSoft, color: C.warn, whiteSpace: "nowrap",
					}
					: S.del,
			}, armed ? (confirmText || "确认") : (label || "✕"));
		}

		/**
		 * 可编辑表格
		 * fields: [{ key, type?: 'text'|'num', align?, render?(row), options?: string[] | (row) => string[] }]
		 */
		function Editable({ head, rows, fields, widths, onChange, onAdd, onDelete, note, addLabel, toolbar }) {
			const rowNameOf = (row) => {
				const keys = ["name", "city", "label", "title", "mark", "month", "step", "week", "q", "region", "no", "module", "level"];
				for (let i = 0; i < keys.length; i += 1) {
					const v = String((row && row[keys[i]]) || "").trim();
					if (v) return v;
				}
				return "";
			};
			return h("div", null,
				h(Section, { title: note && note.title, note: note && note.text }),
				toolbar || null,
				h("table", { style: S.table },
					h("thead", null, h("tr", null,
						head.map((t, i) => h("th", { key: i, style: Object.assign({}, S.th, widths && widths[i] ? { width: widths[i] } : null, { textAlign: (fields[i] && fields[i].align) || "left" }) }, t)),
						onDelete ? h("th", { key: "del", style: Object.assign({}, S.th, { width: 54 }) }, "") : null)),
					h("tbody", null, rows.map((row) => h("tr", { key: row.id },
						fields.map((f, i) => h("td", { key: i, style: Object.assign({}, S.td, { textAlign: f.align || "left" }) },
							f.render ? f.render(row)
								: h(Cell, {
									value: row[f.key],
									align: f.align,
									placeholder: f.placeholder,
									label: [rowNameOf(row), head[i]].filter(Boolean).join(" · "),
									options: typeof f.options === "function" ? f.options(row) : f.options,
									listId: "dl-" + f.key + "-" + row.id,
									onChange: (v) => onChange(row.id, f.key, v),
								}))),
						onDelete ? h("td", { key: "del", style: Object.assign({}, S.td, { width: 54, textAlign: "center" }) },
							h(DelBtn, { onConfirm: () => onDelete(row.id), title: "删除这一行（会再确认一次）" })) : null)))),

				onAdd ? h("button", { onClick: onAdd, style: S.add }, addLabel || "＋ 添加一行") : null);
		}

		/* ---------------------------- 各页 ---------------------------- */

		const AUTO_CARDS = [
			["auto:target", "年度目标（万元）"],
			["auto:month", "月均目标（万元）"],
			["auto:existing", "现有年化（万元）"],
			["auto:gap", "缺口（万元）"],
			["auto:points", "折合目标分"],
			["auto:ytd", "累计回款（万元）"],
			["auto:ytdPoints", "累计分值"],
			["auto:terminals", "终端数"],
			["auto:counties", "县区数"],
			["auto:unit", "加权单产（元/月）"],
			["auto:customers", "客户数"],
			["auto:agents", "代理商数"],
			["auto:agentRisk", "预警代理商"],
			["auto:risks", "风险项数"],
		];

		function cardValue(key, s) {
			switch (key) {
				case "auto:target": return { v: fmt(s.annual, 0) + " 万" };
				case "auto:month": return { v: fmt(s.annual / 12, 1) + " 万" };
				case "auto:existing": return { v: fmt(s.e, 1) + " 万", hint: `${fmt(s.n, 0)} 家终端 · 单产 ${fmt(s.unit, 0)} 元` };
				case "auto:gap": return { v: fmt(s.gap, 1) + " 万", tone: s.gap > 0 ? "warn" : "ok", hint: s.gap > 0 ? "靠新增终端与单产提升补" : "已覆盖目标" };
				case "auto:points": return { v: fmt(s.annual * s.conv, 0) + " 分", hint: `按 ${fmt(s.conv, 0)} 分/万元` };
				case "auto:ytd": return { v: fmt(s.ytd, 1) + " 万" };
				case "auto:ytdPoints": return { v: fmt(s.ytd * s.conv, 0) + " 分" };
				case "auto:terminals": return { v: fmt(s.n, 0) + " 家" };
				case "auto:counties": return { v: s.counties + " 个" };
				case "auto:unit": return { v: fmt(s.unit, 0) + " 元" };
				case "auto:customers": return { v: s.customers + " 家" };
				case "auto:agents": return { v: s.agents + " 个" };
				case "auto:agentRisk": return { v: s.agentRisk + " 个", tone: s.agentRisk ? "warn" : "ok" };
				case "auto:risks": return { v: s.risks + " 项", tone: s.risks ? "warn" : "ok" };
				default: return { v: "—" };
			}
		}

		function Overview({ db, setDb }) {
			const totals = useMemo(() => {
				const groups = aggByCity(db);
				let n = 0, e = 0, t = 0;
				groups.forEach((g) => { n += g.n; e += g.e; t += g.t; });
				const ytd = db.board.reduce((a, b) => a + num(b.actual), 0);
				const agentRisk = db.agents.filter((a) => (num(a.task) ? num(a.real) / num(a.task) : 0) < 0.6).length;
				return {
					n, e, t, unit: unitOf(n, e), gap: t - e, cities: groups.length, counties: db.counties.length,
					ytd, conv: convOf(db), customers: db.customers.length, agents: db.agents.length,
					agentRisk, risks: risksOf(db).length, annual: num(db.settings && db.settings.annualTarget),
				};
			}, [db]);

			const [q, setQ] = useState("");
			const [editCards, setEditCards] = useState(false);
			const keep = (arr) => arr.filter((r) => match(r, q));

			const cards = db.cards || [];
			const editCard = (id, k, v) => setDb((d) => Object.assign({}, d, { cards: d.cards.map((c) => (c.id === id ? Object.assign({}, c, { [k]: v }) : c)) }));
			const isAuto = (c) => String(c.type || "").indexOf("auto:") === 0;

			const badge = (auto) => h("span", {
				style: {
					fontSize: 10.5, padding: "1px 7px", borderRadius: 999, whiteSpace: "nowrap",
					color: auto ? C.accent : C.sub,
					background: auto ? C.accentSoft : C.soft,
					border: `1px solid ${auto ? "#cfe0fd" : C.line}`,
				},
			}, auto ? "自动生成" : "手动修改");

			return h("div", null,
				h(Section, {
					title: "关键指标",
					note: editCards
						? "改标题 / 选「自动生成」或「手动修改」/ 填内容；手动卡片在正常视图里也能直接改数值"
						: "标「自动生成」的跟数据联动；标「手动修改」的可以直接点数值改；想把自动的固定下来，点卡片上的「锁为手动」",
					extra: h("button", { onClick: () => setEditCards(!editCards), style: S.add }, editCards ? "完成编辑" : "编辑卡片"),
				}),
				h("div", { style: S.cards },
					cards.map((c) => {
						const auto = isAuto(c);

						if (editCards) {
							return h("div", { key: c.id, style: Object.assign({}, S.card, { padding: "10px 12px" }) },
								h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 } },
									h("div", { style: S.cardLabel }, "标题"), badge(auto)),
								h("input", {
									value: c.label || "",
									onChange: (e) => editCard(c.id, "label", e.target.value),
									style: { width: "100%", border: `1px solid ${C.line}`, borderRadius: 6, padding: "3px 6px", fontSize: 12, fontFamily: FONT, marginBottom: 6, boxSizing: "border-box" },
								}),
								h("select", {
									value: c.type || "text",
									onChange: (e) => editCard(c.id, "type", e.target.value),
									style: { width: "100%", border: `1px solid ${C.line}`, borderRadius: 6, padding: "3px 6px", fontSize: 12, fontFamily: FONT, marginBottom: 6, background: "#fff", boxSizing: "border-box" },
								},
									[["text", "手动修改（自己写）"]].concat(AUTO_CARDS.map(([k, label]) => [k, "自动生成 · " + label])).map(([k, label]) => h("option", { key: k, value: k }, label))),
								auto
									? h("div", { style: { fontSize: 12, color: C.sub } }, "数值自动算，不用填")
									: h("input", {
										value: c.value || "",
										placeholder: "显示内容",
										onChange: (e) => editCard(c.id, "value", e.target.value),
										style: { width: "100%", border: `1px solid ${C.line}`, borderRadius: 6, padding: "3px 6px", fontSize: 13, fontFamily: FONT, boxSizing: "border-box" },
									}),
								h("span", { style: { display: "inline-block", marginTop: 6 } },
									h(DelBtn, { onConfirm: () => setDb((d) => Object.assign({}, d, { cards: d.cards.filter((x) => x.id !== c.id) })), title: "删除这张卡片（会再确认一次）", label: "删除" })));
						}

						const val = auto ? cardValue(c.type, totals) : null;
						const isMaster = c.type === "auto:target";
						return h("div", { key: c.id, style: S.card },
							h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 } },
								h("div", { style: S.cardLabel }, c.label),
								badge(auto)),
							isMaster
								? h("div", { style: { display: "flex", alignItems: "baseline", gap: 4 } },
									h("input", {
										value: (db.settings && db.settings.annualTarget) || "",
										onChange: (e) => setDb((d) => Object.assign({}, d, { settings: Object.assign({}, d.settings, { annualTarget: e.target.value }) })),
										style: {
											width: 110, boxSizing: "border-box", border: `1px solid ${C.line}`, background: "#fffdf5",
											fontSize: 21, fontWeight: 650, letterSpacing: -0.2, color: C.ink, fontFamily: FONT,
											padding: "2px 6px", borderRadius: 6, outline: "none", textAlign: "right",
										},
									}),
									h("span", { style: { fontSize: 14, color: C.sub } }, "万"),
									h("span", { style: { fontSize: 11, color: C.accent, marginLeft: 4 } }, "改这里，下游全变"))
								: auto
									? h("div", { style: Object.assign({}, S.cardValue, val.tone === "warn" ? { color: C.warn } : val.tone === "ok" ? { color: C.ok } : null) }, val.v)
									: h("input", {
									value: c.value || "",
									placeholder: "点击填写",
									onChange: (e) => editCard(c.id, "value", e.target.value),
									style: {
										width: "100%", boxSizing: "border-box", border: `1px solid transparent`, background: "transparent",
										fontSize: 21, fontWeight: 650, letterSpacing: -0.2, color: C.ink, fontFamily: FONT,
										padding: "2px 4px", borderRadius: 6, outline: "none",
									},
									onFocus: (e) => { e.currentTarget.style.borderColor = C.accent; e.currentTarget.style.background = "#fff"; },
									onBlur: (e) => { e.currentTarget.style.borderColor = "transparent"; e.currentTarget.style.background = "transparent"; },
								}),
							auto && val.hint ? h("div", { style: S.cardHint }, val.hint) : null,
							auto
								? h("button", {
									onClick: () => setDb((d) => Object.assign({}, d, { cards: d.cards.map((x) => (x.id === c.id ? Object.assign({}, x, { type: "text", value: val.v }) : x)) })),
									style: { marginTop: 6, appearance: "none", border: "none", background: "transparent", color: C.sub, fontSize: 11, cursor: "pointer", padding: 0, fontFamily: FONT },
								}, "锁为手动")
								: null);
					}),
					editCards
						? h("button", {
							onClick: () => setDb((d) => Object.assign({}, d, { cards: d.cards.concat([{ id: nid(), label: "新卡片", type: "text", value: "" }]) })),
							style: Object.assign({}, S.add, { height: "100%", minHeight: 96 }),
						}, "＋ 添加卡片")
						: null),

				h(Filter, { q, setQ, placeholder: "筛选本页：区域 / 打法 / 决定…" }),

				h(Editable, {
					note: { title: "江苏三段：不是一个市场，是三个", text: "所有格子都能改，改完自动保存" },
					head: ["区域", "包含城市", "打法", "资源"],
					widths: ["9%", "46%", "33%", "12%"],
					fields: [{ key: "region" }, { key: "cities" }, { key: "play" }, { key: "resource", align: "center" }],
					rows: keep(db.segments),
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { segments: d.segments.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { segments: d.segments.concat([{ id: nid(), region: "", cities: "", play: "", resource: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { segments: d.segments.filter((r) => r.id !== id) })),
				}),

				h(Editable, {
					note: { title: "首月三个决定", text: "" },
					head: ["序号", "决定", "内容"],
					widths: ["8%", "20%", "72%"],
					fields: [{ key: "mark", align: "center" }, { key: "title" }, { key: "content" }],
					rows: keep(db.decisions),
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { decisions: d.decisions.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { decisions: d.decisions.concat([{ id: nid(), mark: "", title: "", content: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { decisions: d.decisions.filter((r) => r.id !== id) })),
				}),

				h(Editable, {
					note: { title: "六步闭环", text: "每一步都要有「完成的标志」，没达到不进下一步" },
					head: ["步骤", "时间", "核心动作", "完成的标志"],
					widths: ["12%", "15%", "43%", "30%"],
					fields: [{ key: "step" }, { key: "time" }, { key: "action" }, { key: "done" }],
					rows: keep(db.loop),
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { loop: d.loop.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { loop: d.loop.concat([{ id: nid(), step: "", time: "", action: "", done: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { loop: d.loop.filter((r) => r.id !== id) })),
				}));
		}

		function GoalPage({ db, setDb }) {
			const [q, setQ] = useState("");
			const [zone, setZone] = useState("全部");
			const [open, setOpen] = useState({});
			const conv = convOf(db);
			const { effCounty } = targetsOf(db);
			const mix = mixOf(db);
			const mixCats = mix.cats.filter((c) => mix.share[c] > 0);

			const groups = useMemo(() => aggByCity(db), [db.cities, db.counties]);
			const totals = useMemo(() => {
				const n = groups.reduce((a, g) => a + g.n, 0);
				const e = groups.reduce((a, g) => a + g.e, 0);
				const t = groups.reduce((a, g) => a + g.t, 0);
				const k = groups.reduce((a, g) => a + g.items.length, 0);
				return { n, e, t, k, g: t - e, unit: unitOf(n, e) };
			}, [groups]);

			const zones = ["全部"].concat(Array.from(new Set(db.cities.map((c) => c.zone || "未分组"))));
			const s = q.trim().toLowerCase();
			const filtered = groups.filter((g) => {
				if (zone !== "全部" && (g.city.zone || "未分组") !== zone) return false;
				if (!s) return true;
				const self = [g.city.city, g.city.zone].join(" ").toLowerCase().indexOf(s) >= 0;
				return self || g.items.some((k) => String(k.name).toLowerCase().indexOf(s) >= 0);
			});
			const shownCount = filtered.reduce((a, g) => a + 1 + (open[g.city.id] || s ? g.items.length : 0), 0);

			const editCity = (id, k, v) => setDb((d) => Object.assign({}, d, { cities: d.cities.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));
			const editCounty = (id, k, v) => setDb((d) => Object.assign({}, d, { counties: d.counties.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));
			const addCounty = (cityId) => setDb((d) => Object.assign({}, d, { counties: d.counties.concat([{ id: nid(), city: cityId, name: "", n: "0", u: "0", t: "" }]) }));
			const delCounty = (id) => setDb((d) => Object.assign({}, d, { counties: d.counties.filter((r) => r.id !== id) }));
			const delCity = (id) => setDb((d) => Object.assign({}, d, {
				cities: d.cities.filter((r) => r.id !== id),
				counties: d.counties.filter((r) => r.city !== id),
			}));
			const toggle = (id) => setOpen((o) => Object.assign({}, o, { [id]: !o[id] }));
			const allOpen = filtered.every((g) => open[g.city.id]);

			const [addOpen, setAddOpen] = useState(false);
			const [confirmAuto, setConfirmAuto] = useState(false);
			const [addName, setAddName] = useState("");
			const [addMsg, setAddMsg] = useState("");
			const existingNames = new Set(db.cities.map((c) => String(c.city).trim()));
			const tplOf = (n) => COUNTY_NAMES[String(n || "").trim()] || null;
			const availableTpl = Object.keys(COUNTY_NAMES).filter((n) => !existingNames.has(n));

			const addCity = (useTemplate) => {
				const name = String(addName || "").trim();
				if (!name) { setAddMsg("先填市名"); return; }
				if (existingNames.has(name)) { setAddMsg(`「${name}」已经有了，直接改它就行`); return; }
				const tpl = tplOf(name);
				if (useTemplate && !tpl) { setAddMsg(`没有「${name}」的内置县区；可以改用「添加空白市」，再手动加县区`); return; }
				const built = buildCity(name, useTemplate && !!tpl);
				setDb((d) => Object.assign({}, d, {
					cities: d.cities.concat([built.city]),
					counties: d.counties.concat(built.counties),
				}));
				setOpen((o) => Object.assign({}, o, { [built.city.id]: true }));
				setAddOpen(false);
				setAddName("");
				setAddMsg("");
			};

			const cell = (v, align) => h("td", { style: Object.assign({}, S.td, { textAlign: align || "left" }) }, v);

			return h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "终端数合计", value: fmt(totals.n, 0) + " 家" }),
					h(Card, { label: "现有年化产出", value: fmt(totals.e, 1) + " 万", hint: "终端数 × 单产 × 12" }),
					h(Card, { label: "年目标合计", value: fmt(totals.t, 0) + " 万" }),
					h(Card, { label: "缺口合计", value: fmt(totals.g, 1) + " 万", tone: totals.g > 0 ? "warn" : "ok", hint: `已细分 ${totals.k} 个县区` }),
					h(Card, { label: "折合目标分", value: fmt(totals.t * conv, 0) + " 分", hint: `按 ${fmt(conv, 0)} 分/万元` })),

				h(Section, { title: "各市现有 vs 目标", note: "实心＝现有年化，浅色＝年目标；条形越长目标越高，右侧显示现有/目标" }),
				h(BarList, {
					items: filtered.map((g) => ({
						label: g.city.city || "未命名",
						value: g.e,
						base: g.t,
						note: `${r1(g.e)} / ${r1(g.t)} 万`,
						noteColor: g.t - g.e > 0 ? C.warn : C.ok,
					})),
				}),

				h(Section, { title: "按产品大类分解", note: "先把年度指标按下面的大类占比切开，再乘各市目标 → 得到「某市某大类多少万」；占比不用凑 100，自动归一" }),
				h("div", { style: { display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center", padding: "10px 12px", border: `1px solid ${C.line}`, borderRadius: 10, marginBottom: 10 } },
					mixCats.map((c) => h("label", { key: c, style: { display: "flex", alignItems: "center", gap: 4, fontSize: 12 } },
						h("span", { style: { color: C.sub } }, c),
						h("input", {
							value: (db.settings.catMix && db.settings.catMix[c] != null) ? String(db.settings.catMix[c]) : "",
							placeholder: String(Math.round((mix.share[c] || 0) * 100)),
							onChange: (e) => setDb((d) => Object.assign({}, d, {
								settings: Object.assign({}, d.settings, { catMix: Object.assign({}, d.settings.catMix || {}, { [c]: e.target.value }) }),
							})),
							style: {
								width: 54, padding: "4px 7px", border: `1px solid ${C.line}`, borderRadius: 6,
								fontSize: 12, fontFamily: FONT, textAlign: "right", outline: "none",
							},
						}),
						h("span", { style: { color: C.sub } }, "%"))),
					h("span", { style: { marginLeft: "auto", fontSize: 11.5, color: mix.sum === 100 ? C.sub : "#8a6d00" } },
						`填的合计 ${mix.sum}，按比例归一；改完下面的表跟着变`)),
				h("table", { style: S.table },
					h("thead", null, h("tr", null,
						["城市"].concat(mixCats).concat(["合计(万)", "合计分"]).map((t, i) =>
							h("th", { key: i, style: Object.assign({}, S.th, { textAlign: i === 0 ? "left" : "right" }) }, t)))),
					h("tbody", null, filtered.map((g) => h("tr", { key: g.city.id },
						cell(g.city.city || "未命名"),
						mixCats.map((c) => cell(r1(g.t * (mix.share[c] || 0)), "right")),
						cell(r1(g.t), "right"),
						cell(fmt(g.t * conv, 0), "right"))))),

				h(Section, {
					title: "13 市 → 县区拆解",
					note: `年目标默认按现有产出占比、从年度指标 ${fmt(num(db.settings.annualTarget), 0)} 万 自动分摊；直接输入就会改成手填，点 ↺ 回到自动`,
					extra: h("div", { style: { display: "flex", gap: 6 } },
						h("button", {
							onClick: () => {
								if (!confirmAuto) { setConfirmAuto(true); return; }
								setConfirmAuto(false);
								setDb((d) => Object.assign({}, d, {
									cities: d.cities.map((c) => Object.assign({}, c, { t: "" })),
									counties: d.counties.map((k) => Object.assign({}, k, { t: "" })),
								}));
							},
							style: confirmAuto ? Object.assign({}, S.add, { borderColor: "#f0b4a8", color: C.warn }) : S.add,
						}, confirmAuto ? "确认全部改成自动分摊？" : "全部改为自动分摊"),
						h("button", {
							onClick: () => {
								const next = {};
								filtered.forEach((g) => { next[g.city.id] = !allOpen; });
								setOpen(Object.assign({}, open, next));
							},
							style: S.add,
						}, allOpen ? "全部收起" : "全部展开")),
				}),
				h(Filter, {
					q, setQ, placeholder: "筛选：城市 / 县区…",
					chips: zones, value: zone, setValue: setZone,
					shown: shownCount, total: 1 + db.cities.length + db.counties.length,
				}),

				h("table", { style: S.table },
					h("thead", null, h("tr", null,
						["", "城市 / 县区", "负责人", "分区", "终端数(家)", "台账终端", "单产(元/月)", "现有年化(万)", "年目标(万)", "目标分", "缺口(万)", ""].map((t, i) =>
							h("th", { key: i, style: Object.assign({}, S.th, { width: ["3%", "16%", "11%", "6%", "8%", "7%", "8%", "8%", "8%", "8%", "12%", "3%"][i], textAlign: i >= 4 && i <= 10 ? "right" : "left" }) }, t)))),
					h("tbody", null, filtered.map((g) => {
						const expanded = !!open[g.city.id] || !!s;
						const rows = [];
						rows.push(h("tr", { key: g.city.id, style: { background: "#fbfcfd" } },
							h("td", { style: Object.assign({}, S.td, { textAlign: "center" }) },
								h("button", {
									onClick: () => toggle(g.city.id),
									style: { appearance: "none", border: "none", background: "transparent", cursor: "pointer", color: C.accent, fontSize: 12, padding: 0, fontFamily: FONT },
								}, expanded ? "▾" : "▸")),
							cell(h("div", { style: { display: "flex", alignItems: "center", gap: 6 } },
								h("div", { style: { width: 96 } }, h(Cell, { value: g.city.city, label: "城市名 · " + (g.city.city || "未命名"), onChange: (v) => editCity(g.city.id, "city", v) })),
								h("span", { style: { fontSize: 11, color: C.sub, background: C.soft, borderRadius: 999, padding: "1px 7px" } }, `${g.items.length} 个县区`))),
							cell((() => {
								const names = [];
								g.items.forEach((k) => {
									agentsOfCounty(db, k.name, g.city.city).forEach((a) => { if (names.indexOf(a.name) < 0) names.push(a.name); });
								});
								return names.length
									? h("span", { style: { fontSize: 11.5, color: C.sub } }, `${names.length} 人`)
									: h("span", { style: { fontSize: 11.5, color: C.warn } }, "未分配");
							})(), "center"),
							cell(h(Cell, { value: g.city.zone, align: "center", options: zones.filter((x) => x !== "全部"), listId: "dl-zone-" + g.city.id, label: (g.city.city || "") + " · 分区", onChange: (v) => editCity(g.city.id, "zone", v) }), "center"),
							cell(fmt(g.n, 0), "right"),
							cell((() => {
								const n = countTerminals(db, g.city.city);
								const diff = n - num(g.n);
								return h("span", { style: { color: diff < 0 && n > 0 ? C.warn : C.sub } }, fmt(n, 0) + (n && num(g.n) ? "（" + (diff >= 0 ? "+" : "") + fmt(diff, 0) + "）" : ""));
							})(), "right"),
							cell(fmt(unitOf(g.n, g.e), 0), "right"),
							cell(fmt(g.e, 1), "right"),
							cell(h("div", { style: { display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 3 } },
								h("div", { style: { width: 68 } }, h(Cell, {
									value: g.city.t,
									align: "right",
									placeholder: fmt(g.t, 1),
									label: (g.city.city || "") + " · 年目标(万)",
									onChange: (v) => editCity(g.city.id, "t", v),
								})),
								String(g.city.t || "").trim()
									? h("button", { title: "改回自动分摊", onClick: () => editCity(g.city.id, "t", ""), style: { appearance: "none", border: "none", background: "transparent", color: C.accent, cursor: "pointer", fontSize: 11 } }, "↺")
									: h("span", { style: { fontSize: 10, color: C.sub, whiteSpace: "nowrap" } }, "自动")), "right"),
							cell(h("span", { style: { color: C.accent } }, fmt(g.t * conv, 0)), "right"),
							cell(h("span", { style: { color: g.t - g.e > 0 ? C.warn : C.ok, fontWeight: 600 } }, fmt(g.t - g.e, 1)), "right"),
							h("td", { style: Object.assign({}, S.td, { textAlign: "center" }) },
								h(DelBtn, { title: "删除该市及其县区（会再确认一次）", confirmText: "确认删市", onConfirm: () => delCity(g.city.id) }))));

						if (expanded) {
							g.items.forEach((k) => {
								const e = num(k.n) * num(k.u) * 12 / 10000;
								const kt = effCounty.get(k.id) || 0;
								const gap = kt - e;
								rows.push(h("tr", { key: k.id },
									cell(""),
									h("td", { style: Object.assign({}, S.td, { paddingLeft: 26 }) },
										h(Cell, { value: k.name, label: "县区名 · " + (k.name || "") + "（" + (g.city.city || "") + "）", onChange: (v) => editCounty(k.id, "name", v) })),
									cell((() => {
										const who = agentsOfCounty(db, k.name, g.city.city);
										if (!who.length) return h("span", { style: { fontSize: 11, color: C.warn, fontWeight: 600 } }, "未分配");
										return h("span", { style: { fontSize: 11, color: C.sub } }, who.map((a) => a.name).join(" + "));
									})(), "center"),
									cell(h("span", { style: { color: "#c9ccd1" } }, "—"), "center"),
									cell(h(Cell, { value: k.n, align: "right", label: (k.name || "") + " · 终端数", onChange: (v) => editCounty(k.id, "n", v) }), "right"),
									cell(h("span", { style: { color: countTerminals(db, g.city.city, k.name) ? C.sub : "#c9ccd1" } }, String(countTerminals(db, g.city.city, k.name))), "right"),
									cell(h(Cell, { value: k.u, align: "right", label: (k.name || "") + " · 单产(元/月)", onChange: (v) => editCounty(k.id, "u", v) }), "right"),
									cell(fmt(e, 1), "right"),
									cell(h("div", { style: { display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 3 } },
										h("div", { style: { width: 64 } }, h(Cell, {
											value: k.t,
											align: "right",
											placeholder: fmt(kt, 1),
											label: (k.name || "") + " · 年目标(万)",
											onChange: (v) => editCounty(k.id, "t", v),
										})),
										String(k.t || "").trim()
											? h("button", { title: "改回自动分摊", onClick: () => editCounty(k.id, "t", ""), style: { appearance: "none", border: "none", background: "transparent", color: C.accent, cursor: "pointer", fontSize: 11 } }, "↺")
											: h("span", { style: { fontSize: 10, color: C.sub } }, "自动")), "right"),
									cell(h("span", { style: { color: C.accent } }, fmt(kt * conv, 0)), "right"),
									cell(h("span", { style: { color: gap > 0 ? C.warn : C.ok } }, fmt(gap, 1)), "right"),
									h("td", { style: Object.assign({}, S.td, { textAlign: "center" }) },
										h(DelBtn, { title: "删除该县区（会再确认一次）", onConfirm: () => delCounty(k.id) }))));
							});
							rows.push(h("tr", { key: g.city.id + "-add" },
								h("td", { style: S.td }),
								h("td", { style: S.td, colSpan: 9, paddingLeft: 26 },
									h("button", { onClick: () => addCounty(g.city.id), style: Object.assign({}, S.add, { padding: "3px 9px", fontSize: 11.5 }) }, `＋ 在${g.city.city || "该市"}下添加县区`))));
						}
						return rows;
					}))),

				h("div", { style: { marginTop: 8, fontSize: 12.5, color: C.sub } },
					`合计：${db.cities.length} 个市 · ${totals.k} 个县区 · ${fmt(totals.n, 0)} 家终端 · 加权单产 ${fmt(totals.unit, 0)} 元 · 目标 ${fmt(totals.t, 0)} 万 · 缺口 ${fmt(totals.g, 1)} 万`),

				h("button", {
					onClick: () => { setAddOpen(!addOpen); setAddMsg(""); },
					style: Object.assign({}, S.add, { marginTop: 8 }),
				}, addOpen ? "收起" : "＋ 添加一个市"),

				addOpen ? h("div", { style: { border: `1px solid ${C.line}`, borderRadius: 10, padding: "12px 14px", marginTop: 8 } },
					h("div", { style: { fontSize: 12.5, fontWeight: 600, marginBottom: 8 } }, "添加一个市 · 两种方式"),
					h("div", { style: { display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" } },
						h("input", {
							value: addName,
							placeholder: "市名，如 南京",
							list: "city-tpl-list",
							onChange: (e) => { setAddName(e.target.value); setAddMsg(""); },
							style: { width: 160, padding: "5px 9px", border: `1px solid ${C.line}`, borderRadius: 7, fontSize: 12.5, fontFamily: FONT },
						}),
						h("datalist", { id: "city-tpl-list" }, Object.keys(COUNTY_NAMES).map((n) => h("option", { key: n, value: n }))),
						h("button", {
							onClick: () => addCity(true),
							style: Object.assign({}, S.add, { borderColor: C.accent, color: C.accent }),
						}, tplOf(addName) ? `按模板添加（带 ${tplOf(addName).length} 个县区）` : "按模板添加"),
						h("button", { onClick: () => addCity(false), style: S.add }, "添加空白市"),
						h("button", { onClick: () => { setAddOpen(false); setAddName(""); setAddMsg(""); }, style: S.add }, "取消")),
					h("div", { style: { fontSize: 11.5, color: C.sub, marginTop: 6 } },
						"模板里的市会把县区一起建好（如南京 11 个区、苏州 9 个）；没有模板的市用「添加空白市」，再在城市下面逐个加县区。新市先填终端数，目标会随年度指标自动分摊；要定点就在目标列直接填。"),
					addMsg ? h("div", { style: { fontSize: 12, color: C.warn, marginTop: 6 } }, addMsg) : null,
					availableTpl.length
						? h("div", { style: { display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 } },
							availableTpl.map((n) => h("button", {
								key: n,
								onClick: () => { setAddName(n); setAddMsg(""); },
								style: { appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 11.5, padding: "3px 9px", borderRadius: 999, border: `1px solid ${C.line}`, background: "#fff", color: C.sub },
							}, `${n} · ${COUNTY_NAMES[n].length} 县区`)))
						: null)
					: null,

				h(Section, { title: "拆解四问", note: "填完自查，答不上来就等于没拆" }),
				h("ul", { style: { margin: "0 0 0 18px", padding: 0, color: "#374151", fontSize: 12.5 } },
					["新增终端名单在哪？没有名单的「新增」等于没有。",
						"单产提升靠哪三个动作（首推 / 陈列 / 活动）？",
						"哪个市、哪个县承担缺口最多，为什么是它？",
						"费用预算是否与缺口同比例增加？"].map((t, i) => h("li", { key: i, style: { marginBottom: 4 } }, t))));
		}


		function TerminalPanel({ db, setDb }) {
			const [q, setQ] = useState("");
			const [st, setSt] = useState("全部");
			const [city, setCity] = useState("全部");
			const [bf, setBf] = useState("全部");
			const terms = db.customers || [];
			const edit = (id, k, v) => setDb((d) => Object.assign({}, d, { customers: d.customers.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));

			const ST = ["全部", "在销", "临近", "逾期", "休眠", "未首单"];
			const BIGF = ["全部", "大客户", "普通"];
			const cityAll = ["全部"].concat(uniqArr(terms.map((t) => String(t.city || "").trim())));
			const typeOpts = uniqArr(["个体诊所", "单体药店", "乡镇卫生院", "村卫生室", "社区卫生服务站", "县域连锁", "民营医院"]
				.concat(terms.map((t) => String(t.type || "").trim())));
			const shown = terms.filter((t) => {
				if (bf === "大客户" && !isBig(t)) return false;
				if (bf === "普通" && isBig(t)) return false;
				if (st !== "全部" && termState(t) !== st) return false;
				if (city !== "全部" && String(t.city || "").trim() !== city) return false;
				return match(t, q, (x) => termState(x));
			});
			const cnt = { 在销: 0, 临近: 0, 逾期: 0, 休眠: 0, 未首单: 0 };
			terms.forEach((t) => { const k = termState(t); if (cnt[k] != null) cnt[k] += 1; });
			const amtSum = terms.reduce((a, t) => a + num(t.amt), 0);
			const covered = new Set(terms.filter((t) => t.city && t.county).map((t) => t.city + "|" + t.county)).size;
			const planN = (db.counties || []).reduce((a, k) => a + num(k.n), 0);
			const todo = terms.map((t) => ({ t, r: repurchase(t), s: termState(t) }))
				.filter((x) => x.s === "逾期" || x.s === "临近")
				.sort((a, b) => num(a.r.days) - num(b.r.days));
			const tone = (v) => (v === "逾期" ? C.warn : v === "临近" ? "#c98a00" : v === "休眠" ? C.sub : v === "在销" ? C.ok : C.sub);
			const bgOf = (v) => (v === "逾期" ? C.warnSoft : v === "临近" ? "#fffbe6" : C.soft);

			return h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "台账终端", value: terms.length + " 家", hint: "大客户 " + terms.filter(isBig).length + " 家 · 普通 " + terms.filter((t) => !isBig(t)).length + " 家" }),
					h(Card, { label: "在销", value: cnt.在销 + " 家", hint: "按复购周期正常进货" }),
					h(Card, { label: "该跑了", value: (cnt.逾期 + cnt.临近) + " 家", tone: cnt.逾期 ? "warn" : "ok", hint: "逾期 " + cnt.逾期 + " · 7 天内 " + cnt.临近 }),
					h(Card, { label: "休眠", value: cnt.休眠 + " 家", tone: cnt.休眠 ? "warn" : undefined, hint: "超两倍周期没进货" }),
					h(Card, { label: "未首单", value: cnt.未首单 + " 家", hint: "开发了还没进货" }),
					h(Card, { label: "月均产出合计", value: fmt(amtSum / 10000, 1) + " 万", hint: covered + " 个县区有终端" })),

				h(Section, { title: "本周该跑的终端", note: "按「最近进货 + 复购周期」算，逾期最久的排最前；跑完把「最近进货」改成当天日期，状态和这张清单自动更新" }),
				todo.length
					? h("div", { style: { border: `1px solid ${C.line}`, borderRadius: 10, overflow: "hidden", marginBottom: 14 } },
						todo.slice(0, 12).map((x, i) => h("div", {
							key: x.t.id,
							style: { display: "flex", alignItems: "center", gap: 12, padding: "7px 12px", borderTop: i ? `1px dashed ${C.line}` : "none", fontSize: 12.5, flexWrap: "wrap" },
						},
							h("span", { style: { width: 132, fontWeight: 600 } }, x.t.name || "未命名"),
							h("span", { style: { width: 110, color: C.sub } }, (x.t.city || "—") + (x.t.county ? " · " + x.t.county : "")),
							h("span", { style: { width: 100, color: C.sub } }, x.t.agent || "未分配"),
							h("span", { style: { width: 104, color: C.sub } }, "应复购 " + (x.r.due || "—")),
							h("span", { style: { color: tone(x.s), fontWeight: 600 } }, x.s === "逾期" ? "逾期 " + Math.abs(num(x.r.days)) + " 天" : num(x.r.days) + " 天后"),
							h("span", { style: { marginLeft: "auto", color: C.sub } }, "电话 " + (x.t.phone || "—")))))
					: h("div", { style: { padding: "16px 0", color: C.ok, fontSize: 12.5 } }, "这几天没有要跑的终端"),

				h(Filter, { q, setQ, placeholder: "搜终端 / 县区 / 代理 / 电话…", chips: ST, value: st, setValue: setSt, shown: shown.length, total: terms.length }),
				h(Filter, { hideSearch: true, chips: cityAll, value: city, setValue: setCity }),
				h(Filter, { hideSearch: true, chips: BIGF, value: bf, setValue: setBf }),

				h(Editable, {
					note: { title: "终端台账", text: "市 / 县区 / 归属代理都能下拉选，也能手输；「最近进货」改成当天日期，复购状态和该跑清单自动更新" },
					head: ["终端名称", "类别", "类型", "市", "县区", "归属代理/负责人", "电话", "月均购进(元)", "首单日", "最近进货", "周期(天)", "应复购", "状态", "等级"],
					widths: ["14%", "8%", "8%", "5%", "8%", "10%", "8%", "7%", "7%", "8%", "5%", "6%", "5%", "3%"],
					fields: [
						{ key: "name" },
						{
							key: "big", align: "center", render: (r) => h("button", {
								onClick: () => edit(r.id, "big", isBig(r) ? "" : "1"),
								title: "点一下切换：大客户 / 普通",
								style: {
									appearance: "none", border: "none", background: "transparent", cursor: "pointer",
									fontFamily: FONT, fontSize: 11.5, padding: "2px 4px", whiteSpace: "nowrap",
									color: isBig(r) ? C.accent : C.sub, fontWeight: isBig(r) ? 700 : 400,
								},
							}, isBig(r) ? "★ 大客户" : "☆ 普通"),
						},
						{ key: "type", align: "center", options: typeOpts },
						{ key: "city", align: "center", options: uniqArr(db.cities.map((c) => String(c.city || "").trim())) },
						{ key: "county", options: (row) => countyNamesIn(db, row.city) },
						{ key: "agent", options: (row) => agentNamesIn(db, row.city) },
						{ key: "phone" },
						{ key: "amt", align: "right" },
						{ key: "firstBuy", align: "center", placeholder: "2025-01-01" },
						{ key: "lastBuy", align: "center", placeholder: "2026-10-01" },
						{ key: "cycle", align: "center", placeholder: "30" },
						{ key: "due", align: "center", render: (r) => repurchase(r).due || "—" },
						{
							key: "state", align: "center", render: (r) => {
								const v = termState(r);
								return h("span", { style: { fontSize: 11, color: tone(v), background: bgOf(v), borderRadius: 999, padding: "1px 8px", whiteSpace: "nowrap" } }, v);
							},
						},
						{
							key: "grade", align: "center", render: (r) => {
								const g = gradeOf(r.amt, r.pot, r.coop);
								return h("span", { style: { fontWeight: 650, color: g === "A" ? C.ok : g === "B" ? "#8a6d00" : C.sub } }, g);
							},
						},
					],
					rows: shown,
					onChange: edit,
					onAdd: () => {
						setQ("");
						setSt("全部");
						setCity("全部");
						setDb((d) => Object.assign({}, d, { customers: d.customers.concat([{ id: nid(), name: "", type: "", city: "", county: "", agent: "", phone: "", amt: "0", pot: "3", coop: "3", products: "", firstBuy: "", lastBuy: "", cycle: "30" }]) }));
					},
					onDelete: (id) => setDb((d) => Object.assign({}, d, { customers: d.customers.filter((r) => r.id !== id) })),
				}));
		}

		function ClientPage({ db, setDb }) {
			const [view, setView] = useState("terminal");
			const [q1, setQ1] = useState("");
			const [g1, setG1] = useState("全部");
			const [q2, setQ2] = useState("");
			const [g2, setG2] = useState("全部");
			const [q3, setQ3] = useState("");
			const [catF, setCatF] = useState("全部");
			const [openCity, setOpenCity] = useState({});
			const [pick, setPick] = useState(null);

			const grade = (amt, pot, coop) => {
				const a = num(amt), p = num(pot), c = num(coop);
				if (p >= 4 && c >= 4) return a >= 5000 ? "A" : "B";
				return a >= 15000 ? "A" : a >= 5000 ? "B" : "C";
			};
			const freq = (g) => (g === "A" ? "≥2 次/月" : g === "B" ? "1 次/月" : "1 次/季");
			const tone = { A: C.ok, B: "#8a6d00", C: C.sub };
			const counts = { A: 0, B: 0, C: 0 };
			db.customers.forEach((c) => { counts[grade(c.amt, c.pot, c.coop)] += 1; });

			const editC = (id, k, v) => setDb((d) => Object.assign({}, d, { customers: d.customers.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));
			const editA = (id, k, v) => setDb((d) => Object.assign({}, d, { agents: d.agents.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));

			const stat = (r) => {
				const t = num(r.task), x = t ? num(r.real) / t : 0;
				return x < 0.6 ? "预警" : x < 0.7 ? "关注" : "正常";
			};

			/* —— 下拉可选项：都从现有数据里取，新加的值下次就出现在下拉里 —— */
			const cityNames = uniqArr(db.cities.map((c) => String(c.city || "").trim()));
			const productNames = uniqArr((db.products || []).map((p) => String(p.name || "").trim()));
			const catAll = catListOf(db);
			const roleOpts = ["地区", "县区"];
			const catOpts = ["全部"].concat(catAll);
			const scopeOpts = ["全部"].concat(productNames);
			const typeOpts = uniqArr(["个体诊所", "单体药店", "乡镇卫生院", "村卫生室", "县域连锁", "民营医院", "社区卫生服务站"]
				.concat(db.customers.map((c) => String(c.type || "").trim())));
			const countyNamesOf = (cityName) => {
				const city = db.cities.filter((c) => String(c.city || "").trim() === String(cityName || "").trim())[0];
				return city ? db.counties.filter((k) => k.city === city.id).map((k) => String(k.name || "").trim()).filter(Boolean) : [];
			};
			const grades = ["A", "B", "C"];
			const shownC = db.customers.filter((r) => {
				if (g1 !== "全部") {
					if (grades.indexOf(g1) >= 0) { if (grade(r.amt, r.pot, r.coop) !== g1) return false; }
					else if (String(r.type || "").trim() !== g1) return false;
				}
				return match(r, q1, (x) => grade(x.amt, x.pot, x.coop) + " " + freq(grade(x.amt, x.pot, x.coop)));
			});
			const statOpts = ["预警", "关注", "正常"];
			const shownA = db.agents.filter((r) => {
				if (g2 !== "全部") {
					if (statOpts.indexOf(g2) >= 0) { if (stat(r) !== g2) return false; }
					else if (!agentCovers(r, g2)) return false;
				}
				return match(r, q2, (x) => stat(x) + " " + catsOf(x).join(" "));
			});

			const reps = db.customers.map((c) => repurchase(c));
			const overdue = reps.filter((r) => r.state === "逾期").length;
			const soon = reps.filter((r) => r.state === "临近").length;
			const never = reps.filter((r) => r.state === "未进货").length;

			const taskSum = db.agents.reduce((a, x) => a + num(x.task), 0);
			const covered = coveredCountyIds(db).size;
			const annual = num(db.settings && db.settings.annualTarget);

			/* —————— 市 → 大类 → 负责人 → 县区 —————— */
			const mix = mixOf(db);
			const cats = mix.cats;
			/** 树上只显示「有占比」或「有人专做」的大类，0% 又没人的先不占地方 */
			const catsShow = cats.filter((c) => mix.share[c] > 0 || db.agents.some((a) => catsOf(a).indexOf("全部") < 0 && agentCovers(a, c)));
			const groups = aggByCity(db);
			let combos = 0;
			let filled = 0;
			groups.forEach((g) => catsShow.forEach((cat) => {
				combos += 1;
				if (catCoverage(db, g.city.city, cat).agents.length) filled += 1;
			}));
			const allRoundCount = db.agents.filter((a) => catsOf(a).indexOf("全部") >= 0).length;
			const key = String(q3 || "").trim().toLowerCase();
			const cityShown = groups.filter((g) => {
				if (!key) return true;
				return String(g.city.city).toLowerCase().indexOf(key) >= 0
					|| db.agents.some((a) => String(a.city).trim() === g.city.city && String(a.name).toLowerCase().indexOf(key) >= 0);
			});
			const allOpen = cityShown.length > 0 && cityShown.every((g) => openCity[g.city.id]);

			const miniBtn = {
				appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 11, padding: "2px 9px",
				borderRadius: 6, border: `1px solid ${C.line}`, background: "#fff", color: C.accent, whiteSpace: "nowrap",
			};
			const pickCellBtn = {
				appearance: "none", border: "none", background: "transparent", padding: "2px 4px", margin: 0,
				fontFamily: FONT, fontSize: 12.5, color: C.ink, cursor: "pointer", textAlign: "left",
				width: "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
			};
			const badge = (txt, col, bg) => h("span", {
				style: { fontSize: 11, color: col || C.sub, background: bg || C.soft, borderRadius: 999, padding: "1px 8px", whiteSpace: "nowrap" },
			}, txt);
			const addAgentHere = (cityName, cat) => setDb((d) => Object.assign({}, d, {
				agents: d.agents.concat([{ id: nid(), name: "", role: "县区", city: cityName, area: "", scope: "", cat: cat, task: "0", real: "0" }]),
			}));
			const rateOf = (a) => { const t = num(a.task); return t ? num(a.real) / t : 0; };
			const agentLine = (a) => {
				const col = rateOf(a) >= 0.7 ? C.ok : rateOf(a) >= 0.6 ? "#8a6d00" : C.warn;
				return h("div", { key: a.id, style: { display: "flex", alignItems: "center", gap: 8, fontSize: 12, flexWrap: "wrap" } },
					h("span", { style: { fontWeight: 600 } }, a.name || "（未命名）"),
					badge(a.role || "—"),
					h("span", { style: { color: C.sub } }, a.area ? String(a.area) : "未写县区"),
					h("span", { style: { color: C.sub } }, `${fmt(num(a.task), 0)} / ${fmt(num(a.real), 0)} 万`),
					h("span", { style: { color: col, fontWeight: 600 } }, pct(rateOf(a))));
			};
			const catRow = (g, cat) => {
				const cov = catCoverage(db, g.city.city, cat);
				const sh = mix.share[cat] || 0;
				const spec = cov.agents.filter((a) => catsOf(a).indexOf("全部") < 0);
				const whole = cov.agents.filter((a) => catsOf(a).indexOf("全部") >= 0);
				return h("div", { key: cat, style: { display: "flex", gap: 10, padding: "8px 0", borderTop: `1px dashed ${C.line}`, alignItems: "flex-start" } },
					h("div", { style: { width: 118, flex: "0 0 118px" } },
						h("div", { style: { fontSize: 12.5, fontWeight: 600 } }, cat),
						h("div", { style: { fontSize: 10.5, color: C.sub } }, `${Math.round(sh * 100)}% · 目标 ${r1(g.t * sh)} 万`)),
					h("div", { style: { flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 4 } },
						spec.length ? h("div", { style: { display: "flex", flexDirection: "column", gap: 3 } }, spec.map(agentLine)) : null,
						whole.length ? h("div", { style: { fontSize: 11.5, color: C.sub } },
							"全品类：" + whole.map((a) => a.name + "（" + (String(a.area || "").indexOf("全市") >= 0 ? "全市" : a.area || "未填") + "）").join("、")) : null,
						!cov.agents.length ? h("div", { style: { fontSize: 11.5, color: C.warn, fontWeight: 600 } },
							"这个大类还没配人 · " + cov.counties.length + " 个县区这个大类没人做") : null,
						cov.agents.length && cov.missing.length
							? h("div", { style: { fontSize: 11.5, color: C.warn } },
								`还有 ${cov.missing.length} 个县区没覆盖：` + cov.missing.slice(0, 8).map((k) => k.name).join("、") + (cov.missing.length > 8 ? " 等" : ""))
							: null),
					h("div", { style: { width: 62, flex: "0 0 62px", textAlign: "right" } },
						h("button", { onClick: () => addAgentHere(g.city.city, cat), style: miniBtn }, "＋ 加人")));
			};
			const cityBlock = (g) => {
				const expanded = !!openCity[g.city.id];
				const ks = g.items;
				const coveredNames = new Set();
				ks.forEach((k) => { if (agentsOfCounty(db, k.name, g.city.city).length) coveredNames.add(k.name); });
				const people = db.agents.filter((a) => String(a.city).trim() === g.city.city);
				const catFilled = catsShow.filter((cat) => catCoverage(db, g.city.city, cat).agents.length).length;
				return h("div", { key: g.city.id, style: { border: `1px solid ${C.line}`, borderRadius: 10, marginBottom: 8, overflow: "hidden", background: "#fff" } },
					h("div", {
						onClick: () => setOpenCity((o) => Object.assign({}, o, { [g.city.id]: !o[g.city.id] })),
						style: { display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", cursor: "pointer", background: "#fbfcfd", flexWrap: "wrap" },
					},
						h("span", { style: { color: C.accent, fontSize: 12, width: 10 } }, expanded ? "▾" : "▸"),
						h("span", { style: { fontSize: 13.5, fontWeight: 650, width: 62 } }, g.city.city || "未命名"),
						badge(ks.length + " 个县区"),
						badge("县区覆盖 " + coveredNames.size + "/" + ks.length, coveredNames.size === ks.length ? C.ok : C.warn, coveredNames.size === ks.length ? C.okSoft : C.warnSoft),
						badge("大类配置 " + catFilled + "/" + catsShow.length, catFilled === catsShow.length ? C.ok : "#8a6d00", catFilled === catsShow.length ? C.okSoft : "#fffbe6"),
						h("span", { style: { marginLeft: "auto", fontSize: 11.5, color: C.sub } }, people.length + " 个负责人 · 目标 " + r1(g.t) + " 万")),
					expanded ? h("div", { style: { padding: "2px 12px 10px" } },
						h("div", { style: { fontSize: 11.5, color: C.sub, padding: "6px 0" } },
							"全品类负责人：" + (people.filter((a) => catsOf(a).indexOf("全部") >= 0).map((a) => a.name + "（" + (a.area || "未填") + "）").join("、") || "无")),
						catsShow.filter((c) => catF === "全部" || c === catF).map((cat) => catRow(g, cat))) : null);
			};

			const viewSwitch = h("div", { style: { display: "flex", gap: 6, marginBottom: 14, borderBottom: `1px solid ${C.line}`, paddingBottom: 10 } },
				[["terminal", "终端台账"], ["agent", "代理与覆盖"]].map(([k, label]) => h("button", {
					key: k,
					onClick: () => setView(k),
					style: {
						appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 12.5,
						padding: "5px 14px", borderRadius: 999, border: `1px solid ${view === k ? C.accent : C.line}`,
						background: view === k ? C.accentSoft : "#fff", color: view === k ? C.accent : C.sub,
					},
				}, label)));

			const agentView = h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "大类配置", value: filled + " / " + combos, tone: filled < combos ? "warn" : "ok", hint: `${groups.length} 个市 × ${catsShow.length} 个大类` }),
					h(Card, { label: "县区覆盖", value: covered + " / " + db.counties.length, hint: "有负责人（不分大类）" }),
					h(Card, { label: "负责人", value: db.agents.length + " 人", hint: `其中全品类 ${allRoundCount} 人` }),
					h(Card, { label: "任务合计", value: fmt(taskSum, 0) + " 万", hint: annual ? `占年度指标 ${pct(taskSum / annual)}` : "年度指标未填" })),

				h(Section, {
					title: "市 → 大类 → 负责人 → 县区",
					note: "一个市一个人全接就在「负责大类」写「全部」；按大类分工就一个人负责一个或几个大类；县区没覆盖到的标红。点市名展开。",
					extra: h("button", {
						onClick: () => {
							const next = {};
							cityShown.forEach((g) => { next[g.city.id] = !allOpen; });
							setOpenCity(Object.assign({}, openCity, next));
						},
						style: S.add,
					}, allOpen ? "全部收起" : "全部展开"),
				}),
				h(Filter, {
					q: q3, setQ: setQ3, placeholder: "筛市 / 负责人…",
					chips: ["全部"].concat(catsShow), value: catF, setValue: setCatF,
					shown: cityShown.length, total: groups.length,
				}),
				cityShown.length ? cityShown.map(cityBlock) : h("div", { style: { padding: "24px 0", textAlign: "center", color: C.sub, fontSize: 12.5 } }, "没搜到"),

				h(Section, { title: "代理商达成率", note: "从低到高排；红＝低于 60%，黄＝低于 70%，绿＝达标 70% 以上" }),
				h(BarList, {
					max: 120,
					labelWidth: 96,
					items: db.agents.slice().sort((a, b) => rateOf(a) - rateOf(b)).map((a) => {
						const x = rateOf(a);
						const col = x < 0.6 ? C.warn : x < 0.7 ? "#c98a00" : C.ok;
						return { label: a.name || "未命名", value: x * 100, color: col, note: pct(x), noteColor: col };
					}),
				}),

				h(Editable, {
					note: { title: "代理商台账", text: "「负责大类」写「全部」＝全品类，写「骨科,皮肤」＝只负责这两个大类；覆盖区域写「全市」或具体县区；达成率、等级、状态自动判定" },
					head: ["代理商 / 负责人", "级别", "城市", "负责大类", "覆盖区域（县区）", "承接产品", "年度任务(万)", "累计回款(万)", "达成率", "等级", "状态"],
					widths: ["13%", "6%", "7%", "13%", "16%", "11%", "9%", "9%", "6%", "5%", "5%"],
					toolbar: h(Filter, {
						q: q2, setQ: setQ2, placeholder: "筛选：代理商 / 城市 / 大类…",
						chips: ["全部"].concat(catAll).concat(statOpts), value: g2, setValue: setG2,
						shown: shownA.length, total: db.agents.length,
					}),
					fields: [
						{ key: "name" },
						{ key: "role", align: "center", options: roleOpts, placeholder: "地区/县区" },
						{ key: "city", align: "center", options: cityNames },
						{
							key: "cat", render: (r) => h("button", {
								onClick: () => setPick({ id: r.id, kind: "cat" }),
								title: "点开多选大类（也能手输）",
								style: pickCellBtn,
							}, String(r.cat || "全部"), h("span", { style: { color: C.sub, marginLeft: 3 } }, "▾")),
						},
						{
							key: "area", render: (r) => h("button", {
								onClick: () => setPick({ id: r.id, kind: "area" }),
								title: "点开多选县区（也能手输）",
								style: pickCellBtn,
							}, String(r.area || "未写县区"), h("span", { style: { color: C.sub, marginLeft: 3 } }, "▾")),
						},
						{ key: "scope", options: scopeOpts },
						{ key: "task", align: "right" }, { key: "real", align: "right" },
						{ key: "rate", align: "right", render: (r) => (num(r.task) ? pct(rateOf(r)) : "—") },
						{
							key: "g", align: "center", render: (r) => {
								const x = rateOf(r);
								const g = x >= 1 ? "A" : x >= 0.7 ? "B" : "C";
								return h("span", { style: { fontWeight: 650, color: tone[g] } }, g);
							}
						},
						{
							key: "st", align: "center", render: (r) => {
								const x = rateOf(r);
								const s = x < 0.6 ? ["预警", C.warn, C.warnSoft] : x < 0.7 ? ["关注", "#8a6d00", "#fffbe6"] : ["正常", C.ok, C.okSoft];
								return h("span", { style: { color: s[1], background: s[2], padding: "1px 8px", borderRadius: 999, fontSize: 11.5 } }, s[0]);
							}
						},
					],
					rows: shownA,
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { agents: d.agents.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => {
						setQ2("");
						setG2("全部");
						setDb((d) => Object.assign({}, d, { agents: d.agents.concat([{ id: nid(), name: "", role: "县区", city: "", area: "", scope: "", cat: "全部", task: "0", real: "0" }]) }));
					},
					onDelete: (id) => setDb((d) => Object.assign({}, d, { agents: d.agents.filter((r) => r.id !== id) })),
				}));

			const terminalView = h(TerminalPanel, { db, setDb });

			/* 覆盖区域 / 负责大类 的多选面板 */
			const pickRow = pick ? db.agents.filter((x) => x.id === pick.id)[0] : null;
			const pickModal = pickRow ? h(MultiPicker, {
				title: pick.kind === "area"
					? "选择覆盖县区 · " + (pickRow.name || "未命名") + (pickRow.city ? "（" + pickRow.city + "）" : "")
					: "选择负责大类 · " + (pickRow.name || "未命名"),
				note: pick.kind === "area"
					? (countyNamesIn(db, pickRow.city).length
						? "勾这个负责人跑的县区；勾「全市」等于整个市都归他。换城市后这里会跟着变。也可以在下面直接手输一串。"
						: "还没填城市——先在「城市」列选好市，这里才会列出县区；也可以直接在下面手输。")
					: "勾他负责的大类；勾「全部」等于全品类。多个大类可以同时勾，比如骨科+皮肤。",
				allLabel: pick.kind === "area" ? "全市" : "全部",
				options: pick.kind === "area" ? countyNamesIn(db, pickRow.city) : catListOf(db),
				value: pick.kind === "area" ? String(pickRow.area || "") : String(pickRow.cat || ""),
				onChange: (v) => {
					const cur = pick.kind === "area" ? String(pickRow.area || "") : String(pickRow.cat || "");
					if (UI.strict && String(v) !== cur) {
						pushChange({ key: "agent-" + pick.kind + "-" + pickRow.id, label: (pickRow.name || "未命名") + (pick.kind === "area" ? " · 覆盖区域" : " · 负责大类"), from: cur, to: String(v), set: (x) => editA(pickRow.id, pick.kind, x) });
					}
					editA(pickRow.id, pick.kind, v);
				},
				onClose: () => setPick(null),
			}) : null;

			return h("div", null, viewSwitch, view === "terminal" ? terminalView : agentView, pickModal);
		}

		function WeeklyPage({ db, setDb }) {
			const done = db.plan.filter((p) => p.done).length;
			const toggle = (id) => setDb((d) => Object.assign({}, d, { plan: d.plan.map((r) => (r.id === id ? Object.assign({}, r, { done: !r.done }) : r)) }));

			const [q1, setQ1] = useState("");
			const [stage, setStage] = useState("全部");
			const stages = ["全部"].concat(Array.from(new Set(db.plan.map((p) => p.stage || "未分组"))));
			const shownPlan = db.plan.filter((p) => (stage === "全部" || (p.stage || "未分组") === stage) && match(p, q1));

			const [q2, setQ2] = useState("");
			const shownQ = db.weekq.filter((r) => match(r, q2));

			return h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "已完成周次", value: done + " / " + db.plan.length }),
					h(Card, { label: "当前阶段", value: (db.plan[Math.min(done, db.plan.length - 1)] || {}).stage || "—" }),
					h(Card, { label: "进度", value: pct(db.plan.length ? done / db.plan.length : 0), tone: done >= 6 ? "ok" : undefined })),

				h(Editable, {
					note: { title: "90 天排期", text: "打勾记进度；周次、阶段、动作、交付物都能改" },
					head: ["", "周次", "阶段", "关键动作", "交付物"],
					widths: ["6%", "11%", "11%", "44%", "28%"],
					toolbar: h(Filter, {
						q: q1, setQ: setQ1, placeholder: "筛选：周次 / 阶段 / 动作…",
						chips: stages, value: stage, setValue: setStage,
						shown: shownPlan.length, total: db.plan.length,
					}),
					fields: [
						{
							key: "done", align: "center", render: (r) => h("input", {
								type: "checkbox", checked: !!r.done, onChange: () => toggle(r.id), style: { cursor: "pointer" },
							})
						},
						{ key: "week" }, { key: "stage", align: "center", options: stages.filter((x) => x !== "全部") }, { key: "action" }, { key: "output" },
					],
					rows: shownPlan,
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { plan: d.plan.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { plan: d.plan.concat([{ id: nid(), week: "", stage: "", action: "", output: "", done: false }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { plan: d.plan.filter((r) => r.id !== id) })),
				}),

				h(Editable, {
					note: { title: "周会六问", text: "每周固定 30—40 分钟，只问六个问题" },
					head: ["问题", "目的"],
					widths: ["38%", "62%"],
					toolbar: h(Filter, { q: q2, setQ: setQ2, placeholder: "筛选问题…", shown: shownQ.length, total: db.weekq.length }),
					fields: [{ key: "q" }, { key: "purpose" }],
					rows: shownQ,
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { weekq: d.weekq.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { weekq: d.weekq.concat([{ id: nid(), q: "", purpose: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { weekq: d.weekq.filter((r) => r.id !== id) })),
				}));
		}

		function MetricPage({ db, setDb }) {
			const rows = db.board;
			const ytdActual = rows.reduce((a, r) => a + num(r.actual), 0);
			const ytdTarget = rows.reduce((a, r) => a + num(r.target), 0);

			const [q1, setQ1] = useState("");
			const shownB = db.board.filter((r) => match(r, q1));

			const [q2, setQ2] = useState("");
			const [lv, setLv] = useState("全部");
			const levels = ["全部"].concat(Array.from(new Set(db.metrics.map((m) => m.level || "未分组"))));
			const shownM = db.metrics.filter((m) => (lv === "全部" || (m.level || "未分组") === lv) && match(m, q2));

			const filled = db.board.filter((b) => b.actual !== "");
			const labels = filled.map((b) => b.month);
			const canChart = labels.length >= 2;
			const conv = convOf(db);

			return h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "累计回款", value: fmt(ytdActual, 1) + " 万" }),
					h(Card, { label: "累计目标", value: fmt(ytdTarget, 1) + " 万" }),
					h(Card, { label: "累计达成", value: ytdTarget ? pct(ytdActual / ytdTarget) : "—", tone: ytdTarget && ytdActual / ytdTarget < 0.95 ? "warn" : "ok" }),
					h(Card, { label: "累计分值", value: fmt(ytdActual * conv, 0) + " 分", hint: `目标 ${fmt(ytdTarget * conv, 0)} 分` })),

				h(Section, {
					title: "回款 vs 目标（月度趋势）",
					note: canChart ? "灰色虚线＝目标，蓝线＝回款，绿线＝纯销；只画已填写的月份" : "至少填两个月的数据才能画趋势",
				}),
				canChart ? h(LineChart, {
					labels,
					series: [
						{ name: "目标", values: filled.map((b) => num(b.target)), color: "#c3cad4", dashed: true },
						{ name: "回款", values: filled.map((b) => (b.actual === "" ? "" : num(b.actual))), color: C.accent },
						{ name: "纯销", values: filled.map((b) => (b.pure === "" ? "" : num(b.pure))), color: C.ok },
					],
					unit: " 万",
				}) : null,

				h(Editable, {
					note: { title: "月度经营看板", text: "月份、目标、回款、纯销、库存、活跃终端都能改；达成率与单产自动算" },
					head: ["月份", "目标(万)", "回款实际(万)", "达成率", "分值", "纯销(万)", "库存天数", "活跃终端", "单产(元)"],
					widths: ["9%", "11%", "12%", "10%", "9%", "11%", "11%", "12%", "14%"],
					toolbar: h(Filter, { q: q1, setQ: setQ1, placeholder: "筛选月份…", shown: shownB.length, total: db.board.length }),
					fields: [
						{ key: "month" },
						{ key: "target", align: "right" },
						{ key: "actual", align: "right" },
						{
							key: "rate", align: "right", render: (r) => {
								if (r.actual === "") return "—";
								const x = num(r.target) ? num(r.actual) / num(r.target) : 0;
								return h("span", { style: { color: x < 0.95 ? C.warn : C.ink, fontWeight: 600 } }, pct(x));
							}
						},
						{ key: "pts", align: "right", render: (r) => (r.actual === "" ? "—" : h("span", { style: { color: C.accent } }, fmt(num(r.actual) * conv, 0))) },
						{ key: "pure", align: "right" },
						{
							key: "inv", align: "right", render: (r) => h("span", { style: { color: num(r.inv) > 60 ? C.warn : C.ink } },
								h(Cell, { value: r.inv, align: "right", onChange: (v) => setDb((d) => Object.assign({}, d, { board: d.board.map((x) => (x.id === r.id ? Object.assign({}, x, { inv: v }) : x)) })) }))
						},
						{ key: "active", align: "right" },
						{
							key: "unit", align: "right", render: (r) => {
								const a = num(r.active);
								return a ? fmt(num(r.pure) * 10000 / a, 0) : "—";
							}
						},
					],
					rows: shownB,
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { board: d.board.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { board: d.board.concat([{ id: nid(), month: "", target: "0", actual: "", pure: "", inv: "", active: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { board: d.board.filter((r) => r.id !== id) })),
				}),

				h(Editable, {
					note: { title: "指标词典", text: "口径统一用；可以按你们公司的定义改" },
					head: ["层级", "指标", "算法", "频率", "预警线"],
					widths: ["9%", "22%", "40%", "10%", "19%"],
					toolbar: h(Filter, {
						q: q2, setQ: setQ2, placeholder: "筛选：指标 / 算法…",
						chips: levels, value: lv, setValue: setLv,
						shown: shownM.length, total: db.metrics.length,
					}),
					fields: [
						{ key: "level", align: "center", options: levels.filter((x) => x !== "全部") },
						{ key: "name" }, { key: "formula" },
						{ key: "freq", align: "center", options: ["日", "周", "月", "季", "年"] },
						{ key: "warn", align: "center" }],
					rows: shownM,
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { metrics: d.metrics.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { metrics: d.metrics.concat([{ id: nid(), level: "", name: "", formula: "", freq: "", warn: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { metrics: d.metrics.filter((r) => r.id !== id) })),
				}));
		}

		/* ---------------------------- 产品价格 / 分值 ---------------------------- */

		function ProductPage({ db, setDb }) {
			const [q, setQ] = useState("");
			const [cat, setCat] = useState("全部");
			const [view, setView] = useState("catalog");
			const [detail, setDetail] = useState(null);
			const [editCat, setEditCat] = useState(false);
			const [pcat, setPcat] = useState("全部");
			const conv = convOf(db);
			const base = (db.settings && db.settings.convBase) || "county";
			const autoConv = (() => {
				const ps = db.products.filter((p) => convBasePrice(p, base) > 0 && num(p.pts) > 0);
				return ps.length ? ps.reduce((a, p) => a + (num(p.pts) / convBasePrice(p, base)) * 10000, 0) / ps.length : 0;
			})();
			const shown = db.products.filter((p) => (pcat === "全部" || ((catOf(db, p.name) || {}).cat || "未分类").trim() === pcat) && match(p, q));
			const avgPts = db.products.length ? db.products.reduce((a, p) => a + num(p.pts), 0) / db.products.length : 0;
			const gC = (p) => num(p.supply) - num(p.county);   // 县区自营
			const gR = (p) => num(p.supply) - num(p.region);   // 地区自营
			const gD = (p) => num(p.county) - num(p.region);   // 地区分销给县区
			const rate = (g, p) => (num(p.supply) ? g(p) / num(p.supply) : 0);
			const avg = (fn) => (db.products.length ? db.products.reduce((a, p) => a + fn(p), 0) / db.products.length : 0);

			const edit = (id, k, v) => setDb((d) => Object.assign({}, d, { products: d.products.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));
			const editCatRow = (id, k, v) => setDb((d) => Object.assign({}, d, { catalog: (d.catalog || []).map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));

			/* —————— 品种目录：大类 → 小类 → 品种 —————— */
			const catalog = catalogOf(db);
			const rowsOf = (name) => (db.products || []).filter((p) => normName(p.name) === normName(name));
			const catAll = (() => {
				const s = [];
				catalog.forEach((r) => { const c = String(r.cat || "未分类").trim(); if (s.indexOf(c) < 0) s.push(c); });
				return s.sort((a, b) => catRank(a) - catRank(b));
			})();
			const catShown = catalog.filter((r) => (cat === "全部" || String(r.cat || "未分类").trim() === cat) && match(r, q));
			const pricedCount = catalog.filter((r) => rowsOf(r.name).length).length;
			const specTotal = catalog.reduce((a, r) => a + Math.max(1, specList(r.spec).length), 0);
			const tree = (() => {
				const out = [];
				catShown.forEach((r) => {
					const cn = String(r.cat || "未分类").trim(), sn = String(r.sub || "未分类").trim();
					let g = out.filter((x) => x.cat === cn)[0];
					if (!g) { g = { cat: cn, subs: [] }; out.push(g); }
					let s = g.subs.filter((x) => x.sub === sn)[0];
					if (!s) { s = { sub: sn, items: [] }; g.subs.push(s); }
					s.items.push(r);
				});
				out.sort((a, b) => catRank(a.cat) - catRank(b.cat));
				return out;
			})();
			const tagsOf = (r) => String(r.qual || "").split(/[·、，,]/).map((x) => x.trim()).filter(Boolean);
			const tagStyle = (t) => (/独家|专利|保护|原研|新药|名牌/.test(t) ? { color: C.accent, bg: C.accentSoft }
				: /医保|基药/.test(t) ? { color: C.ok, bg: C.okSoft } : { color: C.sub, bg: "#f4f6f8" });
			const addPrice = (r) => setDb((d) => {
				if ((d.products || []).some((p) => normName(p.name) === normName(r.name))) return d;
				return Object.assign({}, d, {
					products: (d.products || []).concat([{ id: nid(), name: r.name, spec: specList(r.spec)[0] || r.spec || "", pts: "0", retail: "0", supply: "0", county: "0", region: "0", days: "" }]),
				});
			});
			const addAllPrice = () => setDb((d) => {
				const have = {};
				(d.products || []).forEach((p) => { have[normName(p.name)] = 1; });
				const add = (d.catalog || []).filter((r) => !have[normName(r.name)]).map((r) => ({ id: nid(), name: r.name, spec: specList(r.spec)[0] || r.spec || "", pts: "0", retail: "0", supply: "0", county: "0", region: "0", days: "" }));
				return add.length ? Object.assign({}, d, { products: (d.products || []).concat(add) }) : d;
			});
			const kv = (k, v) => h("div", { style: { display: "flex", gap: 12, padding: "6px 0", borderBottom: `1px dashed ${C.line}` } },
				h("div", { style: { flex: "0 0 72px", width: 72, fontSize: 12, color: C.sub } }, k),
				h("div", { style: { flex: 1, fontSize: 12.5, whiteSpace: "pre-wrap" } }, v || "—"));
			const catCard = (r) => {
				const ps = rowsOf(r.name);
				const p0 = ps[0];
				/** 多个品规时显示区间，如 0.8~1.9 */
				const span = (vals) => {
					const v = vals.map((x) => num(x)).filter((x) => x > 0);
					if (!v.length) return "—";
					const lo = Math.min.apply(null, v), hi = Math.max.apply(null, v);
					return lo === hi ? String(lo) : lo + "~" + hi;
				};
				return h("div", {
					key: r.id,
					onClick: () => setDetail(r),
					style: { border: `1px solid ${C.line}`, borderRadius: 10, padding: "11px 13px", background: "#fff", cursor: "pointer", display: "flex", flexDirection: "column", gap: 5, minWidth: 0 },
				},
					h("div", { style: { display: "flex", alignItems: "baseline", gap: 7, flexWrap: "wrap" } },
						h("div", { style: { fontSize: 14, fontWeight: 650 } }, r.name),
						ps.length
							? h("span", { style: { fontSize: 11, color: C.sub } }, ps.length + " 个品规")
							: h("span", { style: { fontSize: 11, color: C.warn } }, "未进价格表")),
					r.sell ? h("div", { style: { fontSize: 11.5, color: C.warn, fontWeight: 600 } }, r.sell) : null,
					h("div", { style: { display: "flex", gap: 4, flexWrap: "wrap" } },
						tagsOf(r).slice(0, 4).map((t, i) => {
							const c = tagStyle(t);
							return h("span", { key: i, style: { fontSize: 10.5, padding: "1px 7px", borderRadius: 999, color: c.color, background: c.bg } }, t);
						})),
					h("div", { style: { fontSize: 11.5, color: C.sub } }, "规格：" + (r.spec || "—")),
					h("div", { style: { fontSize: 11.5, color: "#4b5563", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" } }, r.act || ""),
					h("div", { style: { display: "flex", gap: 10, alignItems: "center", fontSize: 11.5, color: C.sub, borderTop: `1px dashed ${C.line}`, paddingTop: 5 } },
						p0
							? h("span", null, "分值 " + span(ps.map((p) => p.pts)) + " · 县区 " + span(ps.map((p) => p.county)) + " · 地区 " + span(ps.map((p) => p.region)))
							: h("span", null, "价格未录入"),
						p0 ? null : h("span", {
							style: { color: C.accent, cursor: "pointer" },
							onClick: (e) => { if (e && e.stopPropagation) e.stopPropagation(); addPrice(r); },
						}, "＋ 加入价格表")),
				);
			};

			const priceView = h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "产品数", value: db.products.length + " 个" }),
					h(Card, { label: "县区自营", value: fmt(avg(gC), 1) + " 元/盒", hint: `毛利 ${pct(avg((p) => rate(gC, p)))} · 给终端 − 县区价` }),
					h(Card, { label: "地区自营", value: fmt(avg(gR), 1) + " 元/盒", hint: `毛利 ${pct(avg((p) => rate(gR, p)))} · 给终端 − 地区价` }),
					h(Card, { label: "地区分销", value: fmt(avg(gD), 1) + " 元/盒", hint: "县区价 − 地区价" }),
					h(Card, { label: "分/万元", value: fmt(conv, 0), hint: `按${base === "county" ? "县区价" : base === "supply" ? "供货价" : "地区价"}算 · 1 分 ≈ ${conv ? fmt(10000 / conv, 1) : "—"} 元` })),

				h(Section, { title: "三级各自挣多少", note: "县区自营 = 给终端价 − 县区拿货价；地区自营 = 给终端价 − 地区拿货价；地区分销 = 县区拿货价 − 地区拿货价" }),
				h("div", { style: { display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap", padding: "10px 12px", border: `1px solid ${C.line}`, borderRadius: 10, marginBottom: 12 } },
					h("label", { style: { fontSize: 12.5, color: C.sub } }, "年度指标："),
					h("input", {
						value: (db.settings && db.settings.annualTarget) || "",
						onChange: (e) => setDb((d) => Object.assign({}, d, { settings: Object.assign({}, d.settings, { annualTarget: e.target.value }) })),
						style: { width: 96, padding: "5px 9px", border: `1px solid ${C.line}`, borderRadius: 7, fontSize: 12.5, fontFamily: FONT, textAlign: "right", background: "#fffdf5" },
					}),
					h("span", { style: { fontSize: 12, color: C.sub } }, "万元 — 改这里，指标分解的各市目标会自动重算")),
				h("div", { style: { display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", padding: "10px 12px", border: `1px solid ${C.line}`, borderRadius: 10, marginBottom: 12 } },
					h("label", { style: { fontSize: 12.5, color: C.sub } }, "公司回款按哪个价："),
					[["region", "地区价（公司收款）"], ["county", "县区价"], ["supply", "供货价（给终端）"]].map(([k, label]) => h("button", {
						key: k,
						onClick: () => setDb((d) => Object.assign({}, d, { settings: Object.assign({}, d.settings, { convBase: k }) })),
						style: {
							appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 12,
							padding: "4px 11px", borderRadius: 999, border: `1px solid ${base === k ? C.accent : C.line}`,
							background: base === k ? C.accentSoft : "#fff", color: base === k ? C.accent : C.sub,
						},
					}, label)),
					h("span", { style: { fontSize: 11.5, color: C.sub } }, "决定「分/万元」和折合目标分")),
				h("div", { style: { display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap", padding: "10px 12px", border: `1px solid ${C.line}`, borderRadius: 10, marginBottom: 14 } },
					h("label", { style: { fontSize: 12.5, color: C.sub } }, "手工指定 分/万元："),
					h("input", {
						value: (db.settings && db.settings.conv) || "",
						placeholder: `自动（${fmt(autoConv, 0)}）`,
						onChange: (e) => setDb((d) => Object.assign({}, d, { settings: Object.assign({}, d.settings, { conv: e.target.value }) })),
						style: { width: 110, padding: "5px 9px", border: `1px solid ${C.line}`, borderRadius: 7, fontSize: 12.5, fontFamily: FONT, textAlign: "right" },
					}),
					h("span", { style: { fontSize: 12, color: C.sub } },
						`当前：1 万元 ≈ ${fmt(conv, 0)} 分；目标 100 万元 ≈ ${fmt(100 * conv, 0)} 分`)),

				h("div", { style: { display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap", padding: "10px 12px", border: `1px solid ${C.line}`, borderRadius: 10, marginBottom: 14 } },
					h("label", { style: { fontSize: 12.5, color: C.sub } }, "指标以分为准时，月目标分："),
					h("input", {
						value: (db.settings && db.settings.monthPoints) || "",
						placeholder: "如 80000",
						onChange: (e) => setDb((d) => Object.assign({}, d, { settings: Object.assign({}, d.settings, { monthPoints: e.target.value }) })),
						style: { width: 110, padding: "5px 9px", border: `1px solid ${C.line}`, borderRadius: 7, fontSize: 12.5, fontFamily: FONT, textAlign: "right" },
					}),
					h("span", { style: { fontSize: 12, color: C.sub } },
						num(db.settings && db.settings.monthPoints) && conv
							? `≈ ${fmt(num(db.settings.monthPoints) / conv, 1)} 万元/月 · ${fmt((num(db.settings.monthPoints) / conv) / 30, 2)} 万元/天`
							: "填分数，自动折成金额")),

				h("div", { style: S.cards },
					h(Card, { label: "年度目标（金额）", value: fmt(num(db.settings.annualTarget), 0) + " 万" }),
					h(Card, { label: "折合目标分", value: fmt(num(db.settings.annualTarget) * conv, 0) + " 分", tone: "ok" }),
					h(Card, { label: "月均目标分", value: fmt(num(db.settings.annualTarget) * conv / 12, 0) + " 分" })),

				h(Editable, {
					note: { title: "产品价格表", text: "全部可改；前两列的大类/小类来自「品种目录」，毛利、毛利率、分/万元是自动算的" },
					head: ["大类", "小类", "产品", "规格", "分值", "零售价", "给终端价", "县区价", "地区价", "天数", "县区毛利", "县区率", "地区自营", "地区分销", "县区扣", "地区扣"],
					widths: ["6%", "7%", "9%", "8%", "5%", "6%", "7%", "6%", "6%", "7%", "6%", "5%", "6%", "6%", "6%", "6%"],
					toolbar: h(Filter, {
						q, setQ, placeholder: "筛选产品 / 规格…",
						chips: ["全部"].concat(uniqArr(catListOf(db))), value: pcat, setValue: setPcat,
						shown: shown.length, total: db.products.length,
					}),
					fields: [
						{
							key: "catl", render: (r) => {
								const c = catOf(db, r.name);
								return c && c.cat
									? h("span", { style: { fontSize: 11, color: C.accent, background: C.accentSoft, padding: "1px 6px", borderRadius: 999, whiteSpace: "nowrap" } }, c.cat)
									: h("span", { style: { fontSize: 11, color: C.sub } }, "未归类");
							},
						},
						{ key: "subl", render: (r) => { const c = catOf(db, r.name); return h("span", { style: { fontSize: 11, color: C.sub } }, c ? c.sub || "—" : ""); } },
						{ key: "name" }, { key: "spec" }, { key: "pts", align: "right" },
						{ key: "retail", align: "right" }, { key: "supply", align: "right" },
						{ key: "county", align: "right" }, { key: "region", align: "right" },
						{ key: "days" },
						{
							key: "gC", align: "right", render: (r) => {
								const g = gC(r);
								return h("span", { style: { color: g <= 0 ? C.warn : C.ink, fontWeight: 600 } }, fmt(g, 1));
							}
						},
						{ key: "rC", align: "right", render: (r) => (num(r.supply) ? pct(rate(gC, r)) : "—") },
						{ key: "gR", align: "right", render: (r) => h("span", { style: { color: gR(r) <= 0 ? C.warn : C.ink } }, fmt(gR(r), 1)) },
						{ key: "gD", align: "right", render: (r) => h("span", { style: { color: gD(r) <= 0 ? C.warn : C.ink } }, fmt(gD(r), 1)) },
						{ key: "crate", align: "right", render: (r) => (num(r.supply) ? Math.round((num(r.county) / num(r.supply)) * 100) + " 扣" : "—") },
						{ key: "rrate", align: "right", render: (r) => (num(r.supply) ? Math.round((num(r.region) / num(r.supply)) * 100) + " 扣" : "—") },
					],
					rows: shown,
					onChange: edit,
					onAdd: () => setDb((d) => Object.assign({}, d, { products: d.products.concat([{ id: nid(), name: "", spec: "", pts: "0", retail: "0", supply: "0", county: "0", region: "0", days: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { products: d.products.filter((r) => r.id !== id) })),
				}),

				h(Section, { title: "怎么用分值", note: "" }),
				h("ul", { style: { margin: "0 0 0 18px", padding: 0, color: "#374151", fontSize: 12.5 } },
					[
						`指标分解里的「目标分」＝ 年目标金额 × ${fmt(conv, 0)}；改金额，分自动跟着变。`,
						"指标看板里每个月的「分值」＝ 当月回款 × 换算率，按分算达成。",
						"想按单品算分：分 = 盒数 × 分值；这张表的「分/万元」列就是每卖一万元能拿多少分。",
					].map((t, i) => h("li", { key: i, style: { marginBottom: 4 } }, t))));

			const viewSwitch = h("div", { style: { display: "flex", gap: 6, marginBottom: 14, borderBottom: `1px solid ${C.line}`, paddingBottom: 10 } },
				[["catalog", "品种目录"], ["price", "价格与分值"]].map(([k, label]) => h("button", {
					key: k,
					onClick: () => setView(k),
					style: {
						appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 12.5,
						padding: "5px 14px", borderRadius: 999, border: `1px solid ${view === k ? C.accent : C.line}`,
						background: view === k ? C.accentSoft : "#fff", color: view === k ? C.accent : C.sub,
					},
				}, label)));

			const catalogView = h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "大类", value: catAll.length + " 个", hint: catAll.join("、") }),
					h(Card, { label: "品种", value: catalog.length + " 个" }),
					h(Card, { label: "品规", value: specTotal + " 个", hint: "按目录规格条数" }),
					h(Card, { label: "已录价格", value: pricedCount + " / " + catalog.length, tone: pricedCount < catalog.length ? "warn" : "ok", hint: pricedCount < catalog.length ? "没录价的不计分、不算毛利" : "全部已录入" })),
				h(Filter, { q, setQ, placeholder: "搜品种 / 主治 / 成份 / 资质…", chips: ["全部"].concat(catAll), value: cat, setValue: setCat, shown: catShown.length, total: catalog.length }),
				pricedCount < catalog.length
					? h("div", { style: { display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", padding: "9px 12px", border: `1px solid ${C.line}`, borderRadius: 10, marginBottom: 6, background: "#fffdf5" } },
						h("span", { style: { fontSize: 12, color: C.sub } }, "还有 " + (catalog.length - pricedCount) + " 个品种没进价格表"),
						h("button", { onClick: addAllPrice, style: Object.assign({}, S.add, { margin: 0 }) }, "全部加入价格表"))
					: null,
				tree.length
					? tree.map((g) => h("div", { key: g.cat, style: { marginTop: 10 } },
						h(Section, { title: g.cat, note: g.subs.length + " 个小类 · " + g.subs.reduce((a, s) => a + s.items.length, 0) + " 个品种" }),
						g.subs.map((s) => h("div", { key: s.sub, style: { marginBottom: 12 } },
							h("div", { style: { display: "flex", alignItems: "center", gap: 8, margin: "0 0 8px" } },
								h("span", { style: { width: 3, height: 12, background: C.accent, borderRadius: 2 } }),
								h("span", { style: { fontSize: 12.5, fontWeight: 600 } }, s.sub),
								h("span", { style: { fontSize: 11, color: C.sub } }, s.items.length + " 个")),
							h("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(270px, 1fr))", gap: 10 } },
								s.items.map(catCard))))))
					: h("div", { style: { padding: "40px 0", textAlign: "center", color: C.sub, fontSize: 12.5 } }, "没搜到，换个关键字"),
				h("div", { style: { marginTop: 18, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" } },
					h("button", { onClick: () => setEditCat(!editCat), style: S.add }, editCat ? "收起编辑" : "✎ 编辑品种目录"),
					h("span", { style: { fontSize: 11.5, color: C.sub } }, "大类、小类、卖点、成份、主治都能改，改完上面的分组自动重排")),
				editCat ? h(Editable, {
					note: { title: "品种目录（可直接改）", text: "大类决定分组：骨科 / 皮肤 / 儿科与呼吸 / 补益与男科妇科 / 口腔 / 胃肠与补液；小类是组内分组，可自己起名" },
					head: ["大类", "小类", "品种", "一句话卖点", "资质", "规格", "主要成份", "功能主治", "用法用量"],
					widths: ["8%", "9%", "10%", "16%", "12%", "11%", "12%", "12%", "10%"],
					fields: [
						{ key: "cat", options: uniqArr(catListOf(db)) },
						{ key: "sub", options: uniqArr(catalog.map((r) => String(r.sub || "").trim())) },
						{ key: "name" }, { key: "sell" }, { key: "qual" }, { key: "spec" }, { key: "ing" }, { key: "act" }, { key: "use" }],
					rows: catShown,
					onChange: editCatRow,
					onAdd: () => setDb((d) => Object.assign({}, d, { catalog: (d.catalog || []).concat([{ id: nid(), cat: "", sub: "", name: "", sell: "", qual: "", spec: "", ing: "", act: "", use: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { catalog: (d.catalog || []).filter((r) => r.id !== id) })),
				}) : null);

			const detailModal = detail ? h(Modal, {
				title: detail.name,
				onClose: () => setDetail(null),
				width: 720,
				footer: h("div", { style: { display: "flex", gap: 8 } },
					h("button", { onClick: () => setDetail(null), style: S.add }, "关闭")),
			},
				h("div", { style: { display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 } },
					h("span", { style: { fontSize: 11.5, color: C.accent, background: C.accentSoft, padding: "2px 9px", borderRadius: 999 } },
						(detail.cat || "未分类") + " · " + (detail.sub || "未分类")),
					tagsOf(detail).map((t, i) => {
						const c = tagStyle(t);
						return h("span", { key: i, style: { fontSize: 11, padding: "2px 8px", borderRadius: 999, color: c.color, background: c.bg } }, t);
					})),
				detail.sell ? h("div", { style: { fontSize: 13.5, color: C.warn, fontWeight: 650, marginBottom: 8 } }, detail.sell) : null,
				kv("规格", detail.spec), kv("主要成份", detail.ing), kv("功能主治", detail.act), kv("用法用量", detail.use),
				h("div", { style: { marginTop: 12, marginBottom: 4, fontSize: 12.5, fontWeight: 600 } }, "价格与分值"),
				rowsOf(detail.name).length
					? h("div", { style: { marginTop: 2 } }, rowsOf(detail.name).map((p, i) => h("div", {
						key: i,
						style: { fontSize: 12, padding: "5px 0", borderBottom: `1px dashed ${C.line}`, display: "flex", gap: 12, flexWrap: "wrap" },
					},
						h("span", { style: { flex: "0 0 150px", color: C.ink } }, p.spec || "—"),
						h("span", null, "分值 " + (p.pts || 0) + " · 零售 " + (p.retail || 0) + " · 给终端 " + (p.supply || 0)),
						h("span", null, "县区 " + (p.county || 0) + " · 地区 " + (p.region || 0)),
						h("span", { style: { color: C.ok } }, "县区毛利 " + fmt(num(p.supply) - num(p.county), 1)))))
					: h("div", { style: { display: "flex", gap: 10, alignItems: "center", marginTop: 4 } },
						h("span", { style: { fontSize: 12, color: C.warn } }, "这个品种还没进价格表"),
						h("button", { onClick: () => addPrice(detail), style: Object.assign({}, S.add, { margin: 0 }) }, "＋ 加入价格表"))) : null;

			return h("div", null, viewSwitch, view === "catalog" ? catalogView : priceView, detailModal);
		}

		/* ---------------------------- 风险与行动 ---------------------------- */

		function risksOf(db) {
			const out = [];
			const groups = aggByCity(db);

			db.agents.forEach((a) => {
				const t = num(a.task);
				const x = t ? num(a.real) / t : 0;
				if (x < 0.6) out.push({ level: "高", who: a.name || "未命名代理", what: `达成 ${pct(x)}，低于 60%`, how: "约谈：降目标或缩区域，两个季度不达标按协议收区", tab: "client" });
				else if (x < 0.7) out.push({ level: "中", who: a.name || "未命名代理", what: `达成 ${pct(x)}，低于 70%`, how: "周会列入重点，配一次协同拜访", tab: "client" });
			});

			const filled = db.board.filter((b) => b.actual !== "");
			const last = filled.length ? filled[filled.length - 1] : null;
			if (last) {
				const x = num(last.target) ? num(last.actual) / num(last.target) : 0;
				if (x < 0.95) out.push({ level: "高", who: last.month, what: `达成 ${pct(x)}，差 ${r1(num(last.target) - num(last.actual))} 万`, how: "本月补缺口：新增终端优先，其次提单产", tab: "metric" });
			}
			db.board.forEach((b) => {
				if (b.inv !== "" && num(b.inv) > 60) out.push({ level: "中", who: b.month, what: `库存 ${b.inv} 天，超红线`, how: "停发货、转动销，查是不是压货", tab: "metric" });
			});

			groups.forEach((g) => {
				if (!g.items.length) out.push({ level: "中", who: g.city.city || "未命名市", what: "还没有拆到县区，目标落不到人", how: "展开指标分解补县区", tab: "goal" });
				const gap = g.t - g.e;
				if (gap > 0 && g.n > 0 && gap / Math.max(1, g.e) > 0.3) out.push({ level: "中", who: g.city.city || "未命名市", what: `缺口 ${r1(gap)} 万，相当于现有产出的 ${pct(gap / g.e)}`, how: "要么加终端，要么提单产，二选一先算账", tab: "goal" });
			});

			const blank = db.strategy.filter((s) => !String(s.answer || "").trim()).length;
			if (blank) out.push({ level: "低", who: "一省一策", what: `${blank} 个模块没写答案`, how: "下周开会前补完", tab: "review" });

			const undone = db.plan.filter((p) => !p.done).length;
			if (undone) out.push({ level: "低", who: "90 天", what: `${undone} 项未完成`, how: "周会过一遍，卡住的当场定动作", tab: "weekly" });

			const order = { 高: 0, 中: 1, 低: 2 };
			return out.sort((a, b) => order[a.level] - order[b.level]);
		}

		function RiskPage({ db, setDb, onGo }) {
			const risks = risksOf(db);
			const acts = db.actions || [];
			const todo = acts.filter((a) => a.status !== "已完成").length;
			const done = acts.filter((a) => a.status === "已完成").length;
			const color = { 高: C.warn, 中: "#8a6d00", 低: C.sub };
			const bg = { 高: C.warnSoft, 中: "#fffbe6", 低: C.soft };

			const editAct = (id, k, v) => setDb((d) => Object.assign({}, d, { actions: d.actions.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));
			const cycle = (a) => editAct(a.id, "status", a.status === "未开始" ? "进行中" : a.status === "进行中" ? "已完成" : "未开始");
			const delAct = (id) => setDb((d) => Object.assign({}, d, { actions: d.actions.filter((r) => r.id !== id) }));

			return h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "高风险", value: risks.filter((r) => r.level === "高").length + " 项", tone: "warn" }),
					h(Card, { label: "中风险", value: risks.filter((r) => r.level === "中").length + " 项" }),
					h(Card, { label: "待办行动", value: todo + " 项" }),
					h(Card, { label: "已完成行动", value: done + " 项", tone: "ok" })),

				h(Section, { title: "风险清单", note: "按严重程度排序，点「去处理」直接跳到对应表" }),
				h("table", { style: S.table },
					h("thead", null, h("tr", null, ["级别", "对象", "问题", "建议动作", ""].map((t, i) =>
						h("th", { key: i, style: Object.assign({}, S.th, { width: ["7%", "16%", "32%", "38%", "7%"] [i] }) }, t)))),
					h("tbody", null, risks.map((r, i) => h("tr", { key: i, style: i % 2 ? { background: "#fbfcfd" } : null },
						h("td", { style: Object.assign({}, S.td, { textAlign: "center" }) },
							h("span", { style: { fontSize: 11, color: color[r.level], background: bg[r.level], borderRadius: 999, padding: "1px 8px" } }, r.level)),
						h("td", { style: S.td }, r.who),
						h("td", { style: S.td }, r.what),
						h("td", { style: S.td }, r.how),
						h("td", { style: Object.assign({}, S.td, { textAlign: "center" }) },
							h("button", { onClick: () => onGo(r.tab), style: { appearance: "none", border: "none", background: "transparent", color: C.accent, cursor: "pointer", fontSize: 12 } }, "去处理")))))),
				risks.length === 0 ? h("div", { style: { padding: 16, color: C.ok, fontSize: 12.5 } }, "当前没有风险项") : null,

				h(Section, { title: "行动项", note: "周会定下来的事记在这里，点状态切换 未开始 → 进行中 → 已完成" }),
				h("table", { style: S.table },
					h("thead", null, h("tr", null, ["负责人", "动作", "截止", "状态", "结果", ""].map((t, i) =>
						h("th", { key: i, style: Object.assign({}, S.th, { width: ["13%", "38%", "12%", "12%", "22%", "3%"] [i] }) }, t)))),
					h("tbody", null, acts.map((a) => h("tr", { key: a.id },
						h("td", { style: S.td }, h(Cell, { value: a.owner, onChange: (v) => editAct(a.id, "owner", v) })),
						h("td", { style: S.td }, h(Cell, { value: a.action, onChange: (v) => editAct(a.id, "action", v) })),
						h("td", { style: S.td }, h(Cell, { value: a.due, align: "center", onChange: (v) => editAct(a.id, "due", v) })),
						h("td", { style: Object.assign({}, S.td, { textAlign: "center" }) },
							h("button", {
								onClick: () => cycle(a),
								style: {
									appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 11.5, padding: "2px 9px", borderRadius: 999,
									border: `1px solid ${a.status === "已完成" ? C.ok : a.status === "进行中" ? C.accent : C.line}`,
									background: a.status === "已完成" ? C.okSoft : a.status === "进行中" ? C.accentSoft : "#fff",
									color: a.status === "已完成" ? C.ok : a.status === "进行中" ? C.accent : C.sub,
								},
							}, a.status || "未开始")),
						h("td", { style: S.td }, h(Cell, { value: a.result, onChange: (v) => editAct(a.id, "result", v) })),
						h("td", { style: Object.assign({}, S.td, { textAlign: "center" }) },
							h(DelBtn, { onConfirm: () => delAct(a.id), title: "删除这个行动项（会再确认一次）" })))))),

				h("button", {
					onClick: () => setDb((d) => Object.assign({}, d, { actions: d.actions.concat([{ id: nid(), owner: "", action: "", due: "", status: "未开始", result: "" }]) })),
					style: Object.assign({}, S.add, { marginTop: 8 }),
				}, "＋ 添加行动项"));
		}

		function ReviewPage({ db, setDb }) {
			const [q1, setQ1] = useState("");
			const [q2, setQ2] = useState("");
			const [q3, setQ3] = useState("");
			const shownMeetings = db.meetings.filter((r) => match(r, q1));
			const shownMonth8 = db.month8.filter((r) => match(r, q2));
			const shownStrategy = db.strategy.filter((r) => match(r, q3));

			const updStrategy = (id, k, v) => setDb((d) => Object.assign({}, d, {
				strategy: d.strategy.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)),
			}));
			const delStrategy = (id) => setDb((d) => Object.assign({}, d, { strategy: d.strategy.filter((r) => r.id !== id) }));

			return h("div", null,
				h(Editable, {
					note: { title: "会议节奏", text: "照这个开，会议时间减半；可以按你的习惯改" },
					head: ["会议", "频率", "时长", "议程", "参会人"],
					widths: ["14%", "12%", "12%", "40%", "22%"],
					toolbar: h(Filter, { q: q1, setQ: setQ1, placeholder: "筛选会议…", shown: shownMeetings.length, total: db.meetings.length }),
					fields: [{ key: "name" }, { key: "freq", align: "center", options: ["每日", "每周", "每半月", "每月", "每季", "每年"] }, { key: "dur", align: "center" }, { key: "agenda" }, { key: "who" }],
					rows: shownMeetings,
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { meetings: d.meetings.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { meetings: d.meetings.concat([{ id: nid(), name: "", freq: "", dur: "", agenda: "", who: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { meetings: d.meetings.filter((r) => r.id !== id) })),
				}),

				h(Editable, {
					note: { title: "月度八张表", text: "每月填一次，空着的表说明这个月没管到" },
					head: ["序", "表", "要看的问题"],
					widths: ["7%", "20%", "73%"],
					toolbar: h(Filter, { q: q2, setQ: setQ2, placeholder: "筛选表格…", shown: shownMonth8.length, total: db.month8.length }),
					fields: [{ key: "no", align: "center" }, { key: "name" }, { key: "question" }],
					rows: shownMonth8,
					onChange: (id, k, v) => setDb((d) => Object.assign({}, d, { month8: d.month8.map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) })),
					onAdd: () => setDb((d) => Object.assign({}, d, { month8: d.month8.concat([{ id: nid(), no: "", name: "", question: "" }]) })),
					onDelete: (id) => setDb((d) => Object.assign({}, d, { month8: d.month8.filter((r) => r.id !== id) })),
				}),

				h(Section, { title: "一省一策 · 总纲", note: "三句话把这盘生意讲清楚；写完可一键导出" }),
				h("div", { style: { display: "grid", gap: 10, marginBottom: 4 } },
					[
						["strategy", "一句话战略", "在 ____ 个重点县，通过 ____ 类终端，用 ____ 的打法，实现 ____ 的增长。"],
						["battles", "三个必须赢的战役", "① ____________　② ____________　③ ____________"],
						["redlines", "三条不能碰的红线", "① 价格 ________　② 库存 ________　③ 合规 ________"],
					].map(([k, label, ph]) => h("div", { key: k, style: { border: `1px solid ${C.line}`, borderRadius: 10, padding: "10px 12px" } },
						h("div", { style: { fontSize: 12.5, fontWeight: 600, marginBottom: 6 } }, label),
						h(Area, {
							value: db.oneplan[k],
							placeholder: ph,
							label: "一省一策总纲 · " + label,
							onChange: (v) => setDb((d) => Object.assign({}, d, { oneplan: Object.assign({}, d.oneplan, { [k]: v }) })),
						})))),

				h(Section, { title: "一省一策 · 十二个模块", note: "每一项都要能落到「谁、在哪个县、做什么动作」；模块名与问题也能改" }),
				db.strategy.map((r) => h("div", {
					key: r.id,
					style: { border: `1px solid ${C.line}`, borderRadius: 10, padding: "10px 12px", marginBottom: 10 },
				},
					h("div", { style: { display: "flex", gap: 8, alignItems: "center", marginBottom: 6 } },
						h("div", { style: { width: 130, flex: "0 0 auto" } },
							h("input", {
								value: r.module == null ? "" : r.module,
								onChange: (e) => updStrategy(r.id, "module", e.target.value),
								style: Object.assign({}, inputBase, { fontWeight: 600, padding: "2px 4px" }),
							})),
						h("div", { style: { flex: 1 } },
							h(Cell, { value: r.question, onChange: (v) => updStrategy(r.id, "question", v) })),
						h(DelBtn, { onConfirm: () => delStrategy(r.id), title: "删除这一项（会再确认一次）" })),
					h(Area, {
						value: r.answer,
						placeholder: "在这里写你的答案…",
						label: "一省一策 · " + (r.module || "未命名模块"),
						onChange: (v) => updStrategy(r.id, "answer", v),
					}))),
				h("button", {
					onClick: () => setDb((d) => Object.assign({}, d, { strategy: d.strategy.concat([{ id: nid(), module: "", question: "", answer: "" }]) })),
					style: S.add,
				}, "＋ 添加一项"));
		}

		/* ---------------------------- 主面板 ---------------------------- */

		const TABS = [
			["overview", "总览"],
			["goal", "指标分解"],
			["client", "终端与代理"],
			["visit", "拜访"],
			["product", "产品价格"],
			["weekly", "周会与 90 天"],
			["metric", "指标看板"],
			["risk", "风险与行动"],
			["review", "会议与复盘"],
		];

		/** 把任意来源的数据补全成完整结构（缺的用 seed 补） */
		function normalize(v) {
			if (!v || !Array.isArray(v.cities)) return null;
			const base = seed();
			const out = {};
			Object.keys(base).forEach((k) => {
				if (Array.isArray(base[k])) out[k] = Array.isArray(v[k]) && v[k].length ? v[k] : base[k];
				else out[k] = v[k] && typeof v[k] === "object" ? Object.assign({}, base[k], v[k]) : base[k];
			});
			// 终端台账：老数据补市/县区/归属/电话/首单日（空着也能用，体检会提示补）
			out.customers = out.customers.map((c) => {
				const has = Object.prototype.hasOwnProperty.call(c, "big");
				const merged = Object.assign({ city: "", county: "", agent: "", phone: "", firstBuy: "" }, c);
				if (!has) merged.big = bigGuess(merged);
				return merged;
			});
			out.strategy = out.strategy.map((r) => Object.assign({ answer: "" }, r));
			out.actions = out.actions.map((r) => Object.assign({ status: "未开始", result: "" }, r));
			// 代理商补「负责大类」：老数据按承接产品推
			out.agents = out.agents.map((a) => Object.assign({}, a, { cat: String(a.cat || "").trim() || inferCat(out, a.scope) }));
			if (!Array.isArray(out.counties) || !out.counties.length) out.counties = makeCounties(out.cities);
			// 一次性迁移：老数据里的目标值改成“自动分摊”，让年度指标成为唯一主数
			if (v.schema !== 3) {
				out.cities = out.cities.map((c) => Object.assign({}, c, { t: "" }));
				out.counties = out.counties.map((k) => Object.assign({}, k, { t: "" }));
			}
			// 公司按地区价收款 → 分/万元 默认用地区价
			if (v.schema !== 4) {
				out.settings = Object.assign({}, out.settings, { convBase: "region", conv: "" });
			}
			// 产品名统一成目录标准名（柱附→桂附、丹参→丹芎、前列舒→前列腺舒）
			out.products = out.products.map((p) => {
				const nm = normName(p.name);
				return nm === p.name ? p : Object.assign({}, p, { name: nm });
			});
			out.schema = 4;
			return out;
		}

		function load() {
			try {
				const raw = window.localStorage.getItem(STORE_KEY);
				if (!raw) return null;
				return normalize(JSON.parse(raw));
			} catch (e) {
				return null;
			}
		}

		/** 是否用手机精简视图：插件里默认不用（除非 ?mobile=1）；独立网页版按窗口宽度自动切 */
		function isMobileNow() {
			try {
				const search = String((window.location && window.location.search) || "");
				if (search.indexOf("desktop=1") >= 0) return false;
				if (search.indexOf("mobile=1") >= 0) return true;
				if (!window.__JIANGSU_STANDALONE__) return false;
				const w = Number(window.innerWidth) || 0;
				return w > 0 && w <= 760;
			} catch (e) {
				return false;
			}
		}

		/** 手机专用精简视图：底部五个页签（首页 / 该跑 / 终端 / 看数 / 更多） */
		function MobileApp({ db, setDb }) {
			const [page, setPage] = useState("home");
			const [q, setQ] = useState("");
			const [editing, setEditing] = useState(null);
			const [confirmDel, setConfirmDel] = useState(false);
			const [msg, setMsg] = useState("");
			const today = fmtDate(new Date());

			const terms = db.customers || [];
			const setTerm = (id, patch) => setDb((d) => Object.assign({}, d, { customers: d.customers.map((t) => (t.id === id ? Object.assign({}, t, patch) : t)) }));
			const delTerm = (id) => setDb((d) => Object.assign({}, d, { customers: d.customers.filter((t) => t.id !== id) }));
			const addTerm = () => {
				const t = { id: nid(), name: "", type: "个体诊所", city: "", county: "", agent: "", phone: "", amt: "0", pot: "3", coop: "3", products: "", firstBuy: today, lastBuy: "", cycle: "30" };
				setDb((d) => Object.assign({}, d, { customers: d.customers.concat([t]) }));
				setEditing(t.id);
				setConfirmDel(false);
				setPage("terms");
			};
			const [visitTarget, setVisitTarget] = useState(null);
			const saveVisit = (form) => {
				const res = addVisit(db, visitTarget, form);
				setDb(res.db);
				setMsg("已记：" + (visitTarget.name || "终端") + " · " + res.entry.result + (String(res.entry.result).indexOf("成交") >= 0 ? "（最近进货已改到今天）" : ""));
				setVisitTarget(null);
			};

			const goal = num(db.settings && db.settings.annualTarget);
			const ytd = (db.board || []).reduce((a, b) => a + num(b.actual), 0);
			const rate = goal ? ytd / goal : 0;
			const conv = convOf(db);
			const mix = mixOf(db);

			const runList = terms.filter(isBig)
				.map((t) => ({ t, s: repurchase(t), st: termState(t) }))
				.filter((x) => x.st === "逾期" || x.st === "临近")
				.sort((a, b) => num(a.s.days) - num(b.s.days));

			const shownTerms = terms.filter((t) => {
				if (!q.trim()) return true;
				const s = q.trim().toLowerCase();
				return [t.name, t.city, t.county, t.agent, t.phone].join(" ").toLowerCase().indexOf(s) >= 0;
			});

			const big = { fontSize: 15, padding: "12px 14px", borderRadius: 10, fontFamily: FONT };
			const btn = (label, onClick, tone) => h("button", {
				onClick,
				style: Object.assign({}, big, {
					appearance: "none", border: `1px solid ${tone === "main" ? C.accent : tone === "warn" ? "#f0b4a8" : C.line}`,
					background: tone === "main" ? C.accent : tone === "warn" ? C.warnSoft : "#fff",
					color: tone === "main" ? "#fff" : tone === "warn" ? C.warn : C.ink,
					cursor: "pointer", fontWeight: tone === "main" ? 600 : 400,
				}),
			}, label);
			const card = (children, key) => h("div", {
				key,
				style: { border: `1px solid ${C.line}`, borderRadius: 12, padding: "12px 14px", background: "#fff", marginBottom: 10 },
			}, children);
			const kv = (k, v) => h("div", { style: { display: "flex", justifyContent: "space-between", gap: 10, fontSize: 13, padding: "3px 0" } },
				h("span", { style: { color: C.sub } }, k),
				h("span", { style: { fontWeight: 600, textAlign: "right" } }, v));
			const field = (label, value, onChange, ph) => h("label", { style: { display: "block", marginBottom: 12 } },
				h("div", { style: { fontSize: 12, color: C.sub, marginBottom: 4 } }, label),
				h("input", {
					value: value == null ? "" : value,
					placeholder: ph || "",
					onChange: (e) => onChange(e.target.value),
					style: {
						width: "100%", boxSizing: "border-box", padding: "11px 12px", fontSize: 15, fontFamily: FONT,
						border: `1px solid ${C.line}`, borderRadius: 10, outline: "none", background: "#fff",
					},
				}));

			/* ---------------- 页签内容 ---------------- */

			const home = h("div", null,
				h("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 } },
					h("div", { style: { border: `1px solid ${C.line}`, borderRadius: 12, padding: "12px 14px" } },
						h("div", { style: { fontSize: 12, color: C.sub } }, "年目标"),
						h("div", { style: { fontSize: 22, fontWeight: 700, marginTop: 2 } }, fmt(goal, 0) + " 万")),
					h("div", { style: { border: `1px solid ${C.line}`, borderRadius: 12, padding: "12px 14px" } },
						h("div", { style: { fontSize: 12, color: C.sub } }, "累计回款"),
						h("div", { style: { fontSize: 22, fontWeight: 700, marginTop: 2 } }, fmt(ytd, 1) + " 万")),
					h("div", { style: { border: `1px solid ${C.line}`, borderRadius: 12, padding: "12px 14px" } },
						h("div", { style: { fontSize: 12, color: C.sub } }, "达成率"),
						h("div", { style: { fontSize: 22, fontWeight: 700, marginTop: 2, color: rate >= 1 ? C.ok : rate >= 0.8 ? C.ink : C.warn } }, pct(rate))),
					h("div", { style: { border: `1px solid ${C.line}`, borderRadius: 12, padding: "12px 14px" } },
						h("div", { style: { fontSize: 12, color: C.sub } }, "终端 / 该跑"),
						h("div", { style: { fontSize: 22, fontWeight: 700, marginTop: 2 } }, terms.length + " / " + runList.length))),

				h("div", { style: { display: "flex", gap: 10, marginBottom: 14 } },
					h("div", { style: { flex: 1 } }, btn("今天该跑 " + runList.length + " 家", () => { setPage("run"); setMsg(""); }, "main")),
					h("div", { style: { flex: 1 } }, btn("＋ 新终端", () => { addTerm(); setMsg(""); }))),

				h("div", { style: { fontSize: 13, fontWeight: 650, margin: "4px 0 8px" } }, "最近拜访"),
				((db.visits || []).length
					? (db.visits || []).slice(0, 5).map((v) => card(h("div", null,
						h("div", { style: { fontSize: 14, fontWeight: 600 } }, v.terminal),
						h("div", { style: { fontSize: 12, color: C.sub, marginTop: 2 } }, (v.city || "") + (v.county ? " · " + v.county : "") + " · " + v.date + (v.note ? " · " + v.note : ""))), v.id))
					: h("div", { style: { fontSize: 13, color: C.sub, padding: "6px 0" } }, "还没有拜访记录；在「该跑」里点「记拜访」就会记下来")));

			const run = h("div", null,
				h("div", { style: { fontSize: 13, color: C.sub, marginBottom: 10 } },
					"这里只管大客户。按「最近进货 + 复购周期」算，逾期最久的排最前；点「记拜访」选结果，选「成交」才会把最近进货改成今天。"),
				msg ? h("div", { style: { fontSize: 13, color: C.ok, marginBottom: 10 } }, msg) : null,
				runList.length
					? runList.map((x) => card(h("div", null,
						h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 } },
							h("div", null,
								h("div", { style: { fontSize: 15, fontWeight: 650 } }, x.t.name || "未命名"),
								h("div", { style: { fontSize: 12, color: C.sub, marginTop: 2 } },
									(x.t.city || "") + (x.t.county ? " · " + x.t.county : "") + (x.t.agent ? " · " + x.t.agent : ""))),
							h("div", { style: { fontSize: 12, fontWeight: 600, color: x.st === "逾期" ? C.warn : "#c98a00", whiteSpace: "nowrap" } },
								x.st === "逾期" ? "逾期 " + Math.abs(num(x.s.days)) + " 天" : num(x.s.days) + " 天后")),
						h("div", { style: { fontSize: 12, color: C.sub, margin: "6px 0 10px" } }, "应复购 " + (x.s.due || "—") + (x.t.phone ? " · " + x.t.phone : "")),
						h("div", { style: { display: "flex", gap: 8 } },
							h("div", { style: { flex: 1 } }, btn("记拜访", () => setVisitTarget(x.t), "main")),
							x.t.phone ? h("a", { href: "tel:" + x.t.phone, style: { textDecoration: "none" } }, btn("电话", () => {})) : null)), x.t.id))
					: h("div", { style: { fontSize: 14, color: C.ok, padding: "20px 0", textAlign: "center" } }, "这几天没有要跑的终端"),

				((db.visits || []).filter((v) => v.date === today).length
					? h("div", { style: { marginTop: 10, fontSize: 12, color: C.sub } }, "今天已跑 " + (db.visits || []).filter((v) => v.date === today).length + " 家")
					: null));

			const editRow = editing ? terms.filter((t) => t.id === editing)[0] : null;
			const editor = editRow ? h("div", null,
				field("终端名称", editRow.name, (v) => setTerm(editRow.id, { name: v }), "如 康健诊所"),
				field("类型", editRow.type, (v) => setTerm(editRow.id, { type: v }), "个体诊所 / 单体药店 / 乡镇卫生院…"),
				field("市", editRow.city, (v) => setTerm(editRow.id, { city: v }), "如 南京"),
				field("县区", editRow.county, (v) => setTerm(editRow.id, { county: v }), "如 玄武区"),
				field("归属代理/负责人", editRow.agent, (v) => setTerm(editRow.id, { agent: v })),
				field("电话", editRow.phone, (v) => setTerm(editRow.id, { phone: v })),
				field("月均购进（元）", editRow.amt, (v) => setTerm(editRow.id, { amt: v })),
				field("复购周期（天）", editRow.cycle, (v) => setTerm(editRow.id, { cycle: v })),
				field("最近进货", editRow.lastBuy, (v) => setTerm(editRow.id, { lastBuy: v }), today),
				h("div", { style: { display: "flex", gap: 8, marginBottom: 12 } },
					h("div", { style: { flex: 1 } }, btn(isBig(editRow) ? "★ 大客户（点一下改成普通）" : "☆ 普通终端（点一下改成大客户）", () => setTerm(editRow.id, { big: isBig(editRow) ? "" : "1" }), isBig(editRow) ? "main" : undefined))),
				h("div", { style: { display: "flex", gap: 8, marginBottom: 8 } },
					h("div", { style: { flex: 1 } }, btn("最近进货 = 今天", () => setTerm(editRow.id, { lastBuy: today }), "main")),
					h("div", { style: { flex: 1 } }, btn("返回", () => { setEditing(null); setConfirmDel(false); setMsg(""); }))),
				h("div", { style: { marginTop: 10 } },
					confirmDel
						? btn("确认删除这个终端？（再点一次）", () => { delTerm(editRow.id); setEditing(null); setConfirmDel(false); setMsg("已删除"); }, "warn")
						: btn("删除这个终端", () => setConfirmDel(true), "warn")),
				h("div", { style: { fontSize: 12, color: C.sub, marginTop: 12, lineHeight: 1.7 } },
					"状态：" + termState(editRow) + " · 等级 " + gradeOf(editRow.amt, editRow.pot, editRow.coop) + " · 应复购 " + (repurchase(editRow).due || "—")))
				: h("div", null,
					h("div", { style: { display: "flex", gap: 10, marginBottom: 12 } },
						h("input", {
							value: q,
							placeholder: "搜终端 / 县区 / 代理 / 电话",
							onChange: (e) => setQ(e.target.value),
							style: { flex: 1, boxSizing: "border-box", padding: "11px 12px", fontSize: 15, fontFamily: FONT, border: `1px solid ${C.line}`, borderRadius: 10, outline: "none" },
						}),
						btn("＋", () => addTerm())),
					msg ? h("div", { style: { fontSize: 13, color: C.ok, marginBottom: 10 } }, msg) : null,
					h("div", { style: { fontSize: 12, color: C.sub, marginBottom: 8 } }, "共 " + shownTerms.length + " 家"),
					shownTerms.slice(0, 200).map((t) => card(h("div", {
						onClick: () => { setEditing(t.id); setConfirmDel(false); setMsg(""); },
						style: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 },
					},
						h("div", null,
							h("div", { style: { fontSize: 15, fontWeight: 600 } }, (isBig(t) ? "★ " : "") + (t.name || "（未命名）")),
							h("div", { style: { fontSize: 12, color: C.sub, marginTop: 2 } },
								(t.city || "—") + (t.county ? " · " + t.county : "") + (t.agent ? " · " + t.agent : ""))),
						h("div", { style: { fontSize: 12, whiteSpace: "nowrap", color: termState(t) === "逾期" ? C.warn : termState(t) === "在销" ? C.ok : C.sub } },
							termState(t))), t.id)));

			const dataPage = h("div", null,
				h("div", { style: { fontSize: 13, color: C.sub, marginBottom: 10 } }, "累计回款 " + fmt(ytd, 1) + " 万 / 年目标 " + fmt(goal, 0) + " 万 · 折合 " + fmt(ytd * conv, 0) + " 分"),
				card(h("div", null,
					h("div", { style: { fontSize: 13, fontWeight: 650, marginBottom: 8 } }, "按大类分目标"),
					mix.cats.filter((c) => mix.share[c] > 0).map((c) => h("div", { key: c, style: { marginBottom: 8 } },
						h("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 3 } },
							h("span", null, c),
							h("span", { style: { color: C.sub } }, Math.round(mix.share[c] * 100) + "% · " + r1(goal * mix.share[c]) + " 万")),
						h("div", { style: { height: 6, background: C.soft, borderRadius: 3, overflow: "hidden" } },
							h("div", { style: { width: (mix.share[c] * 100) + "%", height: 6, background: C.accent, borderRadius: 3 } })))))),
				card(h("div", null,
					h("div", { style: { fontSize: 13, fontWeight: 650, marginBottom: 8 } }, "各市 现有 / 目标"),
					aggByCity(db).map((g) => h("div", { key: g.city.id, style: { marginBottom: 8 } },
						h("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 3 } },
							h("span", null, g.city.city || "未命名"),
							h("span", { style: { color: C.sub } }, r1(g.e) + " / " + r1(g.t) + " 万")),
						h("div", { style: { height: 6, background: C.soft, borderRadius: 3, position: "relative" } },
							h("div", { style: { position: "absolute", left: 0, top: 0, height: 6, width: Math.min(100, (g.t ? (g.e / g.t) * 100 : 0)) + "%", background: g.e >= g.t ? C.ok : C.accent, borderRadius: 3 } })))))),
				h("div", { style: { fontSize: 12, color: C.sub, marginTop: 4, lineHeight: 1.7 } },
					"手机上只放了汇总；分品规、县区明细、产品目录在电脑上看得清楚。"));

			const backup = () => {
				try {
					const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
					const url = URL.createObjectURL(blob);
					const a = document.createElement("a");
					a.href = url;
					a.download = "江苏经营-备份-" + today + ".json";
					document.body.appendChild(a);
					a.click();
					document.body.removeChild(a);
					setTimeout(() => URL.revokeObjectURL(url), 2000);
					setMsg("已导出备份文件");
				} catch (e) {
					setMsg("备份失败：" + (e && e.message ? e.message : e));
				}
			};
			const restore = () => {
				const input = document.createElement("input");
				input.type = "file";
				input.accept = ".json,application/json";
				input.onchange = async () => {
					const f = input.files && input.files[0];
					if (!f) return;
					try {
						const next = normalize(JSON.parse(await f.text()));
						if (!next) throw new Error("文件里没有市/县区数据");
						setDb(next);
						setMsg("已恢复：" + f.name);
					} catch (e) {
						setMsg("恢复失败：" + (e && e.message ? e.message : e));
					}
				};
				input.click();
			};
			const exportAll = () => {
				try {
					let sheets = [];
					TABS.forEach((k) => { sheets = sheets.concat(sheetsFor(k[0], db)); });
					download("江苏经营-全部-" + today + ".xlsx", buildXlsx(sheets));
					setMsg("已导出 Excel");
				} catch (e) {
					setMsg("导出失败：" + (e && e.message ? e.message : e));
				}
			};

			const more = h("div", null,
				msg ? h("div", { style: { fontSize: 13, color: C.ok, marginBottom: 10 } }, msg) : null,
				h("div", { style: { display: "flex", flexDirection: "column", gap: 10 } },
					btn("备份到文件（发到微信）", backup, "main"),
					btn("从文件恢复（微信里收到的 JSON）", restore),
					btn("导出全部 Excel", exportAll),
					btn("切到电脑视图", () => { try { window.location.search = "?desktop=1"; } catch (e) { /* ignore */ } })),
				h("div", { style: { fontSize: 12, color: C.sub, marginTop: 14, lineHeight: 1.8 } },
					"数据只存在这台机器的浏览器里（localStorage）。换设备用「备份 / 恢复」搬。",
					h("br", null),
					"终端的「最近进货」改成当天日期，复购状态和该跑清单会自动更新。"),
				card(h("div", null,
					kv("终端", terms.length + " 家"),
					kv("拜访记录", (db.visits || []).length + " 条"),
					kv("市 / 县区", (db.cities || []).length + " / " + (db.counties || []).length),
					kv("产品品规", (db.products || []).length + " 个"))));

			const pages = { home, run, terms: editor, data: dataPage, more };
			const body = pages[page] || home;

			const navItem = (k, label) => h("button", {
				key: k,
				onClick: () => { setPage(k); setMsg(""); if (k !== "terms") { setEditing(null); setConfirmDel(false); } },
				style: {
					appearance: "none", border: "none", background: "transparent", flex: 1, padding: "8px 0 6px",
					fontFamily: FONT, fontSize: 11.5, cursor: "pointer",
					color: page === k ? C.accent : C.sub, fontWeight: page === k ? 650 : 400,
				},
			}, label);

			return h("div", { style: { minHeight: "100%", background: "#fff", fontFamily: FONT, color: C.ink } },
				h("div", {
					style: {
						position: "sticky", top: 0, zIndex: 20, background: "#fff", borderBottom: `1px solid ${C.line}`,
						padding: "12px 14px", display: "flex", alignItems: "baseline", justifyContent: "space-between",
					},
				},
					h("div", { style: { fontSize: 17, fontWeight: 700 } }, page === "home" ? "江苏经营" : page === "run" ? "今天该跑" : page === "terms" ? (editRow ? "编辑终端" : "终端台账") : page === "data" ? "看数" : "更多"),
					h("div", { style: { fontSize: 12, color: C.sub } }, today)),
				h("div", { style: { padding: "14px 14px 84px" } }, body),
				h("div", {
					style: {
						position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 30,
						display: "flex", background: "#fff", borderTop: `1px solid ${C.line}`,
						boxShadow: "0 -4px 16px rgba(16,24,40,.06)",
					},
				},
					navItem("home", "首页"),
					navItem("run", "该跑"),
					navItem("terms", "终端"),
					navItem("data", "看数"),
					navItem("more", "更多")),
				visitTarget ? h(VisitForm, { t: visitTarget, onSave: saveVisit, onClose: () => setVisitTarget(null) }) : null);
		}


		/* ---------------- 拜访闭环 ---------------- */
		const VISIT_METHODS = ["拜访", "电话", "微信", "活动"];
		const VISIT_RESULTS = ["成交（进货）", "有意向", "暂不需要", "没见到人"];

		/** 记一次拜访：写一条拜访记录；结果为「成交（进货）」时把最近进货改成拜访日 */
		function addVisit(db, t, form) {
			const today = fmtDate(new Date());
			const entry = {
				id: nid(),
				terminalId: t.id,
				terminal: t.name || "未命名",
				city: t.city || "",
				county: t.county || "",
				agent: t.agent || "",
				date: form.date || today,
				method: form.method || "拜访",
				result: form.result || "有意向",
				note: form.note || "",
				next: form.next || "",
			};
			const bought = String(entry.result).indexOf("成交") >= 0;
			return {
				db: Object.assign({}, db, {
					customers: bought ? (db.customers || []).map((x) => (x.id === t.id ? Object.assign({}, x, { lastBuy: entry.date }) : x)) : db.customers,
					visits: [entry].concat(db.visits || []).slice(0, 500),
				}),
				entry,
			};
		}

		/** 某终端最近一次拜访 */
		function lastVisitOf(db, t) {
			if (!t) return null;
			const list = (db.visits || []).filter((v) => v.terminalId === t.id || (!v.terminalId && v.terminal === t.name));
			return list.length ? list[0] : null;
		}

		/** 拜访页和拜访导出都只看大客户的拜访 */
		function bigVisitsOf(db) {
			const ids = {};
			const names = {};
			(db.customers || []).filter(isBig).forEach((t) => { ids[t.id] = 1; names[t.name] = 1; });
			return (db.visits || []).filter((v) => (v.terminalId ? ids[v.terminalId] : names[v.terminal]));
		}

		/** 拜访表单（手机、电脑共用） */
		function VisitForm({ t, onSave, onClose }) {
			const today = fmtDate(new Date());
			const [method, setMethod] = useState("拜访");
			const [result, setResult] = useState("成交（进货）");
			const [note, setNote] = useState("");
			const [next, setNext] = useState("");
			const [date, setDate] = useState(today);

			const chip = (opts, val, set) => h("div", { style: { display: "flex", gap: 6, flexWrap: "wrap" } },
				opts.map((o) => h("button", {
					key: o,
					onClick: () => set(o),
					style: {
						appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 13, padding: "7px 12px",
						borderRadius: 999, border: `1px solid ${val === o ? C.accent : C.line}`,
						background: val === o ? C.accentSoft : "#fff", color: val === o ? C.accent : C.ink,
					},
				}, o)));
			const input = (val, set, ph) => h("input", {
				value: val,
				placeholder: ph || "",
				onChange: (e) => set(e.target.value),
				style: { width: "100%", boxSizing: "border-box", padding: "10px 12px", fontSize: 14, fontFamily: FONT, border: `1px solid ${C.line}`, borderRadius: 10, outline: "none", background: "#fff" },
			});

			return h(Modal, {
				title: "记一次拜访 · " + (t.name || "终端"),
				onClose,
				width: 520,
				footer: h("div", { style: { display: "flex", gap: 8 } },
					h("button", { onClick: onClose, style: S.add }, "取消"),
					h("button", { onClick: () => onSave({ date, method, result, note, next }), style: Object.assign({}, S.add, { borderColor: C.accent, color: C.accent }) }, "保存")),
			},
				h("div", { style: { fontSize: 12.5, color: C.sub, marginBottom: 10 } },
					(t.city || "") + (t.county ? " · " + t.county : "") + (t.agent ? " · " + t.agent : "")),
				h("div", { style: { fontSize: 12.5, fontWeight: 600, margin: "10px 0 6px" } }, "方式"),
				chip(VISIT_METHODS, method, setMethod),
				h("div", { style: { fontSize: 12.5, fontWeight: 600, margin: "14px 0 6px" } }, "结果"),
				chip(VISIT_RESULTS, result, setResult),
				h("div", { style: { fontSize: 11.5, color: C.warn, marginTop: 6 } },
					String(result).indexOf("成交") >= 0 ? "会把这个终端的「最近进货」改成拜访日期" : "只记拜访，不改进货日期"),
				h("div", { style: { fontSize: 12.5, fontWeight: 600, margin: "14px 0 6px" } }, "下次跟进（可空）"),
				input(next, setNext, "2026-11-01"),
				h("div", { style: { fontSize: 12.5, fontWeight: 600, margin: "14px 0 6px" } }, "备注"),
				input(note, setNote, "一句话：说了什么、卡在哪、下一步"),
				h("div", { style: { fontSize: 12.5, fontWeight: 600, margin: "14px 0 6px" } }, "日期"),
				input(date, setDate, today));
		}

		/** 拜访页：本周进度 + 该跑未跑 + 拜访记录 */
		function VisitPage({ db, setDb }) {
			const [q, setQ] = useState("");
			const [rf, setRf] = useState("全部");
			const [target, setTarget] = useState(null);
			const terms = db.customers || [];
			const bigTerms = terms.filter(isBig);
			const visits = bigVisitsOf(db);
			const today = fmtDate(new Date());
			const weekAgo = (() => { const d = new Date(); d.setDate(d.getDate() - 7); return fmtDate(d); })();
			const inWeek = visits.filter((v) => String(v.date || "") >= weekAgo);
			const covered = new Set(inWeek.map((v) => v.terminalId || v.terminal)).size;
			const todayCount = visits.filter((v) => v.date === today).length;
			const runList = bigTerms
				.map((t) => ({ t, s: repurchase(t), st: termState(t), last: lastVisitOf(db, t) }))
				.filter((x) => x.st === "逾期" || x.st === "临近")
				.sort((a, b) => num(a.s.days) - num(b.s.days));
			const missed = runList.filter((x) => !x.last || String(x.last.date || "") < weekAgo);

			const shown = visits
				.filter((v) => rf === "全部" || String(v.result || "").indexOf(rf) >= 0)
				.filter((v) => match(v, q))
				.sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));

			const save = (form) => {
				const entry = addVisit(db, target, form);
				setDb(entry.db);
				setTarget(null);
			};
			const edit = (id, k, v) => setDb((d) => Object.assign({}, d, { visits: (d.visits || []).map((r) => (r.id === id ? Object.assign({}, r, { [k]: v }) : r)) }));
			const del = (id) => setDb((d) => Object.assign({}, d, { visits: (d.visits || []).filter((r) => r.id !== id) }));
			const tagOf = (r) => (String(r).indexOf("成交") >= 0 ? C.ok : String(r).indexOf("有意向") >= 0 ? C.accent : C.sub);
			const runCard = (x) => h("div", {
				key: x.t.id,
				style: { border: `1px solid ${C.line}`, borderRadius: 10, padding: "9px 12px", marginBottom: 8, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", background: "#fff" },
			},
				h("div", { style: { flex: 1, minWidth: 180 } },
					h("div", { style: { fontSize: 13, fontWeight: 600 } }, x.t.name || "未命名"),
					h("div", { style: { fontSize: 11.5, color: C.sub, marginTop: 2 } },
						(x.t.city || "") + (x.t.county ? " · " + x.t.county : "") + (x.t.agent ? " · " + x.t.agent : "") +
						(x.last ? "　上次拜访 " + (x.last.date || "") + "（" + (x.last.result || "") + "）" : "　从没拜访过"))),
				h("div", { style: { fontSize: 12, fontWeight: 600, color: x.st === "逾期" ? C.warn : "#c98a00", whiteSpace: "nowrap" } },
					x.st === "逾期" ? "逾期 " + Math.abs(num(x.s.days)) + " 天" : num(x.s.days) + " 天后"),
				h("button", { onClick: () => setTarget(x.t), style: Object.assign({}, S.add, { margin: 0 }) }, "记拜访"));

			return h("div", null,
				h("div", { style: S.cards },
					h(Card, { label: "大客户", value: bigTerms.length + " 家", hint: "拜访只管这些；普通终端在「终端与代理」维护" }),
					h(Card, { label: "本周拜访", value: inWeek.length + " 次", hint: "最近 7 天，只算大客户" }),
					h(Card, { label: "覆盖大客户", value: covered + " 家", hint: "本周跑到的大客户数" }),
					h(Card, { label: "该跑没跑", value: missed.length + " 家", tone: missed.length ? "warn" : "ok", hint: "大客户复购到期、本周还没拜访" })),

				h(Section, { title: "本周该跑的大客户（复购到期，还没跑的）", note: "只列大客户。点「记拜访」记一条：选方式、选结果、写一句备注就算闭环；结果为「成交」时自动把最近进货改成当天" }),
				missed.length
					? missed.slice(0, 20).map(runCard)
					: h("div", { style: { fontSize: 13, color: C.ok, padding: "8px 0 14px" } }, "大客户该跑的都在本周跑过了"),

				h(Section, { title: "大客户拜访记录", note: "只显示大客户的拜访；手机端记的也在同一张表里。普通终端的拜访不进这里" }),
				h(Filter, {
					q, setQ, placeholder: "搜终端 / 备注 / 县区…",
					chips: ["全部"].concat(VISIT_RESULTS), value: rf, setValue: setRf,
					shown: shown.length, total: visits.length,
				}),
				h(Editable, {
					note: { title: "", text: "" },
					head: ["日期", "终端", "方式", "结果", "备注", "下次跟进", "归属代理"],
					widths: ["9%", "18%", "8%", "12%", "28%", "10%", "15%"],
					fields: [
						{ key: "date", align: "center" },
						{ key: "terminal" },
						{ key: "method", align: "center", options: VISIT_METHODS },
						{
							key: "result", render: (r) => h("span", { style: { fontSize: 11.5, color: tagOf(r.result), fontWeight: 600 } }, r.result || "—"),
						},
						{ key: "note" },
						{ key: "next", align: "center" },
						{ key: "agent" },
					],
					rows: shown,
					onChange: edit,
					onAdd: () => setDb((d) => Object.assign({}, d, { visits: [{ id: nid(), date: today, terminal: "", method: "拜访", result: "有意向", note: "", next: "", city: "", county: "", agent: "" }].concat(d.visits || []) })),
					onDelete: del,
				}),

				target ? h(VisitForm, { t: target, onSave: save, onClose: () => setTarget(null) }) : null);
		}

		/* ---------------- 历史版本 / 回滚 ---------------- */
		const HIST_MAX = 20;          // 最多留 20 个还原点
		const HIST_BYTES = 900000;    // 历史总占用上限（约 1.8MB 实际）
		const histKey = () => STORE_KEY + ":history";

		function hashOf(str) {
			let h = 5381;
			for (let i = 0; i < str.length; i += 1) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
			return String(h);
		}

		function loadHistory() {
			try {
				const raw = window.localStorage.getItem(histKey());
				const arr = raw ? JSON.parse(raw) : [];
				return Array.isArray(arr) ? arr : [];
			} catch (e) {
				return [];
			}
		}

		function saveHistory(list) {
			let arr = (list || []).slice();
			const total = () => arr.reduce((a, x) => a + (x.size || 0), 0);
			while (arr.length > HIST_MAX) arr.shift();
			while (arr.length > 2 && total() > HIST_BYTES) arr.shift();
			try {
				window.localStorage.setItem(histKey(), JSON.stringify(arr));
			} catch (e) {
				// 存不下了：只留最近 3 个
				arr = arr.slice(-3);
				try { window.localStorage.setItem(histKey(), JSON.stringify(arr)); } catch (e2) { /* 放弃 */ }
			}
			return arr;
		}

		/** 存一个还原点；内容没变就不重复存 */
		function pushHistory(db, label) {
			try {
				const text = JSON.stringify(db);
				const h = hashOf(text);
				const list = loadHistory();
				const last = list[list.length - 1];
				if (last && last.hash === h) return list;
				const at = new Date();
				list.push({
					id: "h" + at.getTime(),
					at: at.toISOString(),
					time: String(at.getHours()).padStart(2, "0") + ":" + String(at.getMinutes()).padStart(2, "0"),
					date: at.getFullYear() + "-" + String(at.getMonth() + 1).padStart(2, "0") + "-" + String(at.getDate()).padStart(2, "0"),
					label: label || "自动",
					hash: h,
					size: text.length,
					data: db,
				});
				return saveHistory(list);
			} catch (e) {
				return [];
			}
		}

		/** 历史版本弹窗：看列表、存还原点、回到某个版本 */
		function HistoryDialog({ db, setDb, onClose }) {
			const [list, setList] = useState(() => loadHistory());
			const [msg, setMsg] = useState("");
			const [pending, setPending] = useState(null);
			const refresh = () => setList(loadHistory());

			const mark = () => {
				pushHistory(db, "手动还原点");
				refresh();
				setMsg("已存一个还原点");
			};
			const markCurrentBeforeUndo = () => {
				const text = JSON.stringify(db);
				const cur = loadHistory();
				const at = new Date();
				cur.push({
					id: "u" + at.getTime(),
					at: at.toISOString(),
					time: String(at.getHours()).padStart(2, "0") + ":" + String(at.getMinutes()).padStart(2, "0"),
					date: at.getFullYear() + "-" + String(at.getMonth() + 1).padStart(2, "0") + "-" + String(at.getDate()).padStart(2, "0"),
					label: "恢复前",
					hash: hashOf(text),
					size: text.length,
					data: db,
				});
				saveHistory(cur);
			};
			const restore = (item) => {
				if (pending !== item.id) {
					setPending(item.id);
					setMsg("会用这个版本覆盖现在的数据，再点一次「确认恢复」");
					return;
				}
				setPending(null);
				try {
					const next = normalize(JSON.parse(JSON.stringify(item.data)));
					if (!next) { setMsg("这个版本的数据不完整，没法恢复"); return; }
					markCurrentBeforeUndo();
					setDb(next);
					refresh();
					setMsg("已恢复到 " + (item.date || "") + " " + (item.time || "") + (item.label === "手动还原点" ? " · 手动还原点" : ""));
				} catch (e) {
					setMsg("恢复失败：" + (e && e.message ? e.message : e));
				}
			};
			const removeOne = (id) => {
				saveHistory(loadHistory().filter((x) => x.id !== id));
				refresh();
				setMsg("已删除这个还原点");
			};
			const clearAll = () => {
				if (pending !== "clear") { setPending("clear"); setMsg("再点一次「确认清空」才会清空全部历史"); return; }
				setPending(null);
				saveHistory([]);
				refresh();
				setMsg("历史已清空");
			};
			const tag = (t) => (/恢复前/.test(t) ? { c: C.warn, bg: C.warnSoft } : /手动/.test(t) ? { c: C.accent, bg: C.accentSoft } : { c: C.sub, bg: C.soft });

			return h(Modal, {
				title: "历史版本",
				onClose,
				width: 720,
				footer: h("div", { style: { display: "flex", gap: 8 } },
					h("button", { onClick: mark, style: Object.assign({}, S.add, { borderColor: C.accent, color: C.accent }) }, "存一个还原点"),
					h("button", { onClick: onClose, style: S.add }, "关闭")),
			},
				h("div", { style: { fontSize: 12.5, lineHeight: 1.8, color: "#374151", marginBottom: 10 } },
					"改完东西后会自动留一个还原点（最多 20 个，只存在这台机器上）。改错了就回到上一个版本；恢复前系统会先把「现在的样子」也存一份，回错了还能再回来。"),
				msg ? h("div", { style: { fontSize: 12, color: C.warn, marginBottom: 8 } }, msg) : null,
				list.length
					? h("table", { style: S.table },
						h("thead", null, h("tr", null,
							["时间", "类型", "终端", "拜访", "回款(万)", "操作"].map((t, i) => h("th", { key: i, style: Object.assign({}, S.th, { textAlign: i >= 2 && i <= 4 ? "right" : "left" }) }, t)))),
						h("tbody", null, list.slice().reverse().map((item) => {
							const d = item.data || {};
							const terms = (d.customers || []).length;
							const visits = (d.visits || []).length;
							const ytd = (d.board || []).reduce((a, b) => a + num(b.actual), 0);
							const t = tag(item.label || "");
							return h("tr", { key: item.id },
								h("td", { style: S.td }, (item.date || "") + " " + (item.time || "")),
								h("td", { style: S.td }, h("span", { style: { fontSize: 11, color: t.c, background: t.bg, borderRadius: 999, padding: "1px 7px", whiteSpace: "nowrap" } }, item.label || "自动")),
								h("td", { style: Object.assign({}, S.td, { textAlign: "right" }) }, String(terms)),
								h("td", { style: Object.assign({}, S.td, { textAlign: "right" }) }, String(visits)),
								h("td", { style: Object.assign({}, S.td, { textAlign: "right" }) }, r1(ytd)),
								h("td", { style: S.td },
									h("div", { style: { display: "flex", gap: 4, alignItems: "center" } },
										h("button", {
											onClick: () => restore(item),
											style: pending === item.id
												? { appearance: "none", cursor: "pointer", fontFamily: FONT, fontSize: 11, padding: "2px 8px", borderRadius: 6, border: `1px solid ${C.warn}`, background: C.warnSoft, color: C.warn, whiteSpace: "nowrap" }
												: Object.assign({}, S.add, { margin: 0, padding: "2px 9px" }),
										}, pending === item.id ? "确认恢复" : "恢复到这里"),
										h("button", { onClick: () => removeOne(item.id), style: Object.assign({}, S.del, { fontSize: 12 }), title: "删掉这个还原点" }, "✕"))));
						})),
						h("div", { style: { display: "flex", justifyContent: "flex-end", marginTop: 8 } },
							h("button", {
								onClick: clearAll,
								style: pending === "clear" ? Object.assign({}, S.add, { borderColor: "#f0b4a8", color: C.warn }) : S.add,
							}, pending === "clear" ? "确认清空" : "清空历史")))
					: h("div", { style: { padding: "24px 0", textAlign: "center", color: C.sub, fontSize: 12.5 } },
						"还没有还原点。改点东西、等 8 秒，就会自动存一个。"));

		}

		function App() {
			const [db, setDb] = useState(() => load() || (window.__JIANGSU_BLANK_SEED__ ? blankSeed() : seed()));
			const [tab, setTab] = useState("overview");
			const [dialog, setDialog] = useState(null);
			const [confirmReset, setConfirmReset] = useState(false);
			const [askBox, setAskBox] = useState(null);
			const [strict, setStrict] = useState(UI.strict);
			const [, setTick] = useState(0);
			const [mobile, setMobile] = useState(() => isMobileNow());

			useEffect(() => {
				const onResize = () => setMobile(isMobileNow());
				if (window.addEventListener) window.addEventListener("resize", onResize);
				return () => { if (window.removeEventListener) window.removeEventListener("resize", onResize); };
			}, []);

			useEffect(() => {
				const f = () => setTick((x) => x + 1);
				CHANGELOG.subs.push(f);
				return () => { CHANGELOG.subs = CHANGELOG.subs.filter((x) => x !== f); };
			}, []);

			useEffect(() => {
				try {
					window.localStorage.setItem(STORE_KEY, JSON.stringify(db));
				} catch (e) { /* 存储不可用时忽略 */ }
			}, [db]);

			// 改完等 8 秒，自动留一个还原点（内容没变不会重复存）
			useEffect(() => {
				const t = setTimeout(() => { try { pushHistory(db, "自动"); } catch (e) { /* 存不下就算了 */ } }, 8000);
				return () => clearTimeout(t);
			}, [db]);

			useEffect(() => {
				if (!confirmReset) return;
				const t = setTimeout(() => setConfirmReset(false), 4000);
				return () => clearTimeout(t);
			}, [confirmReset]);

			const body = tab === "overview" ? h(Overview, { db, setDb })
				: tab === "goal" ? h(GoalPage, { db, setDb })
				: tab === "client" ? h(ClientPage, { db, setDb })
					: tab === "visit" ? h(VisitPage, { db, setDb })
				: tab === "product" ? h(ProductPage, { db, setDb })
				: tab === "weekly" ? h(WeeklyPage, { db, setDb })
				: tab === "metric" ? h(MetricPage, { db, setDb })
				: tab === "risk" ? h(RiskPage, { db, setDb, onGo: setTab })
				: h(ReviewPage, { db, setDb });

			const btn = (label, onClick, tone) => h("button", {
				onClick,
				style: {
					appearance: "none", border: `1px solid ${tone === "danger" ? "#f0b4a8" : C.line}`,
					background: tone === "danger" ? C.warnSoft : "#fff", color: tone === "danger" ? C.warn : C.sub,
					padding: "5px 10px", borderRadius: 7, fontSize: 11.5, cursor: "pointer", fontFamily: FONT,
				},
			}, label);

			const day = new Date().toISOString().slice(0, 10);

			const exportNow = () => {
				try {
					const label = (TABS.filter((t) => t[0] === tab)[0] || [tab, tab])[1];
					download(`江苏经营-${label}-${day}.xlsx`, buildXlsx(sheetsFor(tab, db)));
				} catch (e) {
					window.alert && window.alert("导出失败：" + (e && e.message ? e.message : e));
				}
			};

			const exportAll = () => {
				try {
					let sheets = [];
					TABS.forEach(([k]) => { sheets = sheets.concat(sheetsFor(k, db)); });
					download(`江苏经营-全部-${day}.xlsx`, buildXlsx(sheets));
				} catch (e) {
					window.alert && window.alert("导出失败：" + (e && e.message ? e.message : e));
				}
			};

			const backup = () => {
				try {
					const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
					const url = URL.createObjectURL(blob);
					const a = document.createElement("a");
					a.href = url;
					a.download = `江苏经营-备份-${day}.json`;
					document.body.appendChild(a);
					a.click();
					document.body.removeChild(a);
					setTimeout(() => URL.revokeObjectURL(url), 2000);
				} catch (e) {
					window.alert && window.alert("备份失败：" + (e && e.message ? e.message : e));
				}
			};

			const restore = () => {
				const input = document.createElement("input");
				input.type = "file";
				input.accept = ".json,application/json";
				input.onchange = async () => {
					const f = input.files && input.files[0];
					if (!f) return;
					try {
						const next = normalize(JSON.parse(await f.text()));
						if (!next) throw new Error("文件里没有 cities 数据");
						setAskBox({
							title: "恢复备份？",
							text: "会用「" + f.name + "」覆盖现在的全部数据（市/县区、客户、代理、指标、产品目录都会变成备份里的样子）。\n确认前建议先点一次「备份」把当前数据存下来。",
							onYes: () => {
								setDb(next);
								window.alert && window.alert("已恢复：" + f.name);
							},
						});
					} catch (e) {
						window.alert && window.alert("恢复失败：" + (e && e.message ? e.message : e));
					}
				};
				input.click();
			};

			const deskView = h("div", { style: S.page },
				h("div", { style: S.head },
					h("div", null,
						h("h1", { style: S.h1 }, "江苏经营工作台"),
						h("div", { style: S.sub }, "数据只存这台设备 · 第一次用请点右上角「恢复」导入备份 · 手机和电脑之间用「备份 / 恢复」搬数据")),
					h("div", { style: { display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" } },
						h(GlobalSearch, { db, onGo: setTab }),
						btn("导入", () => setDialog("import")),
						window.__JIANGSU_STANDALONE__ ? null : btn("同步产品", () => setDialog("sync")),
						btn("体检", () => setDialog("health")),
						btn("版本", () => setDialog("history")),
						btn("导出本页", exportNow),
						btn("导出全部", exportAll),
						btn("备份", backup),
						btn("恢复", restore),
						btn("改动确认：" + (strict ? "开" : "关"), () => { UI.strict = !UI.strict; setStrict(UI.strict); if (!UI.strict) CHANGELOG.list = []; }),
						confirmReset
							? btn("确认清空？", () => { setDb(seed()); setConfirmReset(false); }, "danger")
							: btn("重置", () => setConfirmReset(true)))),

				h("div", { style: S.tabs }, TABS.map(([k, label]) =>
					h("button", { key: k, onClick: () => setTab(k), style: Object.assign({}, S.tab, tab === k ? S.tabOn : null) }, label))),

				body,

				dialog === "import" ? h(ImportDialog, { db, setDb, onClose: () => setDialog(null) }) : null,
				dialog === "sync" ? h(SyncDialog, { db, setDb, onClose: () => setDialog(null) }) : null,
				dialog === "health" ? h(HealthDialog, { db, setDb, onGo: setTab, onClose: () => setDialog(null) }) : null,
				dialog === "history" ? h(HistoryDialog, { db, setDb, onClose: () => setDialog(null) }) : null,

				strict && CHANGELOG.list.length ? (() => {
					const last = CHANGELOG.list[CHANGELOG.list.length - 1];
					return h("div", {
						style: {
							position: "fixed", left: "50%", bottom: 18, transform: "translateX(-50%)", zIndex: 150,
							display: "flex", alignItems: "center", gap: 12, padding: "10px 14px",
							background: "#fff", border: `1px solid ${C.line}`, borderRadius: 12,
							boxShadow: "0 10px 30px rgba(16,24,40,.16)", maxWidth: 620,
						},
					},
						h("div", { style: { flex: 1, minWidth: 0 } },
							h("div", { style: { fontSize: 12, fontWeight: 650 } }, `已改 ${CHANGELOG.list.length} 处 · ${last.label || "这一格"}`),
							h("div", { style: { fontSize: 11.5, color: C.sub, marginTop: 1 } }, `${last.from || "空"} → ${last.to || "空"}　（改动已保存，撤销只撤最后一处）`)),
						h("button", {
							onClick: () => { const e = CHANGELOG.list.pop(); if (e && e.set) e.set(e.from); setTick((x) => x + 1); },
							style: Object.assign({}, S.add, { margin: 0 }),
						}, "撤销"),
						h("button", {
							onClick: () => { CHANGELOG.list = []; setTick((x) => x + 1); },
							style: Object.assign({}, S.add, { margin: 0, borderColor: C.accent, color: C.accent }),
						}, "确认无误"));
				})() : null,

				askBox ? h(Modal, {
					title: askBox.title,
					onClose: () => setAskBox(null),
					width: 480,
					footer: h("div", { style: { display: "flex", gap: 8 } },
						h("button", { onClick: () => setAskBox(null), style: Object.assign({}, S.add) }, "取消"),
						h("button", {
							onClick: () => { const f2 = askBox.onYes; setAskBox(null); if (f2) f2(); },
							style: Object.assign({}, S.add, { borderColor: "#f0b4a8", color: C.warn }),
						}, "确认")),
				},
					h("div", { style: { fontSize: 12.5, lineHeight: 1.9, whiteSpace: "pre-wrap" } }, askBox.text)) : null);

			if (mobile) return h(MobileApp, { db, setDb });
			return deskView;
		}

		function PanelIcon() {
			return h("span", {
				style: {
					display: "inline-flex", alignItems: "center", justifyContent: "center",
					width: 18, height: 18, borderRadius: 5, border: "1.4px solid #2f6fed",
					color: "#2f6fed", fontSize: 11, fontWeight: 700, lineHeight: 1, fontFamily: FONT,
				},
			}, "苏");
		}

		/* ---------------------------- 接线 ---------------------------- */

		const inject = ["slots"];

		function apply(ctx) {
			ctx.slots.inject("main", () => ctx.slots.register({
				name: "main",
				key: PANEL_ID,
			}, App));
			ctx.slots.inject("sidebar.panellist", () => ctx.slots.register({
				name: "sidebar.panellist",
				id: PANEL_ID,
				order: 21,
				label: "江苏经营 V2",
			}, PanelIcon));
		}

		exports.apply = apply;
		exports.inject = inject;
		// 调试钩子：便于离线验证导出/数据，不影响面板行为
		exports.__internal = { buildXlsx, sheetsFor, seed, load, aggByCity, normalize, readXlsx, parsePaste, healthIssues, risksOf, IMPORT_TARGETS, upsertRows, agentsOfCounty, repurchase, targetsOf, buildCity, catalogOf, catOf, normName, CAT_ROWS, CAT_ORDER, specList, catsOf, agentCovers, catListOf, mixOf, catCoverage, inferCat, pickToggle, MultiPicker, DelBtn, UI, CHANGELOG, pushChange, termState, countTerminals, countyNamesIn, agentNamesIn, mergeProductData, readOtherStore, SyncDialog, OTHER_STORE_KEY, MobileApp, isMobileNow, pushHistory, loadHistory, saveHistory, histKey, HistoryDialog, STORE_KEY, addVisit, lastVisitOf, VisitForm, VisitPage, VISIT_RESULTS, VISIT_METHODS, isBig, bigGuess, bigVisitsOf, blankSeed };

	const mountEl = document.getElementById("root");
	const root = window.ReactDOM.createRoot(mountEl);
	root.render(React.createElement(App));
})();
